<!-- view.php -->
<?php
include_once("../../globals.php");
include_once("../../../library/api.inc");
formHeader("Form: CAMOS");
?>
<html><head>
<link rel=stylesheet href="<?echo $css_header;?>" type="text/css">
<script type="text/javascript">
function checkall(){
  var f = document.my_form;
  var x = f.elements.length;
  var i;
  for(i=0;i<x;i++) {
    if (f.elements[i].type == 'checkbox') {
      f.elements[i].checked = true;
    }
  }
}
function uncheckall(){
  var f = document.my_form;
  var x = f.elements.length;
  var i;
  for(i=0;i<x;i++) {
    if (f.elements[i].type == 'checkbox') {
      f.elements[i].checked = false;
    }
  }
}
</script>
<?php html_header_show();?>
<link rel="stylesheet" href="<?php echo $css_header;?>" type="text/css">
</head>
<body class="body_top">
<form method=post action="<?php echo $rootdir?>/forms/CAMOS/save.php?mode=delete&id=<?php echo $_GET["id"];?>" name="my_form">
<h1> CAMOS </h1>
<input type="submit" name="submit form" value="Delete" /><?php
echo "<a href='".$GLOBALS['webroot'] . "/interface/patient_file/encounter/patient_encounter.php'>[do nothing]</a>";
?>
<br/><br/>
<input type='button' value='check all'
  onClick='checkall()'>
<input type='button' value='uncheck all'
  onClick='uncheckall()'>
<br/><br/>
<?php
//experimental code start

  $query = "SELECT id, content FROM form_CAMOS where " .
    "date(date) = current_date() and pid = ".$GLOBALS['pid']." and activity=1";
  $statement = sqlStatement($query);
  while ($result = sqlFetchArray($statement)) { 
    print "<input type=checkbox name='ch_".$result['id']."'> ".$result['content']."<br/>\n";
  }


//experimental code end
?>
</form>
<?
formFooter();
?>
