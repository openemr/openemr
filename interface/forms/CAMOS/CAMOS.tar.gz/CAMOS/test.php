<?php
// Example 1
//$string = "mark leeds: sore throat";
$name = " sore throat";
if (strpos($string, ":") !== false) {
  mysplit($string);
} else {
  echo "no : so I didn't bother to check\n";
}
function mysplit($string) {
  $pieces = preg_split('/\s*:\s*/', $string);
  echo "pieces 0: ".$pieces[0]."\n"; // piece1
  echo "pieces 1: ".$pieces[1]."\n"; // piece1
}
?>

