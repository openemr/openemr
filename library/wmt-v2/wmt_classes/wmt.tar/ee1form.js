function toggleROStoNo()
{
  var i;
  var l = document.ext1_form.elements.length;
  for (i=0; i<l; i++) {
    if(document.ext1_form.elements[i].type.indexOf('select') != -1) {
      if(document.ext1_form.elements[i].name.indexOf('ee1_rs_') != -1) {
        document.ext1_form.elements[i].selectedIndex = '2';
      }
    }
    if(document.ext1_form.elements[i].type.indexOf('check') != -1) {
      if(document.ext1_form.elements[i].name.indexOf('_hpi') != -1) {
        document.ext1_form.elements[i].checked= false;
      }
		}
  }
}

function toggleROStoNull()
{
  var i;
  var l = document.ext1_form.elements.length;
  for (i=0; i<l; i++) {
    if(document.ext1_form.elements[i].type.indexOf('select') != -1) {
      if(document.ext1_form.elements[i].name.indexOf('ee1_rs_') != -1) {
        document.ext1_form.elements[i].selectedIndex = '0';
      }
    }
  }
}

function toggleFamilyExtraNo()
{
  document.ext1_form.elements['ee1_fh_diabetes'].selectedIndex = '2';
  document.ext1_form.elements['ee1_fh_coronary'].selectedIndex = '2';
  document.ext1_form.elements['ee1_fh_htn'].selectedIndex = '2';
  document.ext1_form.elements['ee1_fh_hyper'].selectedIndex = '2';
  document.ext1_form.elements['ee1_fh_thyroid'].selectedIndex = '2';
  document.ext1_form.elements['ee1_fh_colon'].selectedIndex = '2';
  document.ext1_form.elements['ee1_fh_lung'].selectedIndex = '2';
}

function ClearExam()
{
  var i;
  var l = document.ext1_form.elements.length;
  for (i=0; i<l; i++) {
    if(document.ext1_form.elements[i].name.indexOf('ee1_ge_') != -1) {
    	if(document.ext1_form.elements[i].type.indexOf('select') != -1) {
        document.ext1_form.elements[i].selectedIndex = '0';
      }
    	if(document.ext1_form.elements[i].type.indexOf('check') != -1) {
        document.ext1_form.elements[i].checked=false;
      }
    	if(document.ext1_form.elements[i].type.indexOf('text') != -1) {
        if(document.ext1_form.elements[i].name.indexOf('dictate') == -1) {
					document.ext1_form.elements[i].value='';
				}
      }
    }
  }
}

function ClearConstitutional()
{
  if(document.ext1_form.elements['ee1_rs_const_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_fev'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_fev_nt'].value='';
		document.ext1_form.elements['ee1_rs_loss'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_loss_nt'].value='';
		document.ext1_form.elements['ee1_rs_gain'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_gain_nt'].value='';
	}
}

function ClearSkin()
{
  if(document.ext1_form.elements['ee1_rs_skin_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_rash'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_rash_nt'].value='';
		document.ext1_form.elements['ee1_rs_ml'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_ml_nt'].value='';
	}
}

function ClearBreast()
{
  if(document.ext1_form.elements['ee1_rs_breast_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_nip'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_nip_nt'].value='';
		document.ext1_form.elements['ee1_rs_lmp'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_lmp_nt'].value='';
		document.ext1_form.elements['ee1_rs_skn'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_skn_nt'].value='';
	}
}

function ClearNeurologic()
{
  if(document.ext1_form.elements['ee1_rs_neuro_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_diz'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_diz_nt'].value='';
		document.ext1_form.elements['ee1_rs_sz'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_sz_nt'].value='';
		document.ext1_form.elements['ee1_rs_numb'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_numb_nt'].value='';
		document.ext1_form.elements['ee1_rs_head'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_head_nt'].value='';
		document.ext1_form.elements['ee1_rs_strength'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_strength_nt'].value='';
		document.ext1_form.elements['ee1_rs_tremor'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_tremor_nt'].value='';
		document.ext1_form.elements['ee1_rs_dysarthria'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_dysarthria_nt'].value='';
	}
}

function ClearMusculoskeletal()
{
  if(document.ext1_form.elements['ee1_rs_msk_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_jnt'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_jnt_nt'].value='';
		document.ext1_form.elements['ee1_rs_stiff'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_stiff_nt'].value='';
		document.ext1_form.elements['ee1_rs_wk'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_wk_nt'].value='';
		document.ext1_form.elements['ee1_rs_mpain'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_mpain_nt'].value='';
		document.ext1_form.elements['ee1_rs_ply_up'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_ply_up_nt'].value='';
		document.ext1_form.elements['ee1_rs_ply_dn'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_ply_dn_nt'].value='';
	}
}

function ClearEndocrine(sex)
{
  if(document.ext1_form.elements['ee1_rs_endocrine_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_hair'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hair_nt'].value='';
		document.ext1_form.elements['ee1_rs_acne'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_acne_nt'].value='';
		document.ext1_form.elements['ee1_rs_hotcold'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hotcold_nt'].value='';
		document.ext1_form.elements['ee1_rs_diabetes'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_diabetes_nt'].value='';
		document.ext1_form.elements['ee1_rs_thyroid'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_thyroid_nt'].value='';
		document.ext1_form.elements['ee1_rs_tired'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_tired_nt'].value='';
		document.ext1_form.elements['ee1_rs_voice'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_voice_nt'].value='';
		document.ext1_form.elements['ee1_rs_dysphagia'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_dysphagia_nt'].value='';
		document.ext1_form.elements['ee1_rs_odyno'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_odyno_nt'].value='';
		document.ext1_form.elements['ee1_rs_polyuria'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_polyuria_nt'].value='';
		document.ext1_form.elements['ee1_rs_polydipsia'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_polydipsia_nt'].value='';
		document.ext1_form.elements['ee1_rs_nightmare'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_nightmare_nt'].value='';
		document.ext1_form.elements['ee1_rs_nightswt'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_nightswt_nt'].value='';
		document.ext1_form.elements['ee1_rs_brittle'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_brittle_nt'].value='';
		document.ext1_form.elements['ee1_rs_sweat'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_sweat_nt'].value='';
		document.ext1_form.elements['ee1_rs_neck'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_neck_nt'].value='';
		if(sex == 'f') {
			document.ext1_form.elements['ee1_rs_menses'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_menses_nt'].value='';
		}
		document.ext1_form.elements['ee1_rs_hirs'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hirs_nt'].value='';
	}
}

function ClearGastrointestinal()
{
  if(document.ext1_form.elements['ee1_rs_gastro_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_naus'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_naus_nt'].value='';
		document.ext1_form.elements['ee1_rs_vomit'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_vomit_nt'].value='';
		document.ext1_form.elements['ee1_rs_ref'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_ref_nt'].value='';
		document.ext1_form.elements['ee1_rs_anal_p'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_anal_p_nt'].value='';
		document.ext1_form.elements['ee1_rs_jaun'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_jaun_nt'].value='';
		document.ext1_form.elements['ee1_rs_bow'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_bow_nt'].value='';
		document.ext1_form.elements['ee1_rs_dia'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_dia_nt'].value='';
		document.ext1_form.elements['ee1_rs_const'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_const_nt'].value='';
		document.ext1_form.elements['ee1_rs_melena'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_melena_nt'].value='';
		document.ext1_form.elements['ee1_rs_hematemesis'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hematemesis_nt'].value='';
		document.ext1_form.elements['ee1_rs_hematochezia'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hematochezia_nt'].value='';
	}
}

function ClearCardiovascular()
{
  if(document.ext1_form.elements['ee1_rs_cardio_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_cpain'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_cpain_nt'].value='';
		document.ext1_form.elements['ee1_rs_breathe'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_breathe_nt'].value='';
		document.ext1_form.elements['ee1_rs_swell'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_swell_nt'].value='';
		document.ext1_form.elements['ee1_rs_palp'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_palp_nt'].value='';
		document.ext1_form.elements['ee1_rs_jaw'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_jaw_nt'].value='';
		document.ext1_form.elements['ee1_rs_arm'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_arm_nt'].value='';
		document.ext1_form.elements['ee1_rs_back'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_back_nt'].value='';
		document.ext1_form.elements['ee1_rs_acute'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_acute_nt'].value='';
	}
}

function ClearAllergic()
{
  if(document.ext1_form.elements['ee1_rs_imm_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_hay'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hay_nt'].value='';
		document.ext1_form.elements['ee1_rs_med'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_med_nt'].value='';
	}
}

function ClearRespiratory()
{
  if(document.ext1_form.elements['ee1_rs_resp_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_whz'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_whz_nt'].value='';
		document.ext1_form.elements['ee1_rs_shrt'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_shrt_nt'].value='';
		document.ext1_form.elements['ee1_rs_cgh'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_cgh_nt'].value='';
		document.ext1_form.elements['ee1_rs_slp'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_slp_nt'].value='';
		document.ext1_form.elements['ee1_rs_spu'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_spu_nt'].value='';
		document.ext1_form.elements['ee1_rs_dys'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_dys_nt'].value='';
		document.ext1_form.elements['ee1_rs_hemoptysis'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hemoptysis_nt'].value='';
		document.ext1_form.elements['ee1_rs_snore'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_snore_nt'].value='';
	}
}

function ClearEyes()
{
  if(document.ext1_form.elements['ee1_rs_eyes_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_blr'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_blr_nt'].value='';
		document.ext1_form.elements['ee1_rs_dbl'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_dbl_nt'].value='';
		document.ext1_form.elements['ee1_rs_vis'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_vis_nt'].value='';
		document.ext1_form.elements['ee1_rs_vloss'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_vloss_nt'].value='';
		document.ext1_form.elements['ee1_rs_blind'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_blind_nt'].value='';
		document.ext1_form.elements['ee1_rs_mac'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_mac_nt'].value='';
		document.ext1_form.elements['ee1_rs_vpain'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_vpain_nt'].value='';
		document.ext1_form.elements['ee1_rs_dry'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_dry_nt'].value='';
	}
}

function ClearENT()
{
  if(document.ext1_form.elements['ee1_rs_ent_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_sore'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_sore_nt'].value='';
		document.ext1_form.elements['ee1_rs_sin'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_sin_nt'].value='';
		document.ext1_form.elements['ee1_rs_hear'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hear_nt'].value='';
		document.ext1_form.elements['ee1_rs_tin'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_tin_nt'].value='';
		document.ext1_form.elements['ee1_rs_hot'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hot_nt'].value='';
		document.ext1_form.elements['ee1_rs_lymph'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_lymph_nt'].value='';
		document.ext1_form.elements['ee1_rs_mass'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_mass_nt'].value='';
		document.ext1_form.elements['ee1_rs_epain'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_epain_nt'].value='';
	}
}

function ClearLymph()
{
  if(document.ext1_form.elements['ee1_rs_lymph_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_swl'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_swl_nt'].value='';
		document.ext1_form.elements['ee1_rs_brse'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_brse_nt'].value='';
		document.ext1_form.elements['ee1_rs_nose'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_nose_nt'].value='';
		document.ext1_form.elements['ee1_rs_trait'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_trait_nt'].value='';
	}
}

function ClearPsychiatric()
{
  if(document.ext1_form.elements['ee1_rs_psych_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_dep'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_dep_nt'].value='';
		document.ext1_form.elements['ee1_rs_anx'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_anx_nt'].value='';
		document.ext1_form.elements['ee1_rs_sui'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_sui_nt'].value='';
		document.ext1_form.elements['ee1_rs_hom'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hom_nt'].value='';
	}
}

function ClearGenitourinary(sex)
{
  if(document.ext1_form.elements['ee1_rs_gen_hpi'].checked==true) {
		document.ext1_form.elements['ee1_rs_leak'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_leak_nt'].value='';
		document.ext1_form.elements['ee1_rs_ret'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_ret_nt'].value='';
		if(sex == 'f') {
			document.ext1_form.elements['ee1_rs_vag'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_vag_nt'].value='';
			document.ext1_form.elements['ee1_rs_bleed'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_bleed_nt'].value='';
			document.ext1_form.elements['ee1_rs_pp'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_pp_nt'].value='';
			document.ext1_form.elements['ee1_rs_sex'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_sex_nt'].value='';
			document.ext1_form.elements['ee1_rs_fib'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_fib_nt'].value='';
			document.ext1_form.elements['ee1_rs_inf'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_inf_nt'].value='';
		}
		document.ext1_form.elements['ee1_rs_urg'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_urg_nt'].value='';
		document.ext1_form.elements['ee1_rs_hematuria'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_hematuria_nt'].value='';
		document.ext1_form.elements['ee1_rs_nocturia'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_nocturia_nt'].value='';
		if(sex == 'f') {
			document.ext1_form.elements['ee1_rs_low'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_low_nt'].value='';
		}
		if(sex == 'm') {
			document.ext1_form.elements['ee1_rs_ed'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_ed_nt'].value='';
			document.ext1_form.elements['ee1_rs_libido'].selectedIndex=0;
			document.ext1_form.elements['ee1_rs_libido_nt'].value='';
		}
		document.ext1_form.elements['ee1_rs_weaks'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_weaks_nt'].value='';
		document.ext1_form.elements['ee1_rs_drib'].selectedIndex=0;
		document.ext1_form.elements['ee1_rs_drib_nt'].value='';
	}
}

function clearGEGeneral()
{
  document.ext1_form.elements['ee1_ge_gen_norm'].checked=false;
  document.ext1_form.elements['ee1_ge_gen_norm_nt'].value='';
  document.ext1_form.elements['ee1_ge_gen_dev'].checked=false;
  document.ext1_form.elements['ee1_ge_gen_dev_nt'].value='';
  document.ext1_form.elements['ee1_ge_gen_groom'].checked=false;
  document.ext1_form.elements['ee1_ge_gen_groom_nt'].value='';
  document.ext1_form.elements['ee1_ge_gen_dis'].checked=false;
  document.ext1_form.elements['ee1_ge_gen_dis_nt'].value='';
  document.ext1_form.elements['ee1_ge_gen_jaun'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gen_jaun_nt'].value='';
  document.ext1_form.elements['ee1_ge_gen_waste'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gen_waste_nt'].value='';
  document.ext1_form.elements['ee1_ge_gen_sleep'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gen_sleep_nt'].value='';
  document.ext1_form.elements['ee1_ge_gen_nt'].value='';
}

function clearGEHead()
{
  document.ext1_form.elements['ee1_ge_hd_atra'].checked=false;
  document.ext1_form.elements['ee1_ge_hd_atra_nt'].value='';
  document.ext1_form.elements['ee1_ge_hd_norm'].checked=false;
  document.ext1_form.elements['ee1_ge_hd_norm_nt'].value='';
  document.ext1_form.elements['ee1_ge_hd_nt'].value='';
}

function clearGEEyes()
{
  document.ext1_form.elements['ee1_ge_eye_pupil'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eye_pupil_nt'].value='';
  document.ext1_form.elements['ee1_ge_eye_hem'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eye_hem_nt'].value='';
  document.ext1_form.elements['ee1_ge_eye_exu'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eye_exu_nt'].value='';
  document.ext1_form.elements['ee1_ge_eye_av'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eye_av_nt'].value='';
  document.ext1_form.elements['ee1_ge_eye_pap'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eye_pap_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyer_norm'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyer_norm_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyer_exo'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyer_exo_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyer_stare'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyer_stare_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyer_lag'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyer_lag_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyer_scleral'].checked=false;
  document.ext1_form.elements['ee1_ge_eyer_scleral_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyer_eomi'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyer_eomi_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyer_perrl'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyer_perrl_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyel_norm'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyel_norm_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyel_exo'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyel_exo_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyel_stare'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyel_stare_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyel_lag'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyel_lag_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyel_scleral'].checked=false;
  document.ext1_form.elements['ee1_ge_eyel_scleral_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyel_eomi'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyel_eomi_nt'].value='';
  document.ext1_form.elements['ee1_ge_eyel_perrl'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_eyel_perrl_nt'].value='';
  document.ext1_form.elements['ee1_ge_eye_nt'].value='';
}

function clearGEEars()
{
  document.ext1_form.elements['ee1_ge_earr_tym_nt'].value='';
  document.ext1_form.elements['ee1_ge_earr_clear'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earr_clear_nt'].value='';
  document.ext1_form.elements['ee1_ge_earr_perf'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earr_perf_nt'].value='';
  document.ext1_form.elements['ee1_ge_earr_ret'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earr_ret_nt'].value='';
  document.ext1_form.elements['ee1_ge_earr_pus'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earr_pus_nt'].value='';
  document.ext1_form.elements['ee1_ge_earr_ceru'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earr_ceru_nt'].value='';
  document.ext1_form.elements['ee1_ge_earl_tym_nt'].value='';
  document.ext1_form.elements['ee1_ge_earl_clear'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earl_clear_nt'].value='';
  document.ext1_form.elements['ee1_ge_earl_perf'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earl_perf_nt'].value='';
  document.ext1_form.elements['ee1_ge_earl_ret'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earl_ret_nt'].value='';
  document.ext1_form.elements['ee1_ge_earl_pus'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earl_pus_nt'].value='';
  document.ext1_form.elements['ee1_ge_earl_ceru'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_earl_ceru_nt'].value='';
  document.ext1_form.elements['ee1_ge_ear_nt'].value='';
}

function clearGENose()
{
  document.ext1_form.elements['ee1_ge_nose_ery'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nose_ery_nt'].value='';
  document.ext1_form.elements['ee1_ge_nose_swell'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nose_swell_nt'].value='';
  document.ext1_form.elements['ee1_ge_nose_pall'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nose_pall_nt'].value='';
  document.ext1_form.elements['ee1_ge_nose_polps'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nose_polps_nt'].value='';
  document.ext1_form.elements['ee1_ge_nose_sept'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nose_sept_nt'].value='';
  document.ext1_form.elements['ee1_ge_nose_nt'].value='';
}

function clearGEMouth()
{
  document.ext1_form.elements['ee1_ge_mouth_moist'].checked=false;
  document.ext1_form.elements['ee1_ge_mouth_moist_nt'].value='';
  document.ext1_form.elements['ee1_ge_mouth_nt'].value='';
}

function clearGEThroat()
{
  document.ext1_form.elements['ee1_ge_thrt_ery'].checked=false;
  document.ext1_form.elements['ee1_ge_thrt_ery_nt'].value='';
  document.ext1_form.elements['ee1_ge_thrt_exu'].checked=false;
  document.ext1_form.elements['ee1_ge_thrt_exu_nt'].value='';
  document.ext1_form.elements['ee1_ge_thrt_nt'].value='';
}

function clearGENeck()
{
  document.ext1_form.elements['ee1_ge_nk_sup'].checked=false;
  document.ext1_form.elements['ee1_ge_nk_brit'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nk_jvp'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nk_lymph'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nk_trach'].checked=false;
  document.ext1_form.elements['ee1_ge_nk_nt'].value='';
}

function clearGEThyroid()
{
  document.ext1_form.elements['ee1_ge_thy_norm'].checked=false;
  document.ext1_form.elements['ee1_ge_thy_norm_nt'].value='';
  document.ext1_form.elements['ee1_ge_thy_nod'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_thy_nod_nt'].value='';
  document.ext1_form.elements['ee1_ge_thy_brit'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_thy_brit_nt'].value='';
  document.ext1_form.elements['ee1_ge_thy_tnd'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_thy_tnd_nt'].value='';
  document.ext1_form.elements['ee1_ge_thy_nt'].value='';
}

function clearGEBreasts()
{
  document.ext1_form.elements['ee1_ge_brr_axil'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_brr_axil_nt'].value='';
  document.ext1_form.elements['ee1_ge_brr_mass'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_brr_mass_nt'].value='';
  document.ext1_form.elements['ee1_ge_brr_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipr_ev'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipr_ev_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipr_in'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipr_in_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipr_mass'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipr_mass_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipr_dis'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipr_dis_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipr_ret'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipr_ret_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipr_nt'].value='';
  document.ext1_form.elements['ee1_ge_brl_axil'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_brl_axil_nt'].value='';
  document.ext1_form.elements['ee1_ge_brl_mass'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_brl_mass_nt'].value='';
  document.ext1_form.elements['ee1_ge_brl_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipl_ev'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipl_ev_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipl_in'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipl_in_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipl_mass'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipl_mass_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipl_dis'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipl_dis_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipl_ret'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_nipl_ret_nt'].value='';
  document.ext1_form.elements['ee1_ge_nipl_nt'].value='';
}

function clearGECardio()
{
  document.ext1_form.elements['ee1_ge_cr_norm'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_cr_norm_nt'].value='';
  document.ext1_form.elements['ee1_ge_cr_mur'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_cr_mur_nt'].value='';
  document.ext1_form.elements['ee1_ge_cr_gall'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_cr_gall_nt'].value='';
  document.ext1_form.elements['ee1_ge_cr_click'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_cr_click_nt'].value='';
  document.ext1_form.elements['ee1_ge_cr_rubs'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_cr_rubs_nt'].value='';
  document.ext1_form.elements['ee1_ge_cr_extra'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_cr_extra_nt'].value='';
  document.ext1_form.elements['ee1_ge_cr_nt'].value='';
}

function clearGEPulmo()
{
  document.ext1_form.elements['ee1_ge_pul_clear'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_pul_rales'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_pul_whz'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_pul_ron'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_pul_dec'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_pul_nt'].value='';
}

function clearGEGastro()
{
  document.ext1_form.elements['ee1_ge_gi_soft'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gi_tend'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gi_tend_loc'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gi_dis'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gi_scar'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gi_hern'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gi_bowel'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gi_hepa'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gi_spleno'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_gi_nt'].value='';
}

function clearGENeuro()
{
  document.ext1_form.elements['ee1_ge_neu_ao'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_cn'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_cn_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_bicr'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_bicr_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_bicl'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_bicl_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_trir'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_trir_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_tril'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_tril_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_brar'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_brar_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_bral'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_bral_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_patr'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_patr_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_patl'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_patl_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_achr'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_achr_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_achl'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_achl_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_pup'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_plow'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_dup'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_dlow'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_str_nt'].value='';
  document.ext1_form.elements['ee1_ge_neu_sense'].value='';
}

function clearGEMusc()
{
  document.ext1_form.elements['ee1_ms_nt'].value='';
}

function clearGEExt()
{
  document.ext1_form.elements['ee1_ge_ext_edema'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_edema_chc'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_edema_nt'].value='';
  document.ext1_form.elements['ee1_ge_ext_pls_rad'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_pls_dors'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_pls_post'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_pls_pop'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_pls_fem'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_refill'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_club'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_club_nt'].value='';
  document.ext1_form.elements['ee1_ge_ext_cyan'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_ext_cyan_nt'].value='';
  document.ext1_form.elements['ee1_ge_ext_nt'].value='';
}

function clearGEDia()
{
  document.ext1_form.elements['ee1_ge_db_prop'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_db_prop_nt'].value='';
  document.ext1_form.elements['ee1_ge_db_vib'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_db_vib_nt'].value='';
  document.ext1_form.elements['ee1_ge_db_sens'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_db_sens_nt'].value='';
  document.ext1_form.elements['ee1_ge_db_nt'].value='';
}

function clearGETestes()
{
  document.ext1_form.elements['ee1_ge_te_cir'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_te_cir_nt'].value='';
  document.ext1_form.elements['ee1_ge_te_les'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_te_les_nt'].value='';
  document.ext1_form.elements['ee1_ge_te_dis'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_te_dis_nt'].value='';
  document.ext1_form.elements['ee1_ge_te_size'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_te_size_nt'].value='';
  document.ext1_form.elements['ee1_ge_te_palp'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_te_palp_nt'].value='';
  document.ext1_form.elements['ee1_ge_te_mass'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_te_mass_nt'].value='';
  document.ext1_form.elements['ee1_ge_te_tend'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_te_tend_nt'].value='';
  document.ext1_form.elements['ee1_ge_te_ery'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_te_ery_nt'].value='';
  document.ext1_form.elements['ee1_ge_te_nt'].value='';
}

function clearGERectal()
{
  document.ext1_form.elements['ee1_ge_rc_tone'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_rc_tone_nt'].value='';
  document.ext1_form.elements['ee1_ge_rc_ext'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_rc_ext_nt'].value='';
  document.ext1_form.elements['ee1_ge_rc_pro'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_rc_pro_nt'].value='';
  document.ext1_form.elements['ee1_ge_rc_bog'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_rc_bog_nt'].value='';
  document.ext1_form.elements['ee1_ge_rc_hard'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_rc_hard_nt'].value='';
  document.ext1_form.elements['ee1_ge_rc_mass'].selectedIndex='0';
	document.ext1_form.elements['ee1_ge_rc_mass_nt'].value='';
	document.ext1_form.elements['ee1_ge_rc_tend'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_rc_tend_nt'].value='';
	document.ext1_form.elements['ee1_ge_rc_color'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_rc_color_nt'].value='';
  document.ext1_form.elements['ee1_ge_rc_nt'].value='';
}

function clearGESkin()
{
  document.ext1_form.elements['ee1_ge_skin_nt'].value='';
}

function clearGEPsych()
{
  document.ext1_form.elements['ee1_ge_psych_judge'].checked=false;
  document.ext1_form.elements['ee1_ge_psych_judge_nt'].value='';
  document.ext1_form.elements['ee1_ge_psych_orient'].checked=false;
  document.ext1_form.elements['ee1_ge_psych_orient_nt'].value='';
  document.ext1_form.elements['ee1_ge_psych_memory'].checked=false;
  document.ext1_form.elements['ee1_ge_psych_memory_nt'].value='';
  document.ext1_form.elements['ee1_ge_psych_mood'].checked=false;
  document.ext1_form.elements['ee1_ge_psych_mood_nt'].value='';
  document.ext1_form.elements['ee1_ge_psych_nt'].value='';
}

function setGEGeneralNormal()
{
  document.ext1_form.elements['ee1_ge_gen_norm'].checked=true;
  document.ext1_form.elements['ee1_ge_gen_dev'].checked=true;
  document.ext1_form.elements['ee1_ge_gen_groom'].checked=true;
  document.ext1_form.elements['ee1_ge_gen_dis'].checked=true;
  document.ext1_form.elements['ee1_ge_gen_jaun'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_gen_waste'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_gen_sleep'].selectedIndex='1';
}

function setGEHeadNormal()
{
  document.ext1_form.elements['ee1_ge_hd_atra'].checked=true;
  document.ext1_form.elements['ee1_ge_hd_norm'].checked=true;
}

function setGEEyesNormal()
{
  document.ext1_form.elements['ee1_ge_eye_hem'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_eye_exu'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_eye_av'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_eye_pap'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_eyer_norm'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_eyer_scleral'].checked=true;
  document.ext1_form.elements['ee1_ge_eyer_eomi'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_eyer_perrl'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_eyel_norm'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_eyel_scleral'].checked=true;
  document.ext1_form.elements['ee1_ge_eyel_eomi'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_eyel_perrl'].selectedIndex='1';
}

function setGEEarsNormal()
{
  document.ext1_form.elements['ee1_ge_earr_clear'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_earr_perf'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_earr_ret'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_earr_pus'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_earr_ceru'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_earl_clear'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_earl_perf'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_earl_ret'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_earl_pus'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_earl_ceru'].selectedIndex='2';
}

function setGENoseNormal()
{
  document.ext1_form.elements['ee1_ge_nose_ery'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_nose_swell'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_nose_pall'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_nose_polps'].selectedIndex='2';
}

function setGEMouthNormal()
{
  document.ext1_form.elements['ee1_ge_mouth_moist'].checked=true;
}

function setGEThroatNormal()
{
  document.ext1_form.elements['ee1_ge_thrt_ery'].checked=true;
  document.ext1_form.elements['ee1_ge_thrt_exu'].checked=true;
}

function setGENeckNormal()
{
  document.ext1_form.elements['ee1_ge_nk_sup'].checked=true;
  document.ext1_form.elements['ee1_ge_nk_trach'].checked=true;
}

function setGEThyroidNormal()
{
  document.ext1_form.elements['ee1_ge_thy_norm'].checked=true;
  document.ext1_form.elements['ee1_ge_thy_nod'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_thy_brit'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_thy_tnd'].selectedIndex='2';
}

function setGECardioNormal()
{
  document.ext1_form.elements['ee1_ge_cr_norm'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_cr_mur'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_cr_gall'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_cr_click'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_cr_rubs'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_cr_extra'].selectedIndex='2';
}

function setGEPulmoNormal()
{
  document.ext1_form.elements['ee1_ge_pul_clear'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_pul_rales'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_pul_whz'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_pul_ron'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_pul_dec'].selectedIndex='2';
}

function setGEGastroNormal()
{
  document.ext1_form.elements['ee1_ge_gi_soft'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_gi_tend'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_gi_dis'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_gi_scar'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_gi_hern'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_gi_bowel'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_gi_hepa'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_gi_spleno'].selectedIndex='2';
}

function setGENeuroNormal()
{
  document.ext1_form.elements['ee1_ge_neu_ao'].selectedIndex='3';
  document.ext1_form.elements['ee1_ge_neu_cn'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_neu_bicr'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_bicl'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_trir'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_tril'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_brar'].selectedIndex='3';
  document.ext1_form.elements['ee1_ge_neu_bral'].selectedIndex='3';
  document.ext1_form.elements['ee1_ge_neu_patr'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_patl'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_achr'].selectedIndex='0';
  document.ext1_form.elements['ee1_ge_neu_achl'].selectedIndex='0';
}

function setGEExtNormal()
{
  document.ext1_form.elements['ee1_ge_ext_edema'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_ext_refill'].selectedIndex='1';
  document.ext1_form.elements['ee1_ge_ext_club'].selectedIndex='2';
  document.ext1_form.elements['ee1_ge_ext_cyan'].selectedIndex='2';
}

function setGEPsychNormal()
{
  document.ext1_form.elements['ee1_ge_psych_judge'].checked=true;
  document.ext1_form.elements['ee1_ge_psych_orient'].checked=true;
  document.ext1_form.elements['ee1_ge_psych_memory'].checked=true;
  document.ext1_form.elements['ee1_ge_psych_mood'].checked=true;
}
