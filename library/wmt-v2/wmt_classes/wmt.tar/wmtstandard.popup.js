
function ScrollHere(target)
{
	var scroll_target = document.getElementById(target);
	scroll_target.scrollIntoView();
}

function togglePanel(divid,imgid1,imgid2,barid)
{
  var numargs=arguments.length;
  if(document.getElementById(divid).style.display == 'none') {
    document.getElementById(divid).style.display = 'block';
    document.getElementById(imgid1).src = '../../../library/wmt/fill-090.png';
    document.getElementById(imgid2).src = '../../../library/wmt/fill-090.png';
    document.getElementById(barid).style.borderBottom = 'solid 1px black';
		if(numargs >= 7) {
    	document.getElementById(arguments[6]).src = '../../../library/wmt/fill-090.png';
		}
		if(numargs >= 8) {
    	document.getElementById(arguments[7]).src = '../../../library/wmt/fill-090.png';
		}
		if(numargs >= 9) {
    	document.getElementById(arguments[8]).style.borderTop= 'solid 1px black';
		}
  } else {
    document.getElementById(divid).style.display = 'none';
    document.getElementById(imgid1).src = '../../../library/wmt/fill-270.png';
    document.getElementById(imgid2).src = '../../../library/wmt/fill-270.png';
    document.getElementById(barid).style.borderBottom = 'none';
		if(numargs >= 7) {
    	document.getElementById(arguments[6]).src = '../../../library/wmt/fill-270.png';
		}
		if(numargs >= 8) {
    	document.getElementById(arguments[7]).src = '../../../library/wmt/fill-270.png';
		}
		if(numargs >= 9) {
    	document.getElementById(arguments[8]).style.borderTop= 'solid 1px black';
		}
    if(barid == 'GEAllergyCollapseBar') {
      document.getElementById(barid).style.borderBottom = 'solid 1px black';
    }
    if(barid == 'GEMedsCollapseBar') {
      document.getElementById(barid).style.borderBottom = 'solid 1px black';
    }
    if(barid == 'DBAllergyCollapseBar') {
      document.getElementById(barid).style.borderBottom = 'solid 1px black';
    }
    if(barid == 'DBMedsCollapseBar') {
      document.getElementById(barid).style.borderBottom = 'solid 1px black';
    }
  }
  // This sets the bottom border of the bar for special boxes
  if(numargs >= 5) {
    if(arguments[4] == 'line') {
      document.getElementById(barid).style.borderBottom = 'solid 1px black';
    }
  }
  if(numargs >= 6) {
		var mode_id=arguments[5];
		// alert("Mode Element: "+mode_id);
    document.getElementById(mode_id).value = 
														document.getElementById(divid).style.display;
		// alert("Element Value: "+document.getElementById(mode_id).value);
  }
}

function TogglePair(ChkBox, UnBox)
{
  if(document.getElementById(ChkBox).checked == true) {
    document.getElementById(UnBox).checked = false;
  }
}

function VerifyYesChecks(YesBox, NoBox)
{
  if(document.getElementById(YesBox).checked == true) {
    document.getElementById(NoBox).checked = false;
  }
}

function VerifyNoChecks(YesBox, NoBox)
{
  if(document.getElementById(NoBox).checked == true) {
    document.getElementById(YesBox).checked = false;
  }
}

function VerifyYesFirstCheck()
{
  var numargs=arguments.length;
  // The First Item is the Yes Box
  if(document.getElementById(arguments[0]).checked == false) return(1);
  for (var i = 1; i < numargs; i++) {
     document.getElementById(arguments[i]).checked = false;
  }
}

function UpdateBMI(height, weight, bmi, bmi_status)
{
  var tmp_bmi = '';
  var tmp_bmi_status = '';

  var ht = document.getElementById(height).value;
  ht = Math.round(ht * 100) / 100;
  ht = ht.toFixed(2);
  document.getElementById(height).value = ht;

  var wt = document.getElementById(weight).value;
  wt = Math.round(wt * 100) / 100;
  wt = wt.toFixed(2);
  document.getElementById(weight).value = wt;

  if((wt <= 0) || (ht <= 0)) {
    document.getElementById(bmi).value = '';
    document.getElementById(bmi_status).value = '';
    return false;
  }

  tmp_bmi = ((wt/ht/ht) * 703);
  tmp_bmi = Math.round(tmp_bmi * 10) / 10;
  tmp_bmi = tmp_bmi.toFixed(1);
  if(tmp_bmi > 42) {
    tmp_bmi_status = 'Obesity III';
  } else if (tmp_bmi > 34) {
    tmp_bmi_status = 'Obesity II';
  } else if (tmp_bmi > 30) {
    tmp_bmi_status = 'Obesity I';
  } else if (tmp_bmi > 27) {
    tmp_bmi_status = 'Overweight';
  } else if (tmp_bmi > 25) {
    tmp_bmi_status = 'Normal BL';
  } else if (tmp_bmi > 18.5) {
    tmp_bmi_status = 'Normal';
  } else if (tmp_bmi) {
    tmp_bmi_status = 'Underweight';
  }
  if( tmp_bmi ) {
    document.getElementById(bmi).value = tmp_bmi;
    document.getElementById(bmi_status).value = tmp_bmi_status;
  }
}

function NoDecimal(thisField)
{
  var tmp = document.getElementById(thisField).value;
  tmp = Math.round(tmp);
  if(tmp == '0') tmp='';
  document.getElementById(thisField).value = tmp;
}

function OneDecimal(thisField)
{
  var tmp = document.getElementById(thisField).value;
  tmp = Math.round(tmp * 10) / 10;
  tmp = tmp.toFixed(1);
  if(tmp == '0.0') tmp='';
  document.getElementById(thisField).value = tmp;
}

function TwoDecimal(thisField)
{
  var tmp = document.getElementById(thisField).value;
  tmp = Math.round(tmp * 100) / 100;
  tmp = tmp.toFixed(2);
  if(tmp == '0.00') tmp='';
  document.getElementById(thisField).value = tmp;
}

function CalcPatAge(thisDate, thisAge)
{
  var dob = document.getElementById(thisDate).value;
  var age = document.getElementById(thisAge).value;
  if(age > 0) {
    return true;
  }
  dob = new Date(dob);  
  if(dob == 'Invalid Date') {
    alert("Not a Valid Date - use 'YYYY-MM-DD'");
    return false;
  }
  var Cdate = new Date;
  var age = Math.floor((( Cdate - dob) /1000 /(60*60*24)) / 365.25 );
  document.getElementById(thisAge).value = age;
  return true;
}

function TimeStamp(thisDate)
{
  var currentTime=new Date();
  var myStamp= currentTime.getFullYear();
  var myMonth= "00" + (currentTime.getMonth()+1);
  myMonth= myMonth.slice(-2);
  var myDays= "00" + currentTime.getDate();
  myDays= myDays.slice(-2);
  var myHours= "00" + currentTime.getHours();
  myHours= myHours.slice(-2);
  var myMinutes= "00" + currentTime.getMinutes();
  myMinutes= myMinutes.slice(-2);
  var mySeconds= "00" + currentTime.getSeconds();
  mySeconds= mySeconds.slice(-2);
  myStamp= myStamp + "-" + myMonth + "-" + myDays + " " + myHours + ":" +
           myMinutes + ":" + mySeconds;

  document.getElementById(thisDate).value = myStamp;
}

function SetDatetoToday(thisDate)
{
  var currentTime=new Date();
  var myStamp= currentTime.getFullYear();
  var myMonth= "00" + (currentTime.getMonth()+1);
  myMonth= myMonth.slice(-2);
  var myDays= "00" + currentTime.getDate();
  myDays= myDays.slice(-2);
  myStamp= myStamp + "-" + myMonth + "-" + myDays;

  document.getElementById(thisDate).value = myStamp;
}

function ClearThisField(thisField)
{
  if(thisField) {
    document.getElementById(thisField).value= '';
  }
}

function ShortTimeStamp(thisDate)
{
	var numargs=arguments.length;
  var currentTime=new Date();
  var myHours= "00" + currentTime.getHours();
  myHours= myHours.slice(-2);
  var myMinutes= "00" + currentTime.getMinutes();
  myMinutes= myMinutes.slice(-2);
  var myStamp=  myHours + ":" + myMinutes;

  document.getElementById(thisDate).value = myStamp;
	if(numargs >= 2) {
		// alert("In the change: "+arguments[1]);
  	document.getElementById(arguments[1]).value = myStamp;
	}
}

function GetShortTimeStamp()
{
  var currentTime=new Date();
  var myHours= "00" + currentTime.getHours();
  myHours= myHours.slice(-2);
  var myMinutes= "00" + currentTime.getMinutes();
  myMinutes= myMinutes.slice(-2);
  var myStamp=  myHours + ":" + myMinutes;
	return myStamp;

}

function CalcShortDiff(start, end, target)
{
	var startTime= document.getElementById(start).value;
	var endTime= document.getElementById(end).value;
	var endMinute= parseInt(endTime.slice(-2));
	var endHour= parseInt(endTime.slice(0,2));
	var startMinute= parseInt(startTime.slice(-2));
	var startHour= parseInt(startTime.slice(0,2));
	// alert(startHour+'  '+startMinute+'  -  '+endHour+'  '+endMinute);
	if(isNaN(endHour) || isNaN(endMinute) || isNaN(startHour) || isNaN(startMinute)) return false;
	var endTotal= parseInt((endHour * 60) + endMinute);
	var startTotal= parseInt((startHour * 60) + startMinute);
	// alert(endTotal+'  ::  '+startTotal);
	var len= parseInt(endTotal - startTotal);
	if(isNaN(len)) return false;
	document.getElementById(target).value= len;
}

//
// These are the functions that support all the inner-block 'Windows'
//
function SubmitSurgery(base,wrap,formID)
{
  document.forms[0].action=base+'&mode=surg&wrap='+wrap;
	if(formID != '' && formID != 0 && formID != null) {
  	document.forms[0].action=base+'&mode=surg&wrap='+wrap+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdateSurgery(base,wrap,itemID,formID) {
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Surgery ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('ps_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updatesurg&wrap='+wrap+'&itemID='+itemID;
	if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=updatesurg&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UnlinkSurgery(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Surgery ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('ps_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinksurg&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinksurg&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function DeleteSurgery(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Past Surgery ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('ps_id_'+itemID).value;
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid Past Surgery entry...Aborting");
		return false;
	}
	var warn="Delete This Past Surgery Entry?\n\nThis Action CAN NOT Be Reversed!";
	var numargs= arguments.length;
	if(numargs > 4) {
		var num_links = arguments[4];
		if(num_links > 0) {
			warn=" ** WARNING ** This Entry Is Attached to ["+num_links+
				"] Encounter(s)\n\nAre You Sure You Want To Delete This Past "+
				"Surgery Entry?\n\n                This Action Can NOT Be Reversed!";
		}
	}
	if(confirm(warn)) {
  	document.forms[0].action=base+'&mode=delsurg&wrap='+wrap+'&itemID='+itemID;
		if(formID != '' && formID != 0 && formID != null) {
  		document.forms[0].action=base+'&mode=delsurg&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
		}
		document.forms[0].submit();
	}
	return false;
}

function SubmitHospitalization(base,wrap,formID)
{
  document.forms[0].action=base+'&mode=hosp&wrap='+wrap;
	if(formID != '' && formID != 0 && formID != null) {
  	document.forms[0].action=base+'&mode=hosp&wrap='+wrap+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdateHospitalization(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Admittance ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('hosp_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updatehosp&wrap='+wrap+'&itemID='+itemID;
	if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=updatehosp&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function DeleteHospitalization(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Prior Admission ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('hosp_id_'+itemID).value;
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid Prior Admission entry...Aborting");
		return false;
	}
	var warn="Delete This Prior Admission?\n\nThis Action CAN NOT Be Reversed!";
	var numargs= arguments.length;
	if(numargs > 4) {
		var num_links = arguments[4];
		if(num_links > 0) {
			warn=" ** WARNING ** This Entry Is Attached to ["+num_links+
				"] Encounter(s)\n\nAre You Sure You Want To Delete This Prior "+
				"Admission?\n\n                This Action Can NOT Be Reversed!";
		}
	}
	if(confirm(warn)) {
  	document.forms[0].action=base+'&mode=delhosp&wrap='+wrap+'&itemID='+itemID;
		if(formID != '' && formID != 0 && formID != null) {
  		document.forms[0].action=base+'&mode=delhosp&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
		}
		document.forms[0].submit();
	}
	return false;
}

function UnlinkHospitalization(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Admission ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('hosp_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkhosp&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkhosp&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function SubmitMedicalHistory(base,wrap,formID)
{
  document.forms[0].action=base+'&mode=pmh&wrap='+wrap;
  if(formID != '' && formID != 0) {
 		document.forms[0].action=base+'&mode=pmh&wrap='+wrap+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdateMedicalHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Medical History ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('pmh_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid Medical History entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updatepmh&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=updatepmh&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function DeleteMedicalHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Medical History ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('pmh_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid Medical History entry...Aborting");
		return false;
	}
	var warn="Delete This Medical History Entry?\n\nThis Action CAN NOT Be Reversed!";
	var numargs= arguments.length;
	if(numargs > 4) {
		var num_links = arguments[4];
		if(num_links > 0) {
			warn="  ** WARNING ** This Entry Is Attached to ["+num_links+
				"] Encounter(s)\n\nAre You Sure You Want To Delete This Medical "+
				"History Entry?\n\n                This Action Can NOT Be Reversed!";
		}
	}
	if(confirm(warn)) {
  	document.forms[0].action=base+'&mode=delpmh&wrap='+wrap+'&itemID='+itemID;
  	if(formID != '' && formID != 0 && formID != null) {
  		document.forms[0].action=base+'&mode=delpmh&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
		}
		document.forms[0].submit();
	}
	return false;
}

function UnlinkMedicalHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Medical History ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('pmh_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkpmh&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkpmh&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function SubmitImageHistory(base,wrap,formID)
{
  document.forms[0].action=base+'&mode=img&wrap='+wrap;
  if(formID != '' && formID != 0) {
 		document.forms[0].action=base+'&mode=img&wrap='+wrap+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdateImageHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Image History ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('img_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updateimg&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=updateimg&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UnlinkImageHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Image History ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('img_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkimg&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkimg&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function DeleteImageHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Image History ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('img_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid Image History entry...Aborting");
		return false;
	}
	var warn="Delete This Image History Entry?\n\nThis Action CAN NOT Be Reversed!";
	var numargs= arguments.length;
	if(numargs > 4) {
		var num_links = arguments[4];
		if(num_links > 0) {
			warn="  ** WARNING ** This Entry Is Attached to ["+num_links+
				"] Encounter(s)\n\nAre You Sure You Want To Delete This Image "+
				"History Entry?\n\n                This Action Can NOT Be Reversed!";
		}
	}
	if(confirm(warn)) {
  	document.forms[0].action=base+'&mode=delimg&wrap='+wrap+'&itemID='+itemID;
  	if(formID != '' && formID != 0 && formID != null) {
  		document.forms[0].action=base+'&mode=delimg&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
		}
		document.forms[0].submit();
	}
	return false;
}

function SubmitFamilyHistory(base,wrap,formID)
{
  document.forms[0].action=base+'&mode=fh&wrap='+wrap;
  if(formID != '' && formID != 0 && formID != null) {
  	document.forms[0].action=base+'&mode=fh&wrap='+wrap+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdateFamilyHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Family History ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('fh_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid Family History entry...Aborting");
		return false;
	}
	document.forms[0].action=base+'&mode=updatefh&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0 && formID != null) {
		document.forms[0].action=base+'&mode=updatefh&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function DeleteFamilyHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Family History ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('fh_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid Family History entry...Aborting");
		return false;
	}
	var warn="Delete This Family History Entry?\n\nThis Action CAN NOT Be Reversed!";
	var numargs= arguments.length;
	if(numargs > 4) {
		var num_links = arguments[4];
		if(num_links > 0) {
			warn="  ** WARNING ** This Entry Is Attached to ["+num_links+
				"] Encounter(s)\n\nAre You Sure You Want To Delete This Family "+
				"History Entry?\n\n                This Action Can NOT Be Reversed!";
		}
	}
	if(confirm(warn)) {
  	document.forms[0].action=base+'&mode=delfh&wrap='+wrap+'&itemID='+itemID;
  	if(formID != '' && formID != 0 && formID != null) {
  		document.forms[0].action=base+'&mode=delfh&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
		}
		document.forms[0].submit();
	}
	return false;
}

function UnlinkFamilyHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Family History ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('fh_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkfh&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkfh&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function ToggleDiagWindowMode(base,wrap,formID,mode)
{
  document.forms[0].action=base+'&mode=window&disp='+mode+'&wrap='+wrap;
 	if(formID != '' && formID != 0 && formID != null) {
  	document.forms[0].action=base+'&mode=window&disp='+mode+'&wrap='+wrap+'&id='+formID;
	}
	document.forms[0].submit();
}

function AddDiagnosis(base,wrap,formID)
{
  document.forms[0].action=base+'&mode=diag&wrap='+wrap;
 	if(formID != '' && formID != 0 && formID != null) {
  	document.forms[0].action=base+'&mode=diag&wrap='+wrap+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdateDiagnosis(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Diagnosis ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('dg_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
	document.forms[0].action=base+'&mode=updatediag&wrap='+wrap+'&itemID='+itemID;
 	if(formID != '' && formID != 0 && formID != null) {
		document.forms[0].action=base+'&mode=updatediag&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function DeleteDiagnosis(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Diagnosis ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('dg_id_'+itemID).value;
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
	if(confirm("      Delete This Diagnosis?\n\nThis Action Can Not Be Reversed!")) {

  	document.forms[0].action=base+'&mode=deldiag&wrap='+wrap+'&itemID='+itemID;
 		if(formID != '' && formID != 0 && formID != null) {
  		document.forms[0].action=base+'&mode=deldiag&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
		}
		document.forms[0].submit();
	}
}

function UnlinkDiagnosis(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Diagnosis ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('dg_id_'+itemID).value;
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkdiag&wrap='+wrap+'&itemID='+itemID;
 	if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=unlinkdiag&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function LinkDiagnosis(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Diagnosis ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('dg_id_'+itemID).value;
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=linkdiag&wrap='+wrap+'&itemID='+itemID;
 	if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=linkdiag&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdatePrescription(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Prescription ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('med_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updatemed&wrap='+wrap+'&itemID='+itemID;
	if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=updatemed&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UnlinkPrescription(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Prescription ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('med_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkmed&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkmed&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdatePrescriptionHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Prescription ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('med_hist_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updatemedhist&wrap='+wrap+'&itemID='+itemID;
	if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=updatemedhist&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UnlinkPrescriptionHistory(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Prescription ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('med_hist_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkmedhist&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkmedhist&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdateMedication(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Medication ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('med_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updatemed&wrap='+wrap+'&itemID='+itemID;
	if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=updatemed&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UnlinkMedication(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Medication ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('med_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkmed&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkmed&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function SubmitAllergy(base,wrap,formID)
{
  document.forms[0].action=base+'&mode=all&wrap='+wrap;
	if(formID != '' && formID != 0) {
  	document.forms[0].action=base+'&mode=all&wrap='+wrap+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdateAllergy(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Allergy ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('all_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updateall&wrap='+wrap+'&itemID='+itemID;
	if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=updateall&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UnlinkAllergy(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Allergy ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('all_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkall&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkall&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function SubmitFavorite(base,wrap,itemID,formID,code_field,plan_field)
{
	var plan = document.forms[0].elements[plan_field].value;
	if(!plan || plan == '') {
		alert("Why would you want to save an empty plan?");
		return false;
	}
	var pcode = document.forms[0].elements[code_field].value;
	if(!pcode || pcode == '') {
		alert("There is no code to attach this plan to - NOT Saving");
		return false;
	}
	alert("Plan Saved as a Favorite");
  document.forms[0].action=base+'&mode=fav&wrap='+wrap;
	if(itemID != '' && itemID != 0) {
  	document.forms[0].action=base+'&mode=fav&wrap='+wrap+'&itemID='+itemID;
	}
  if(formID != '' && formID != 0) {
 		document.forms[0].action=document.forms[0].action+'&id='+formID;
	}
	// alert("Action: "+document.forms[0].action);
	document.forms[0].submit();
}

function SubmitPastPregnancy(base,wrap,formID)
{
  document.forms[0].action=base+'&mode=pp&wrap='+wrap;
	if(formID != '' && formID != 0) {
  	document.forms[0].action=base+'&mode=pp&wrap='+wrap+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdatePastPregnancy(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Past Pregnancy ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('pp_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updatepp&wrap='+wrap+'&itemID='+itemID;
	if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=updatepp&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UnlinkPastPregnancy(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Past Pregnancy ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('pp_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkpp&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkpp&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UpdateImmunization(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Immunization ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('imm_id_'+itemID).value;
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=updateimm&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0 && formID != null) {
 		document.forms[0].action=base+'&mode=updateimm&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function UnlinkImmunization(base,wrap,itemID,formID)
{
  if(itemID == '' || itemID == 0 || isNaN(itemID)) {
		alert("No Valid Immunization ID Was Found...Aborting!!");
		return false;
	}
	var test=document.getElementById('imm_id_'+itemID);
	if(test == '' || test == null) {
		alert("ID <"+itemID+"> is not a valid list entry...Aborting");
		return false;
	}
 	document.forms[0].action=base+'&mode=unlinkimm&wrap='+wrap+'&itemID='+itemID;
  if(formID != '' && formID != 0) {
 	document.forms[0].action=base+'&mode=unlinkimm&wrap='+wrap+'&itemID='+itemID+'&id='+formID;
	}
	document.forms[0].submit();
}

function AdjustFocus(here)
{
	document.forms[0].elements[here].focus();
}

function ExitCheckPopup(here)
{
	var url=document.forms[0].elements[here].value;
	alert("Url: "+url);
	if(confirm("Exit Without Saving...Are You Sure?")) {
		top.restoreSession();
		window.location=url;
		return true;
	} else {
		return false;
	}
}

function VerifyApproveForm(here)
{
	var flag= true
  if(arguments.length > 1) {
		flag=arguments[1];
	}
	if(flag == 0) return(true);
	var mode=document.forms[0].elements[here].value;
	if(mode == 'a') {
		if(!confirm("Approving the form will render it completely un-editable and is not reversible.\n\nAre you sure you are ready to do this?")) {
			document.forms[0].elements[here].value='c';
			document.forms[0].elements[here].selectedIndex=2;
		}
	}
	return true;
}

function setEmptyDate(testDate)
{
	if(document.getElementById(testDate).value == '') {
		SetDatetoToday(testDate);
	}
}

function setEmptyTo(thisField, thisVal)
{
	if(document.getElementById(thisField).value == '') {
		document.getElementById(thisField).value = thisVal;
	}
}

function SyncContent(thisField,matchField)
{
	var my_val = document.getElementById(thisField).value;
	var cur_val = document.getElementById(matchField).value;
	document.getElementById(matchField).value = my_val;
}
