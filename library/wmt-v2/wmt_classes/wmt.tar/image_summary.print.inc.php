<?php
if(isset($img) && (count($img) > 0)) {
	echo "<div class='wmtPrnMainContainer'>\n";
	echo "  <div class='wmtPrnCollapseBar'>\n";
	echo "    <span class='wmtPrnChapter'>Images</span>\n";
	echo "  </div>\n";
	echo "  <div class='wmtPrnCollapseBox'>\n";
	echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
	echo "		<tr>\n";
	echo "			<td class='wmtPrnLabelCenterBorderB' style='width: 90px'>Date</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB'>Type</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB'>Notes</td>\n";
	echo "		</tr>\n";
	foreach($img as $prev) {
		echo "<tr>\n";
		echo "	<td class='wmtPrnBodyBorderB'>",$prev['img_dt'],"&nbsp;</td>\n";
		echo "	<td class='wmtPrnBodyBorderLB'>",ListLook($prev['img_type'],'Image_Types'),"&nbsp;</td>\n";
		echo "	<td class='wmtPrnBodyBorderLB'>",$prev['img_nt'],"&nbsp;</td>\n";
		echo "</tr>\n";
	}
	echo "		</table>\n";
	echo "	</div>\n";
	echo "</div>\n";
}
?>
