<?php
/** **************************************************************************
 *	DASHBOARD.CLASS.PHP
 *	This file contains the standard classes for interacting with the          
 *	'Dashboard' which is a Williams Medical Technologies option for OpenEMR.  
 *	This class must be included for dashboard integration.
 *
 *  NOTES:
 *  1) __CONSTRUCT - always uses the record ID to retrieve data from the database
 *  2) GET - uses alternate selectors to find and return associated object
 *  3) FIND - returns only the object ID without data using alternate selectors
 *  4) LIST - returns an array of IDs meeting specific selector criteria
 *  5) FETCH - returns an array of data meeting specific criteria
 *   
 * 
 *  @package dashboard
 *  @version 1.0
 *  @copyright Williams Medical Technologies, Inc.
 *  @author Rich Genandt <rgenandt@gmail.com>
 * 
 *************************************************************************** */

/** 
 * Provides a partial representation of the patient data record. This object
 * does NOT include all of the fields associated with the core patient data
 * record and should NOT be used for database updates.  It is intended only
 * for retrieval of partial patient information primarily for display 
 * purposes (reports for example).
 *
 * @package WMT
 * @subpackage Standard
 * @category Patient
 * 
 */
class wmtDashboard {
	public $id;
	public $pid;
  public $db_form_dt;
	public $db_hpi;
	public $db_cc;
	public $db_last_colon;
	public $db_last_bone;
	public $db_last_chol;
	public $db_last_pap;
	public $db_last_mamm;
	public $db_last_ww;
	public $db_last_mp;
	public $db_age_men;
	public $db_last_rectal;
	public $db_last_psa;
	public $db_last_db_foot;
	public $db_last_db_eye;
	public $db_bc;
	public $db_sex_active;
	public $db_sex_act_nt;
	public $db_sex_nt;
	public $db_pflow;
	public $db_pflow_dur;
	public $db_pfreq;
	public $db_pfreq_days;
	public $db_pregnancies;
	public $db_deliveries;
	public $db_last_hpv;
	public $db_hcg;
	public $db_last_urine_alb;
	
	// generated values - none in use currently
	
	/**
	 * Constructor for the 'dashboard' class which retrieves the requested 
	 * dashboard information from the database or creates an empty object.
	 * 
	 * @param int $id dashboard record identifier
	 * @return object instance of dashboard class
	 */
	public function __construct($id = false) {
		if(!$id) return false;

		$query = "SELECT * FROM form_dashboard WHERE id =?";
		$results = sqlStatement($query, array($id));
	
		if ($data = sqlFetchArray($results)) {
			$this->id = $data['id'];
			$this->pid = $data['pid'];
      $this->db_form_dt = $data['db_form_dt'];
      $this->db_hpi = $data['db_hpi'];
      $this->db_cc = $data['db_cc'];
      $this->db_last_colon = $data['db_last_colon'];
      $this->db_last_bone = $data['db_last_bone'];
      $this->db_last_chol = $data['db_last_chol'];
      $this->db_last_pap = $data['db_last_pap'];
      $this->db_last_mamm = $data['db_last_mamm'];
      $this->db_last_ww = $data['db_last_ww'];
      $this->db_last_mp = $data['db_last_mp'];
      $this->db_age_men = $data['db_age_men'];
      $this->db_last_rectal = $data['db_last_rectal'];
      $this->db_last_psa = $data['db_last_psa'];
      $this->db_last_db_foot = $data['db_last_db_foot'];
      $this->db_last_db_eye = $data['db_last_db_eye'];
			$this->db_bc = $data['db_bc'];
			$this->db_sex_active = $data['db_sex_active'];
			$this->db_sex_act_nt = $data['db_sex_act_nt'];
			$this->db_sex_nt = $data['db_sex_nt'];
			$this->db_pflow = $data['db_pflow'];
			$this->db_pflow_dur = $data['db_pflow_dur'];
			$this->db_pfreq = $data['db_pfreq'];
			$this->db_pfreq_days = $data['db_pfreq_days'];
			$this->db_pregnancies = $data['db_pregnancies'];
			$this->db_deliveries = $data['db_deliveries'];
      $this->db_last_hpv = $data['db_last_hpv'];
      $this->db_hcg = $data['db_hcg'];
      $this->db_last_urine_alb= $data['db_last_urine_alb'];

		}
		else {
			throw new Exception('wmtDashboard::_construct - no dashboard record with id ('.$this->id.').');
		}
		
		// preformat commonly used data elements
		
	}	

	/**
	 * Retrieve a dashboard object by PID value. Uses the base constructor 
   * for the 'dashboard' class to create and return the object.  Since only 
   * one dashboard is allowed per patient we will create a blank one if 
   * nothing is found.	 
	 * 
	 * @static
	 * @param int $pid patient record pid
	 * @return object instance of patient class
	 */
	public static function getPidDashboard($pid) {
		if(!$pid) {
			throw new Exception('wmtDashboard::getPidDashboard - no patient identifier provided.');
		}
		
		$results = sqlStatement("SELECT id FROM form_dashboard WHERE pid =?",
			 array($pid));
		$data = sqlFetchArray($results);
		$parms=array($pid, $_SESSION['authUser'], $_SESSION['authProvider']);
		if(!$data['id']) {
			$data['id'] = sqlInsert("INSERT INTO form_dashboard SET " .
			"date = NOW(), pid = ?, user = ?, groupname = ?", $parms);
    }
		return new wmtDashboard($data['id']);
	}
	
  /**
 * Updates the dashboard information in the database.
 * 
 * @static
 * @param Errors $iderror_object
 * @return null
 */
	public function update() {
			
		$sql = "UPDATE form_dashboard SET date = NOW()" .
 			", user = '".$_SESSION['authUser']."'" .
			", groupname = '".$_SESSION['authProvider']."'" .
			", activity = 1";
			$sql .= ($this->db_form_dt) ? ", db_form_dt = '$this->db_form_dt'" : "";
			$sql .= ($this->db_hpi) ? ", db_hpi = '$this->db_hpi'" : "";
			$sql .= ($this->db_cc) ? ", db_cc = '$this->db_cc'" : "";
      $sql .= ($this->db_last_colon) ? ", db_last_colon = '$this->db_last_colon'" : "";
      $sql .= ($this->db_last_bone) ? ", db_last_bone = '$this->db_last_bone'" : "";
      $sql .= ($this->db_last_chol) ? ", db_last_chol = '$this->db_last_chol'" : "";
      $sql .= ($this->db_last_pap) ? ", db_last_pap = '$this->db_last_pap'" : "";
      $sql .= ($this->db_last_mamm) ? ", db_last_mamm = '$this->db_last_mamm'" : "";
      $sql .= ($this->db_last_ww) ? ", db_last_ww = '$this->db_last_ww'" : "";
      $sql .= ($this->db_last_mp) ? ", db_last_mp = '$this->db_last_mp'" : "";
      $sql .= ($this->db_age_men) ? ", db_age_men = '$this->db_age_men'" : "";
      $sql .= ($this->db_last_rectal) ? ", db_last_rectal = '$this->db_last_rectal'" : "";
      $sql .= ($this->db_last_psa) ? ", db_last_psa = '$this->db_last_psa'" : "";
      $sql .= ($this->db_last_db_foot) ? ", db_last_db_foot= '$this->db_last_db_foot'" : "";
      $sql .= ($this->db_last_db_eye) ? ", db_last_db_eye = '$this->db_last_db_eye'" : "";
			$sql .= ($this->db_bc) ? ", db_bc = '$this->db_bc'" : "";
			$sql .= ($this->db_sex_active) ? ", db_sex_active = '$this->db_sex_active'" : "";
			$sql .= ($this->db_sex_act_nt) ? ", db_sex_act_nt = '$this->db_sex_act_nt'" : "";
			$sql .= ($this->db_sex_nt) ? ", db_sex_nt = '$this->db_sex_nt'" : "";
			$sql .= ($this->db_pflow) ? ", db_pflow = '$this->db_pflow'" : "";
			$sql .= ($this->db_pflow_dur) ? ", db_pflow_dur = '$this->db_pflow_dur'" : "";
			$sql .= ($this->db_pfreq) ? ", db_pfreq = '$this->db_pfreq'" : "";
			$sql .= ($this->db_pfreq_days) ? ", db_pfreq_days = '$this->db_pfreq_days'" : "";
      $sql .= ($this->db_last_hpv) ? ", db_last_hpv = '$this->db_last_hpv'" : "";
			$sql .= ($this->db_pregnancies) ? ", db_pregnancies= '$this->db_pregnancies'" : "";
			$sql .= ($this->db_deliveries) ? ", db_deliveries= '$this->db_deliveries'" : "";
			$sql .= ($this->db_hcg) ? ", db_hcg= '$this->db_hcg'" : "";
      $sql .= ($this->db_last_urine_alb) ? ", db_last_urine_alb = '$this->db_last_urine_alb'" : "";
		$sql .= " WHERE id = $this->id ";
		sqlInsert($sql);
		return;
	}

	/**
	 * Inserts data from a dashboard object into the database.
	 * 
	 * @static
	 * @param Errors $iderror_object
	 * @return null
	 */
	public static function insert(wmtDashboard $object) {
		if($object->id) {
			throw new Exception("wmtDashboard::insert - object already contains identifier");
		}

		$object->id = sqlInsert("INSERT INTO form_dashboard SET " .
			"date = NOW(), " .
			"pid = '$object->pid', " .
			"user = '".$_SESSION['authUser']."', " .
			"groupname = '".$_SESSION['authProvider']."'");
		
		return $object->id;
	}

	/**
	 * Checks to see if we will update any dashboard fields, if so we will 
	 * also set the form date.
	 *
	 * @static
	 * @param - an array of fields indexed by dashboard field names
	 * @return - true if we need to update
	 */
	public static function change($values=array(),$object) {
		if(count($values) < 1) return false;
		$change = false;
		$flds = sqlListFields('form_dashboard');
		$flds = array_slice($flds,7);
		foreach($values as $key => $val) {
			if(in_array($key, $flds)) {
				if($val && ($val != 'YYYY-MM-DD') && ($val != $object->$key)) {
					$change = true;
					$object->$key = $val;
				}
			}
		}	
	}
}
                                            
?>
