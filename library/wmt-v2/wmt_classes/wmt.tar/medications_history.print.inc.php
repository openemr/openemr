<?php
$_print= false;
if(!isset($medh_note)) { $medh_note= ''; }
if((isset($med_hist) && (count($med_hist) > 0)) || $medh_note != '') { $_print= true; }
if($_print) {
	echo "<div class='wmtPrnMainContainer'>\n";
	echo "<div class='wmtPrnCollapseBar'>\n";
	echo "	<span class='wmtPrnChapter'>Medication History</span>\n";
	echo "</div>\n";
	echo "<div class='wmtPrnCollapseBox'>\n";
	echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
	if(isset($med_hist) && (count($med_hist) > 0)) {
		echo "	<tr>\n";
		echo "		<td class='wmtPrnLabelCenterBorderB' style='width: 95px'>Start Date</td>\n";
		echo "		<td class='wmtPrnLabelCenterBorderLB'>Medication</td>\n";
		echo "		<td class='wmtPrnLabelCenterBorderLB'>Quantity</td>\n";
		echo "		<td class='wmtPrnLabelCenterBorderLB'>Dosage</td>\n";
		echo "		<td class='wmtPrnLabelCenterBorderLB'>Sig</td>\n";
		echo "		<td class='wmtPrnLabelCenterBorderLB'>Comments</td>\n";
		echo "	</tr>\n";
		$cnt=1;
		foreach($med_hist as $prev) {
			$sig1=trim(ListLook($prev['route'],'drug_route'));
			if(!empty($sig1)) { $sig1=' by '.$sig1; }
			$sig2=trim(ListLook($prev['interval'],'drug_interval'));
			$sig1=$prev['dosage'].$sig1.' '.$sig2;
			$size=trim($prev['size']);
			$unit=trim(ListLook($prev['unit'],'drug_units'));
			$size.=$unit;
			echo "<tr>\n";
			echo "<td class='wmtPrnBodyBorderB'>".$prev['date_added']."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$prev['drug']."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$prev['quantity']."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$size."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$sig1."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$prev['note']."&nbsp;</td>\n";
			echo "</tr>\n";
			$cnt++;
			if($cnt > 10) { break; }
		}
	}
	if($medh_note != '') {
		echo "		<tr>\n";
		echo "			<td class='wmtPrnLabel' colspan='2'>Other Notes:</td>\n";
		echo "		</tr>\n";
		echo "		<tr>\n";
		echo "			<td colspan='6' class='wmtPrnBody'>$pmh_note</td>\n";
		echo "		</tr>\n";
	}
// } else {
	// echo "<tr>\n";
	// echo "<td class='wmtPrnLabelBorderB'>&nbsp;</td>\n";
	// echo "<td class='wmtPrnLabelBorderLB'>None on File</td>\n";
	// echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
	// echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
	// echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
	// echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
	// echo "</tr>\n";
	echo "</table>\n";
	echo "</div>\n";
	echo "</div>\n";
}
?>
