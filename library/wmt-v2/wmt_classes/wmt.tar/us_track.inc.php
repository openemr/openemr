<?php
if(!isset($pop_form)) { $pop_form=false; }
echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "		<tr>\n";
echo "			<td class='LabelCenterBorderB' style='width: 90px'>Date</td>\n";
echo "			<td class='LabelCenterBorderLB'>Type</td>\n";
echo "			<td class='LabelCenterBorderLB'>Notes</td>\n";
echo "			<td class='LabelCenterBorderLB' style='width: 90px'>Reviewed</td>\n";
if(acl_check('admin','super') && $unlink_allow) {
	echo "			<td class='LabelBorderLB' style='width: 175px'>&nbsp;</td>\n";
} else if($unlink_allow) {
	echo "			<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else if(acl_check('admin', 'super')) {
	echo "			<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else {
	echo "			<td class='LabelBorderLB' style='width: 65px'>&nbsp;</td>\n";
}
echo "		</tr>\n";
$cnt=1;
if(isset($ultra) && (count($ultra) > 0)) {
	foreach($ultra as $prev) {
		echo "<tr>\n";
		echo "<td class='BodyBorderB'><input name='us_id_$cnt' id='us_id_$cnt' type='hidden' readonly='readonly' value='".$prev['id']."' /><input name='us_num_links_$cnt' id='us_num_links_$cnt' type='hidden' tabindex='-1' value='".$prev['num_links']."' /><input name='us_dt_$cnt' id='us_dt_$cnt' class='FullInput' tabindex='-1' type='text' value='".$prev['begdate']."' title='YYYY-MM-DD' /></td>\n";
		echo "<td class='BodyBorderLB'><input name='us_type_$cnt' id='us_type_$cnt' class='FullInput' tabindex='-1' value='".$prev['title']."' /></td>\n";
		echo "<td class='BodyBorderLB'><input name='us_comm_$cnt' id='us_comm_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['comments']."' /></td>\n";
		echo "<td class='BodyBorderLB'><input name='us_rev_$cnt' id='us_rev_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['referredby']."' /></td>\n";
		echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdateUltrasound(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a>";
		if($unlink_allow) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return UnlinkUltrasound(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Un-Link</span></a>\n";
		}
		if(acl_check('admin','super')) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return DeleteUltrasound(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\",\"{$prev['num_links']}\");' href='javascript:;'><span>Delete</span></a>\n";
		}
		echo "</td>\n";
		echo "</tr>\n";
		$cnt++;
	}
}
$cnt--;
echo "		<tr>\n";
echo "			<td class='BodyBorderB'><input name='us_date' id='us_date' class='FullInput' type='text' value='",$dt['us_date'],"' /></td>\n";
echo "			<td class='BodyBorderLB'><input name='us_type' id='us_type' class='FullInput' type='text' value='".$dt['us_type']."' /></td>\n";
echo "			<td class='BodyBorderLB'><input name='us_comm' id='us_comm' class='FullInput' type='text' value='",$dt['us_comm'],"' /></td>\n";
echo "			<td class='BodyBorderLB'><input name='us_rev' id='us_rev' class='FullInput' type='text' value='",$dt['us_rev'],"' /></td>\n";
echo "			<td class='BodyBorderLB'>&nbsp;</td>\n";
echo "		</tr>\n";
echo "		</tr>\n";
echo "			<td class='",(($frmn=='form_acog_antepartum_D')?'wmtCollapseBarBlack':'wmtCollapseBar'),"'><a class='css_button' onClick='return SubmitUltrasound(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a></td>\n";
echo "			<td class='",(($frmn=='form_acog_antepartum_D')?'wmtCollapseBarBlack':'wmtCollapseBar'),"' colspan='2'><input name='tmp_us_cnt' id='tmp_us_cnt' type='hidden' tabindex='-1' value='$cnt' />&nbsp;</td>\n";
if($pop_form) {
	echo "			<td colspan='2' class='",(($frmn=='form_acog_antepartum_D')?'wmtCollapseBarBlack':'wmtCollapseBar'),"'><a class='css_button' href='javascript:;' onclick=\"dlgopen('../../../custom/document_popup.php?pid=".$pid."', '_blank', 800, 600);\"><span>View Documents</span></a></td>\n";
} else {
	echo "			<td colspan='2' class='",(($frmn=='form_acog_antepartum_D')?'wmtCollapseBarBlack':'wmtCollapseBar'),"'><a class='css_button' href='javascript:;' onclick=\"dlgopen('../../../custom/document_popup.php?pid=".$pid."', 'blank', 800, 600);\"><span>View Documents</span></a></td>\n";
}
echo "		</tr>\n";
echo "		</table>\n";
?>
