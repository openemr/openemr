<?php
echo "<div class='wmtPrnMainContainer'>\n";
echo "<div class='wmtPrnCollapseBar'>\n";
echo "	<span class='wmtPrnChapter'>Current Medications</span>\n";
echo "</div>\n";
echo "<div class='wmtPrnCollapseBox'>\n";
echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
if($med_add_allowed) {
	echo "	<tr>\n";
	echo "	<td class='wmtPrnLabelCenterBorderB' style='width: 95px'>Start Date</td>\n";
	echo "	<td class='wmtPrnLabelCenterBorderLB'>Medication</td>\n";
	echo "	<td class='wmtPrnLabelCenterBorderLB'>End Date</td>\n";
	echo "	<td class='wmtPrnLabelCenterBorderLB'>Status</td>\n";
	echo "	<td class='wmtPrnLabelCenterBorderLB'>Comments</td>\n";
	echo "</tr>\n";
	$cnt=1;
	if(isset($meds) && (count($meds) > 0)) {
		foreach($meds as $prev) {
			$med_status='Active';
			if($prev['enddate'] != '' && $prev['enddate'] != '0000-00-00') {
				$med_status='Inactive';
			}
			if($prev['extrainfo'] != '') { 
				$med_status= $prev['extrainfo'];
			}
			echo "<tr>\n";
			echo "<td class='wmtPrnBodyBorderB'>".$prev['begdate']."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$prev['title']."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$prev['enddate']."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$med_status."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$prev['comments']."&nbsp;</td>\n";
			echo "</tr>\n";
			$cnt++;
		}
	} else {
		echo "<tr>\n";
		echo "<td class='wmtPrnLabelBorderB'>&nbsp;</td>\n";
		echo "<td class='wmtPrnLabelBorderLB'>None on File</td>\n";
		echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
		echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
		echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
		echo "</tr>\n";
	}
} else {
	// This is the section for e-Rx clients, no medication adding
	echo "	<tr>\n";
	echo "		<td class='wmtPrnLabelCenterBorderB' style='width: 95px'>Start Date</td>\n";
	echo "		<td class='wmtPrnLabelCenterBorderLB'>Medication</td>\n";
	echo "		<td class='wmtPrnLabelCenterBorderLB'>Quantity</td>\n";
	echo "		<td class='wmtPrnLabelCenterBorderLB'>Dosage</td>\n";
	echo "		<td class='wmtPrnLabelCenterBorderLB'>Sig</td>\n";
	echo "		<td class='wmtPrnLabelCenterBorderLB'>Comments</td>\n";
	echo "	</tr>\n";
	$cnt=1;
	if(isset($meds) && (count($meds) > 0)) {
		foreach($meds as $prev) {
			// This flag isn't set and there's nothing to test for activity
			// $med_status='Inactive';
			// if($prev['active'] == '1') { $med_status='Active'; }
			$sig1=trim(ListLook($prev['route'],'drug_route'));
			if(!empty($sig1)) { $sig1=' by '.$sig1; }
			$sig2=trim(ListLook($prev['interval'],'drug_interval'));
			$sig1=$prev['dosage'].$sig1.' '.$sig2;
			$size=trim($prev['size']);
			$unit=trim(ListLook($prev['unit'],'drug_units'));
			$size.=$unit;
			echo "<tr>\n";
			echo "<td class='wmtPrnBodyBorderB'>".$prev['date_added']."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$prev['drug']."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$prev['quantity']."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$size."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$sig1."&nbsp;</td>\n";
			echo "<td class='wmtPrnBodyBorderLB'>".$prev['note']."&nbsp;</td>\n";
			echo "</tr>\n";
			$cnt++;
		}
	} else {
		echo "<tr>\n";
		echo "<td class='wmtPrnLabelBorderB'>&nbsp;</td>\n";
		echo "<td class='wmtPrnLabelBorderLB'>None on File</td>\n";
		echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
		echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
		echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
		echo "<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
		echo "</tr>\n";
	}
}
$tmp_col=6;
if($med_add_allowed) { $tmp_col=5; }
if(!empty($dt['fyi_med_nt'])) {
	echo "		<tr>\n";
	echo "			<td class='wmtPrnLabel' colspan='2'>Other Notes:</td>\n";
	echo "		</tr>\n";
	echo "		<tr>\n";
	echo "			<td class='wmtPrnBody' colspan='$tmp_col'>".$dt['fyi_med_nt']."</td>\n";
	echo "		</tr>\n";
}
echo "</table>\n";
echo "</div>\n";
echo "</div>\n";
?>
