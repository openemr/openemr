<?php
$_print= false;
if(!isset($pmh_note)) { $pmh_note = ''; }
if((isset($pmh) && (count($pmh) > 0)) || $pmh_note != '') { $_print= true; }
if($_print) {
	echo "<div class='wmtPrnMainContainer'>\n";
	echo "	<div class='wmtPrnCollapseBar'>\n";
	echo "		<span class='wmtPrnChapter'>Medical History</span>\n"; 
	echo "	</div>\n";
	echo "	<div class='wmtPrnCollapseBox'>\n";
	echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
	if(count($pmh) > 0) {
		echo "		<tr>\n";
		echo "			<td class='wmtPrnLabelCenterBorderB'>Issue</td>\n";
		echo "			<td class='wmtPrnLabelCenterBorderLB'>Notes</td>\n";
		echo "		</tr>\n";
	}
	foreach($pmh as $prev) {
		echo "		<tr>\n";
		echo "			<td class='wmtPrnBodyBorderB'>",ListLook($prev['pmh_type'],'Medical_History_Problems'),"&nbsp;</td>\n";
		echo "			<td class='wmtPrnBodyBorderLB'>",$prev['pmh_nt'],"&nbsp;</td>\n";
		echo "		</tr>\n";
	}
	if($pmh_note != '') {
		echo "		<tr>\n";
		echo "			<td class='wmtPrnLabel'>Other Notes:</td>\n";
		echo "		</tr>\n";
		echo "		<tr>\n";
		echo "			<td colspan='2' class='wmtPrnBody'>$pmh_note</td>\n";
		echo "		</tr>\n";
	}
	echo "		</table>\n";
	echo "	</div>\n";
	echo "</div>\n";
}
?>
