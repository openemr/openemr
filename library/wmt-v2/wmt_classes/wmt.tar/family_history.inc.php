<?php
if(!isset($client_id)) { $client_id=''; }
echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "		<tr>\n";
echo "			<td class='LabelCenterBorderB'>Who</td>\n";
echo "			<td class='LabelCenterBorderLB'>Deceased</td>\n";
if($client_id != 'wcs') {
	echo "			<td class='LabelCenterBorderLB'>Current Age</td>\n";
}
echo "			<td class='LabelCenterBorderLB'>Age at Death</td>\n";
echo "			<td class='LabelCenterBorderLB'>Condition</td>\n";
echo "			<td class='LabelCenterBorderLB'>Notes</td>\n";
if(acl_check('admin','super') && $unlink_allow) {
	echo "			<td class='LabelCenterBorderLB' style='width: 175px'>&nbsp;</td>\n";
} else if(acl_check('admin','super')) {
	echo "			<td class='LabelCenterBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else if(acl_check('admin','super')) {
	echo "			<td class='LabelCenterBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else {
	echo "			<td class='LabelCenterBorderLB' style='width: 65px'>&nbsp;</td>\n";
}
echo "		</tr>\n";
$cnt=1;
if(isset($fh)) {
	foreach($fh as $prev) {
		echo "<tr>\n";
		echo "<td class='BodyBorderB'><input name='fh_id_".$cnt."' id='fh_id_".$cnt."' type=hidden readonly='readonly' value='".$prev['id']."' /><input name='fh_num_links_$cnt' id='fh_num_links_$cnt' type='hidden' tabindex='-1' value='".$prev['fh_num_links']."' /><select name='fh_who_".$cnt."' id='fh_who_".$cnt."' class='FullInput' tabindex='-1'>\n";
		ListSel($prev['fh_who'],'Family_Relationships');
		echo "</select></td>\n";
		echo "<td class='BodyBorderLB'><select name='fh_dead_".$cnt."' id='fh_dead_".$cnt."' class='FullInput' tabindex='-1'>\n";
		ListSel($prev['fh_deceased'],'YesNo');
		echo "</select>";
		if($client_id != 'wcs') {
			echo "</td>\n<td class='BodyBorderLB'><input name='fh_age_".$cnt."' id='fh_age_".$cnt."' class='FullInput' type='text' tabindex='-1' value='".$prev['fh_age']."' /></td>\n";
		} else {
			echo "<input name='fh_age_".$cnt."' id='fh_age_".$cnt."' type='hidden' tabindex='-1' value='".$prev['fh_age']."' /></td>\n";
		}
		echo "<td class='BodyBorderLB'><input name='fh_age_dead_".$cnt."' id='fh_age_dead_".$cnt."' class='FullInput' type='text' tabindex='-1' value='".$prev['fh_age_dead']."' /></td>\n";
		echo "<td class='BodyBorderLB'><select name='fh_type_".$cnt."' id='fh_type_".$cnt."' class='FullInput' tabindex='-1'>\n";
	 	ListSelALpha($prev['fh_type'],'Family_History_Problems');
		echo "</select></td>\n";
		echo "<td class='BodyBorderLB'><input name='fh_nt_".$cnt."' id='fh_nt_".$cnt."' class='FullInput' type='text' value='".$prev['fh_nt']."' /></td>\n";
		echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdateFamilyHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a>";
		if($unlink_allow) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return UnlinkFamilyHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Un-Link</span></a>\n";
		}
		if(acl_check('admin','super')) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return DeleteFamilyHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\",\"{$prev['fh_num_links']}\");' href='javascript:;'><span>Delete</span></a>\n";
		}
		echo "</td>\n";
		echo "</tr>\n";
		$cnt++;
	}
}
	echo "		<tr>\n";
	echo "			<td class='BodyBorderB'><select name='fh_who' id='fh_who' class='FullInput' onchange='get_family_defaults();'>\n";
	ListSel($dt{'fh_who'},'Family_Relationships');
	echo "			</select></td>\n";
	echo "			<td class='BodyBorderLB'><select name='fh_dead' id='fh_dead' class='FullInput'>\n";
	ListSel($dt{'fh_dead'},'YesNo');
	echo "			</select>";
	if($client_id != 'wcs') {
		echo "			</td>\n<td class='BodyBorderLB'><input name='fh_age' id='fh_age' class='FullInput' type='text' value='",$dt{'fh_age'},"' /></td>\n";
	} else {
		echo "			<input name='fh_age' id='fh_age' type='hidden' value='",$dt{'fh_age'},"' /></td>\n";
	}
	echo "			<td class='BodyBorderLB'><input name='fh_age_dead' id='fh_age_dead' class='FullInput' type='text' value='",$dt{'fh_age_dead'},"' /></td>\n";
	echo "			<td class='BodyBorderLB'><select name='fh_type' id='fh_type' class='FullInput'>\n";
	ListSelAlpha($dt{'fh_type'},'Family_History_Problems');
	echo "			</select></td>\n";
	echo "			<td class='BodyBorderLB'><input name='fh_nt' id='fh_nt' class='FullInput' type='text' value='",$dt{'fh_nt'},"' /></td>\n";
	echo "			<td class='BodyBorderLB'>&nbsp;</td>\n";
	echo "		</tr>\n";
	echo "		<tr>\n";
	$cols=3;
	if($client_id != 'wcs') { $cols=4; }
	echo "			<td class='CollapseBar' colspan='4'><a class='css_button' onClick='return SubmitFamilyHistory(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a></td>\n";
	echo "			<td class='CollapseBar' colspan='3'><a class='css_button' onClick='return add_item(\"fh_type\",\"Family_History_Problems\");' href='javascript:;'><span>Add A Problem Type</span></a></td>\n";
	echo "		</tr>\n";
	echo "	</table>\n";
?>
