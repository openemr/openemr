<?php
echo" <table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo" 	<tr>\n";
echo" 		<td class='LabelCenterBorderB' style='width: 95px'>Date</td>\n";
echo" 		<td class='LabelCenterBorderLB'>Immunization</td>\n";
echo" 		<td class='LabelCenterBorderLB'>Notes</td>\n";
if($unlink_allow) {
	echo" 		<td class='LabelCenterBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else {
	echo" 		<td class='LabelCenterBorderLB' style='width: 65px'>&nbsp;</td>\n";
}
echo" 	</tr>\n";
$cnt=1;
if(isset($imm) && (count($imm) > 0)) {
	foreach($imm as $prev) {
		echo "<tr>\n";
		echo "<td class='BodyBorderB'><input name='imm_id_".$cnt."' id='imm_id_".$cnt."' type='hidden' tabindex='-1' value='".$prev['id']."' />".$prev['administered_date']."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'>".ImmLook($prev['cvx_code'],'immunizations')."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'><input name='imm_comments_".$cnt."' id='imm_comments_".$cnt."' type='text' class='FullInput' tabindex='-1' value='".$prev['note']."' /></td>\n";
		echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdateImmunization(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a>";
		if($unlink_allow) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return UnlinkImmunization(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Un-Link</span></a>\n";
		}
		// echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdateImmunization(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a></td>\n";
		echo "</td>\n";
		echo "</tr>\n";
		$cnt++;
	}
} else {
	echo "<tr>\n";
	echo "<td class='LabelBorderB'>&nbsp;</td>\n";
	echo "<td class='LabelBorderLB'>None on File</td>\n";
	echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
	echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
	echo "</tr>\n";
}
echo "	</table>\n";
?>
