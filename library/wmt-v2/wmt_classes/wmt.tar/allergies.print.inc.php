<?php
echo "<div class='wmtPrnMainContainer'>\n";
echo "  <div class='wmtPrnCollapseBar'>\n";
echo "    <span class='wmtPrnChapter'>Allergies</span>\n";
echo "  </div>\n";
echo "  <div class='wmtPrnCollapseBox'>\n";
echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "		<tr>\n";
echo "			<td class='wmtPrnLabelCenterBorderB' style='width: 95px'>Start Date</td>\n";
echo "			<td class='wmtPrnLabelCenterBorderLB'>Title</td>\n";
echo "			<td class='wmtPrnLabelCenterBorderLB'>Reaction</td>\n";
echo "			<td class='wmtPrnLabelCenterBorderLB'>Comments</td>\n";
echo "		</tr>\n";
$cnt=1;
if(isset($allergies) && (count($allergies) > 0)) {
	foreach($allergies as $prev) {
		echo "		<tr>\n";
		echo "			<td class='wmtPrnBodyBorderB'>".$prev['begdate']."&nbsp;</td>\n";
		echo "			<td class='wmtPrnBodyBorderLB'>".$prev['title']."&nbsp;</td>\n";
		echo "			<td class='wmtPrnBodyBorderLB'>".ListLook($prev['outcome'],'outcome')."&nbsp;</td>\n";
		echo "			<td class='wmtPrnBodyBorderLB'>".$prev['comments']."&nbsp;</td>\n";
		echo "		</tr>\n";
		$cnt++;
	}
} else {
	echo "		<tr>\n";
	echo "			<td class='wmtPrnLabelBorderB'>&nbsp;</td>\n";
	echo "			<td class='wmtPrnLabelBorderLB'>None on File</td>\n";
	echo "			<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
	echo "			<td class='wmtPrnLabelBorderLB'>&nbsp;</td>\n";
	echo "		</tr>\n";
}
if(!empty($dt['fyi_allergy_nt'])) {
	echo "		<tr>\n";
	echo "			<td class='wmtPrnLabel' colspan='2'>Other Notes:</td>\n";
	echo "		</tr>\n";
	echo "		<tr>\n";
	echo "			<td class='wmtPrnBody' colspan='4'>".$dt['fyi_allergy_nt']."</td>\n";
	echo "		</tr>\n";
}
echo "	</table>\n";
echo "	</div>\n";
echo "</div>\n";
?>
