<?php
if(isset($fh) && (count($fh) > 0))  {
	$border='';
	if($chp_printed) {
		echo "	</table>\n";
		echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
		$border='wmtPrnBorderT';
	} else {
		$chp_printed=PrintChapter('Family History',$chp_printed); 
	}
	echo "		<tr>\n";
	echo "			<td class='wmtPrnLabelCenterBorderB $border'>Who</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB $border'>Deceased</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB $border'>Current Age</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB $border'>Age at Death</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB $border'>Condition</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB $border'>Notes</td>\n";
	echo "		</tr>\n";
	if(count($fh) > 0) {
		foreach($fh as $prev) {
			echo "		<tr>\n";
			echo "			<td class='wmtPrnBodyBorderB'>",ListLook($prev['fh_who'],'Family_Relationships'),"&nbsp;</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>",ListLook($prev['fh_deceased'],'YesNo'),"&nbsp;</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>",$prev['fh_age'],"&nbsp;</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>",$prev['fh_age_dead'],"&nbsp;</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>",ListLook($prev['fh_type'],'Family_History_Problems'),"&nbsp;</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>",$prev['fh_nt'],"&nbsp;</td>\n";
			echo "		</tr>\n";
		}
	} else {
			echo "		<tr>\n";
			echo "			<td class='wmtPrnBodyBorderB'>None on File</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>&nbsp;</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>&nbsp;</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>&nbsp;</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>&nbsp;</td>\n";
			echo "			<td class='wmtPrnBodyBorderLB'>&nbsp;</td>\n";
			echo "		</tr>\n";
	}
}
?>
