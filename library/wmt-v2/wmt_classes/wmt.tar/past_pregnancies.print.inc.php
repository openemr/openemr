<?php
$_print= false;
if(!isset($show_ob_totals)) { $show_ob_totals= false; }
if(isset($obhist) && (count($obhist) > 0)) { $_print= true; }
if($show_ob_totals && ($dt['db_pregnancies'] || $dt['db_deliveries'])) { $_print= true; }
if($_print) {
	echo "<div class='wmtPrnMainContainer'>\n";
	echo "  <div class='wmtPrnCollapseBar'>\n";
	echo "    <span class='wmtPrnChapter'>Obstetrical History</span>\n";
	echo "  </div>\n";
	echo "  <div class='wmtPrnCollapseBox'>\n";
	echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
	echo "		<tr>\n";
	echo "       <td style='width: 8%' class='wmtPrnLabel3Center'>Date</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderLB' style='width: 8%' rowspan='2'>GA Weeks</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderLB' style='width: 6%' rowspan='2'>Length of Labor</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderL' colspan='2'>Birth Weight</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderL' style='width: 6%'>Sex</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderLB' style='width: 8%' rowspan='2'>Type Delivery</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderLB' style='width: 9%' rowspan='2'>Anesthesia</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderLB' style='width: 15%' rowspan='2'>Place of Delivery</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderL' style='width: 8%'>Preterm</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderLB' rowspan='2'>Comments/Complications</td>\n";
	echo "     </tr>\n";
	echo "     <tr>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderB'>YYYY-MM</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderLB' style='width: 4%'>lb.</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderB' style='width: 4%'>oz.</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderLB'>M/F</td>\n";
	echo "       <td class='wmtPrnLabel3CenterBorderLB'>Labor</td>\n";
	echo "		</tr>\n";
	foreach($obhist as $preg) {
  	echo "		<tr>\n";
  	echo "  		<td class='wmtPrnBody3BorderB'>",$preg['pp_date_of_pregnancy'],"&nbsp;</td>\n";
  	echo "  		<td class='wmtPrnBody3BorderLB'>",$preg['pp_ga_weeks'],"&nbsp;</td>\n";
  	echo "  		<td class='wmtPrnBody3BorderLB'>",$preg['pp_labor_length'],"&nbsp;</td>\n"; 
  	echo "  		<td class='wmtPrnBody3BorderLB'>",$preg['pp_weight_lb'],"&nbsp;</td>\n"; 
  	echo "	 		<td class='wmtPrnBody3BorderLB'>",$preg['pp_weight_oz'],"&nbsp;</td>\n";
  	echo "			<td class='wmtPrnBody3BorderLB'>",ListLook($preg['pp_sex'],'WHC_Sex'),"&nbsp;</td>\n";
  	echo "  		<td class='wmtPrnBody3BorderLB'>",ListLook($preg['pp_delivery'],'WHC_Delivery'),"&nbsp;</td>\n";
  	echo "  		<td class='wmtPrnBody3BorderLB'>",ListLook($preg['pp_anes'],'WHC_Anesthesia'),"&nbsp;</td>\n";
  	echo " 		  <td class='wmtPrnBody3BorderLB'>",$preg['pp_place'],"&nbsp;</td>\n";
  	echo "		  <td class='wmtPrnBody3BorderLB'>",ListLook($preg['pp_preterm'],'WHC_Preterm'),"&nbsp;</td>\n";
  	echo "  		<td class='wmtPrnBody3BorderLB'>",$preg['pp_comment'],"&nbsp;</td>\n";
  	echo "		</tr>\n";
	}
	if($show_ob_totals) {
		echo "			<tr>\n";
		echo "				<td class='wmtPrnLabel' colspan='5' style='border-top: solid 1px black'>Total # of Pregnancies:</td>\n";
		echo "				<td class='wmtPrnBody' style='border-top: solid 1px black'>".$dt{'db_pregnancies'}."</td>\n";
		echo "				<td style='border-top: solid 1px black'>&nbsp;</td>\n";
		echo "				<td class='wmtPrnLabel' colspan='3' style='border-top: solid 1px black'>Total # of Deliveries:</td>\n";
		echo "				<td class='wmtPrnBody' style='border-top: solid 1px black'>".$dt{'db_deliveries'}."</td>\n";
		echo "			</tr>\n";
	}
	echo "		</table>\n";
	echo "	</div>\n";
	echo "</div>\n";
}
// if(!$printed) {
// 	echo "		<tr>\n";
//  echo "  		<td class='wmtPrnBody3BorderB'>None</td>\n";
//  echo "  		<td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
// 	echo "  		<td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
// 	echo "  		<td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
// 	echo "	 		<td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
// 	echo "			<td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
// 	echo "  		<td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
// 	echo "  		<td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
// 	echo " 		  <td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
// 	echo "		  <td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
// 	echo "  		<td class='wmtPrnBody3BorderLB'>&nbsp;</td>\n";
//	echo "		</tr>\n";
//}
?>
