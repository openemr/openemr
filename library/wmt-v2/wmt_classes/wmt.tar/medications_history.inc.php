<?php
echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "	<tr>\n";
echo "		<td class='LabelCenterBorderB' style='width: 95px'>Start Date</td>\n";
echo "		<td class='LabelCenterBorderLB'>Medication</td>\n";
echo "		<td class='LabelCenterBorderLB'>Quantity</td>\n";
echo "		<td class='LabelCenterBorderLB'>Dosage</td>\n";
echo "		<td class='LabelCenterBorderLB'>Sig</td>\n";
echo "		<td class='LabelCenterBorderLB'>Comments</td>\n";
if($unlink_allow) {	
	echo "		<td class='LabelCenterBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else {
	echo "		<td class='LabelCenterBorderLB' style='width: 65px'>&nbsp;</td>\n";
}
echo "	</tr>\n";
if($med_hist && (count($med_hist) > 0)) {
	$cnt=1;
	foreach($med_hist as $prev) {
		$sig1=trim(ListLook($prev['route'],'drug_route'));
		if(!empty($sig1)) { $sig1=' by '.$sig1; }
		$sig2=trim(ListLook($prev['interval'],'drug_interval'));
		$sig1=$prev['dosage'].$sig1.' '.$sig2;
		$size=trim($prev['size']);
		$unit=trim(ListLook($prev['unit'],'drug_units'));
		$size.=$unit;
		echo "<tr>\n";
		echo "<td class='BodyBorderB'><input name='med_hist_id_".$cnt."' id='med_hist_id_".$cnt."' type='hidden' readonly='readonly' tabindex='-1' value='".$prev['id']."' />".$prev['date_added']."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'>".$prev['drug']."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'>".$prev['quantity']."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'>".$size."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'>".$sig1."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'><input name='med_hist_comments_".$cnt."' id='med_hist_comments_".$cnt." type='text' class='FullInput' tabindex='-1' value='".$prev['note']."' /></td>\n";
		echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdatePrescriptionHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a>";
		if($unlink_allow) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return UnlinkPrescriptionHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Un-Link</span></a>\n";
		}
		// echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdatePrescriptionHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a></td>\n";
		echo "</td>\n";
		echo "</tr>\n";
		$cnt++;
	}
} else {
	echo "<tr>\n";
		echo "<td class='LabelBorderB'>&nbsp;</td>\n";
		echo "<td class='LabelBorderLB'>None on File</td>\n";
		echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
		echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
		echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
		echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
		echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
	echo "</tr>\n";
}
echo "</table>\n";
?>
