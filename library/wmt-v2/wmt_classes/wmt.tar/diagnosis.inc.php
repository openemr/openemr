<?php
include_once("../../../custom/code_types.inc.php");
$show_unlink=true;
if(isset($no_unlink)) {
	if($no_unlink == true) { $show_unlink = false; }
}
if(!(isset($use_favorites))) { $use_favorites=false; }
echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "	<tr>\n";
if($use_favorites) {
	echo "		<td class='LabelBorderB' style='width: 60px;'>#</td>\n";
} else {
	echo "		<td class='LabelBorderB' style='width: 35px;'>#</td>\n";
}
echo "		<td class='LabelBorderLB' style='width: 85px;'>Diagnosis</td>\n";
echo "		<td class='LabelBorderLB' style='width: 85px;'>Start Date</td>\n";
echo "		<td class='LabelBorderLB' style='width: 85px;'>End Date</td>\n";
echo "		<td class='LabelBorderLB'>Title</td>\n";
if($show_unlink) {
	echo "		<td class='LabelBorderLB'>Description</td>\n";
	echo "		<td class='LabelBorderB' style='width: 70px'>&nbsp;</td>\n";
} else {
	echo "		<td class='LabelBorderB'>Description</td>\n";
}
echo "	</tr>\n";
$bb='';
if(isset($diag_bar_bottom)) {
	if($diag_bar_bottom == true) { $bb = 'border-bottom: solid 1px black'; }
}
$cnt=1;
// echo "Mode: ",$dt['tmp_diag_window_mode'],"  Count: ",count($diag),"<br/>\n";
if(isset($diag) & (count($diag) > 0)) {
	foreach($diag as $prev) {
		// If multiple diags OEMR puts them in a semi-colon delimited list
		// we'll use the first but keep the rest to put back if we update
		$remainder='';
		$code_type='';
		// echo "Encounter: $encounter Diag Link: ",$prev['encounter'],"<br/>\n";
		if($dt['tmp_diag_window_mode'] == 'current') {
			if($prev['enddate']) { continue; }
		}
		if($dt['tmp_diag_window_mode'] == 'encounter') {
			if($prev['encounter'] != $encounter) { continue; }
		}
		if($pos = strpos($prev['diagnosis'],';')) {
			$remainder=trim(substr($prev['diagnosis'],($pos+1)));
			$prev['diagnosis']=trim(substr($prev['diagnosis'],0,$pos));
		}
		// echo "Our diagnosis ",$prev['diagnosis'],"<br/>\n";
		// echo "Our Remainder",$remainder,"<br/>\n";
		if($pos = strpos($prev['diagnosis'],':')) {
			// Also keep the type in case we update
			$code_type=trim(substr($prev['diagnosis'],0,$pos));
			$prev['diagnosis']=trim(substr($prev['diagnosis'],($pos+1)));
		}
		// echo "Our diagnosis ",$prev['diagnosis'],"<br/>\n";
		// echo "Our Code Type",$code_type,"<br/>\n";
		$desc = lookup_code_descriptions($code_type.':'.$prev['diagnosis']);
   	echo "	<tr>\n";
		echo "		<td class='Label'><input name='dg_id_$cnt' id='dg_id_$cnt' type='hidden' readonly='readonly' value='".$prev['id']."' /><span class='Label'>$cnt&nbsp).</td>\n";
		echo "		<td class='Body'><input name='dg_code_".$cnt."' id='dg_code_".$cnt."' class='FullInput' type='text' value='".$prev['diagnosis']."' onClick='get_diagnosis(\"dg_code_".$cnt."\",\"tmp_dg_desc_".$cnt."\",\"dg_begdt_".$cnt."\",\"dg_title_".$cnt."\");' title='Click to select or clear a diagnosis' /></td>\n";
		echo "		<td class='Body'><input name='dg_begdt_".$cnt."' id='dg_begdt_".$cnt."' class='FullInput' type='text' value='".$prev['begdate']."' /></td>\n";
		echo "		<td class='Body'><input name='dg_enddt_".$cnt."' id='dg_enddt_".$cnt."' class='FullInput' type='text' value='".$prev['enddate']."' /></td>\n";
		echo "		<td class='Body'><input name='dg_title_".$cnt."' id='dg_title_".$cnt."' class='FullInput' type='text' value='".$prev['title']."' /></td>\n";
		echo "		<td class='Body'><input name='tmp_dg_desc_".$cnt."' id='tmp_dg_desc_".$cnt."' class='FullInput' type='text' disabled='disabled' value='".$desc."' /></td>\n";
		if($show_unlink) {
			echo "		<td class='BodyBorderL'>&nbsp;</td>\n";
		}
		echo "	</tr>\n";
		echo "	<tr>\n";
		echo "		<td class='Label2TR' style='border-bottom: solid 1px black'>Plan:";
		if($use_favorites) {
			echo "</br></br><div style='float: right; padding-right: 5px;'><a href='javascript:;' onClick='get_favorite(\"dg_plan_$cnt\",\"dg_code_$cnt\");' class='css_button_small' tabindex='-1' title='Select a plan for this diagnosis from Favorites'><span>Plans</span></a>";
		}
		echo "</td>\n";
		echo "		<td colspan='5' class='BodyBorderB'><textarea name='dg_plan_".$cnt."' id='dg_plan_".$cnt."' class='FullInput'>",$prev['comments'],"</textarea></td>\n";
		
		if($show_unlink || $use_favorites) {
			echo "		<td class='BodyBorderL' style='border-bottom: solid 1px black; vertical-align: top'>";
			if($show_unlink) {
				if($prev['encounter'] == $encounter) {
					echo "<a class='css_button_small' tabindex='-1' onclick='return UnlinkDiagnosis(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Un-Link</span></a>\n";
				} else {
					echo "<a class='css_button_small' tabindex='-1' onclick='return LinkDiagnosis(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Link</span></a>\n";
				}
			}
			if($use_favorites) {
					echo "<div style='float: left; padding-top: 5px;'><a class='css_button_small' tabindex='-1' onclick='return SubmitFavorite(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\",\"dg_code_$cnt\",\"dg_plan_$cnt\");' href='javascript:;'><span>Save Plan</span></a></div>\n";
			}
		}

		echo "			<input name='dg_remain_".$cnt."' id='dg_remain_".$cnt."'' type='hidden' value='",$remainder,"' /><input name='dg_type_".$cnt."' id='dg_type_".$cnt."' type='hidden' value='",$code_type,"' /></td>\n";
		echo "	</tr>\n";
		$cnt++;
	}
}

// Here is the new entry 
echo "	<tr>\n";
echo "		<td class='Label'>",$cnt,"&nbsp).</td>\n";
echo "		<td class='Body'><input name='dg_code' id='dg_code' class='FullInput' type='text' value='",$dt{'dg_code'},"' onClick='get_diagnosis(\"dg_code\",\"tmp_dg_desc\",\"dg_begdt\",\"dg_title\");' title='Click to select a diagnosis' /></td>\n";
echo "		<td class='Body'><input name='dg_begdt' id='dg_begdt' class='FullInput' type='text' value='",$dt{'dg_begdt'},"' title='YYYY-MM-DD' /></td>\n";
echo "		<td class='Body'><input name='dg_enddt' id='dg_enddt' class='FullInput' type='text' value='",$dt{'dg_enddt'},"' title='YYYY-MM-DD' /></td>\n";
echo "		<td class='Body'><input name='dg_title' id='dg_title' class='FullInput' type='text' value='",$dt{'dg_title'},"' title='Enter a brief description of the problem here'/></td>\n";
echo "		<td class='Body'><input name='tmp_dg_desc' id='tmp_dg_desc' class='FullInput' type='text' readonly='readonly' value='",$dt{'tmp_dg_desc'},"' /></td>\n";
if($show_unlink || $use_favorites) {
	echo "		<td class='BodyBorderL'>&nbsp;</td>\n";
}
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td class='Label2TR' style='border-bottom: solid 1px black'>Plan:";
if($use_favorites) {
	echo "</br></br><div style='float: right; padding-right: 5px;'><a href='javascript:;' onClick='get_favorite(\"dg_code_plan\",\"dg_code\");' class='css_button_small' tabindex='-1' title='Select a plan for this diagnosis from Favorites'><span>Plans</span></a>";
}
echo "</td>\n";
echo "		<td class='BodyBorderB' colspan='5'><textarea name='dg_code_plan' id='dg_code_plan' class='FullInput'>",$dt{'dg_code_plan'},"</textarea></td>\n";
if($show_unlink || $use_favorites) {
	echo "		<td class='BodyBorderLB'>&nbsp;";
	if($use_favorites) {
			echo "<br/><a class='css_button_small' tabindex='-1' onclick='return SubmitFavorite(\"$base_action\",\"$wrap_mode\",0,\"$id\",\"dg_code\",\"dg_code_plan\");' href='javascript:;'><span>Save Plan</span></a>\n";
	}
	echo "</td>\n";
}
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td colspan='2' class='CollapseBar' style='$bb'><a class='css_button' tabindex='-1' onclick='return AddDiagnosis(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a></td>\n";
echo "		<td class='CollapseBar' style='$bb'><input name='tmp_diag_cnt' id='tmp_diag_cnt' type='hidden' value='".($cnt-1)."' />&nbsp;</td>\n";
echo "		<td class='CollapseBar' style='$bb'>&nbsp;</td>\n";

if($show_unlink) {
	if($dt['tmp_diag_window_mode']=='encounter') {
		echo "		<td class='CollapseBar' style='$bb'><a class='css_button' tabindex='-1' onclick='return ToggleDiagWindowMode(\"$base_action\",\"$wrap_mode\",\"$id\",\"all\");' href='javascript:;'><span>Show All Diagnoses</span></a></td>\n";
		echo "		<td class='CollapseBar' style='$bb'><a class='css_button' tabindex='-1' onclick='return ToggleDiagWindowMode(\"$base_action\",\"$wrap_mode\",\"$id\",\"current\");' href='javascript:;'><span>Show Current Diagnoses</span></a></td>\n";
	} else if($dt['tmp_diag_window_mode']=='all') {
		echo "		<td class='CollapseBar' style='$bb'><a class='css_button' tabindex='-1' onclick='return ToggleDiagWindowMode(\"$base_action\",\"$wrap_mode\",\"$id\",\"current\");' href='javascript:;'><span>Show Current Diagnoses</span></a></td>\n";
		echo "		<td class='CollapseBar' style='$bb'><a class='css_button' tabindex='-1' onclick='return ToggleDiagWindowMode(\"$base_action\",\"$wrap_mode\",\"$id\",\"encounter\");' href='javascript:;'><span>Only This Encounter</span></a></td>\n";
	} else {
		echo "		<td class='CollapseBar' style='$bb'><a class='css_button' tabindex='-1' onclick='return ToggleDiagWindowMode(\"$base_action\",\"$wrap_mode\",\"$id\",\"all\");' href='javascript:;'><span>Show All Diagnoses</span></a></td>\n";
		echo "		<td class='CollapseBar' style='$bb'><a class='css_button' tabindex='-1' onclick='return ToggleDiagWindowMode(\"$base_action\",\"$wrap_mode\",\"$id\",\"encounter\");' href='javascript:;'><span>Only This Encounter</span></a></td>\n";
	}
} else {
	echo "		<td class='CollapseBar' style='$bb'>&nbsp;</td>\n";
}
	echo "		<td class='CollapseBar' style='$bb'>&nbsp;</td>\n";
echo "	</tr>\n";
echo "</table>\n";
?>
