<?php
echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "		<tr>\n";
echo "			<td class='LabelCenterBorderB' style='width: 95px'>Date</td>\n";
echo "			<td class='LabelCenterBorderLB'>Facility Type</td>\n";
echo "			<td class='LabelCenterBorderLB'>Reason</td>\n";
echo "			<td class='LabelCenterBorderLB'>Comments</td>\n";
if(acl_check('admin','super') && $unlink_allow) {
	echo "			<td class='LabelBorderLB' style='width: 175px'>&nbsp;</td>\n";
} else if($unlink_allow) {
	echo "			<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else if(acl_check('admin','super')) {
	echo "			<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else {
	echo "			<td class='LabelBorderLB' style='width: 65px'>&nbsp;</td>\n";
}
echo "		</tr>\n";
$cnt=1;
if(isset($hosp) && (count($hosp) > 0)) {
	foreach($hosp as $prev) {
		echo "<tr>\n";
		echo "<td class='BodyBorderB'><input name='hosp_id_$cnt' id='hosp_id_$cnt' type='hidden' readonly='readonly' value='".$prev['id']."' /><input name='hosp_num_links_$cnt' id='hosp_num_links_$cnt' type='hidden' tabindex='-1' value='".$prev['num_links']."' /><input name='hosp_dt_$cnt' id='hosp_dt_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['begdate']."' /></td>\n";
		echo "<td class='BodyBorderLB'><input name='hosp_type_$cnt' id='hosp_type_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['extrainfo']."' /></td>\n";
		echo "<td class='BodyBorderLB'><input name='hosp_why_$cnt' id='hosp_why_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['title']."' /></td>\n";
		echo "<td class='BodyBorderLB'><input name='hosp_nt_$cnt' id='hosp_nt_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['comments']."' /></td>\n";
		echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdateHospitalization(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a>";
		if($unlink_allow) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return UnlinkHospitalization(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Un-Link</span></a>\n";
		}
		if(acl_check('admin','super')) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return DeleteHospitalization(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\",\"{$prev['num_links']}\");' href='javascript:;'><span>Delete</span></a>\n";
		}
		echo "</td>\n";
		echo "</tr>\n";
		$cnt++;
	}
}
echo "		<tr>\n";
echo "			<td class='BodyBorderB'><input name='hosp_dt' id='hosp_dt' class='FullInput' type='text' value='",$dt{'hosp_dt'},"' /></td>\n";
echo "			<td class='BodyBorderLB'><input name='hosp_type' id='hosp_type' class='FullInput' type='text' value='",$dt{'hosp_type'},"' /></td>\n";
echo "			<td class='BodyBorderLB'><input name='hosp_why' id='hosp_why' class='FullInput' type='text' value='",$dt{'hosp_why'},"' /></td>\n";
echo "			<td class='BodyBorderLB'><input name='hosp_nt' id='hosp_nt' class='FullInput' type='text' value='",$dt{'hosp_nt'},"' /></td>\n";
echo "			<td class='BodyBorderLB'>&nbsp;</td>\n";
echo "		</tr>\n";
echo "		</tr>\n";
echo "			<td class='CollapseBar' colspan='5'><a class='css_button' onClick='return SubmitHospitalization(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a></td>\n";
echo "		</tr>\n";
echo "	</table>\n";
?>

