<?php
/** **************************************************************************
 *	fyi.class.php
 *	This file contains the standard classes for interacting with the          
 *	'Dashboard' which is a Williams Medical Technologies option for OpenEMR.  
 *	This class must be included for dashboard integration.
 *
 *  NOTES:
 *  1) __CONSTRUCT - always uses a record ID to retrieve data from the database
 *  2) GET - uses alternate selectors to find and return associated object
 *  3) FIND - returns only the object ID without data using alternate selectors
 *  4) LIST - returns an array of IDs meeting specific selector criteria
 *  5) FETCH - returns an array of data meeting specific criteria
 *   
 * 
 *  @packagefyi 
 *  @version 1.0
 *  @copyright Williams Medical Technologies, Inc.
 *  @author Rich Genandt <rgenandt@gmail.com>
 * 
 *************************************************************************** */

class wmtFYI{
	public $id;
	public $last_touch;
	public $pid;
  public $fyi;
	public $fyi_med_nt;
	public $fyi_allergy_nt;
	public $fyi_pmh_nt;
	public $fyi_surg_nt;
	public $fyi_medhist_nt;
	
	// generated values - none in use currently
	
	/**
	 * Constructor for the 'fyi' class which retrieves the requested 
	 * information from the database or creates an empty object. Only one
   * FYI record is on file for each patient.
	 * 
	 * @param int $id fyi record identifier
	 * @return object instance of fyi class
	 */
	public function __construct($id = false) {
		if(!$id) return false;

		$query = "SELECT * FROM form_fyi WHERE id = $id ";
		$results = sqlStatement($query);
	
		if ($data = sqlFetchArray($results)) {
			$this->id = $data['id'];
			$this->pid = $data['pid'];
      $this->last_touch= $data['date'];
      $this->fyi= $data['fyi'];
      $this->fyi_med_nt= $data['fyi_med_nt'];
      $this->fyi_allergy_nt= $data['fyi_allergy_nt'];
      $this->fyi_pmh_nt= $data['fyi_pmh_nt'];
      $this->fyi_surg_nt= $data['fyi_surg_nt'];
      $this->fyi_medhist_nt= $data['fyi_medhist_nt'];

		}
		else {
			throw new Exception('wmtFYI::_construct - no FYI record with id ('.$this->id.').');
		}
		
		// preformat commonly used data elements
		
	}	

	/**
	 * Retrieve an FYI object by PID value. Uses the base constructor 
   * for the 'FYI' class to create and return the object.  Since only 
   * one FYI is allowed per patient we will create a blank one if 
   * nothing is found.	 
	 * 
	 * @static
	 * @param int $pid patient record pid
	 * @return object instance of patient class
	 */
	public static function getPidFYI($pid) {
		if(!$pid) {
			throw new Exception('wmtFYI::getPidFYI - no patient identifier provided.');
		}
		
		$results = sqlStatement("SELECT id FROM form_fyi WHERE pid = '$pid'");
		$data = sqlFetchArray($results);
		if(!$data['id']) {
			$data['id'] = sqlInsert("INSERT INTO form_fyi SET " .
			"date = NOW(), " .
			"pid = '$pid', " .
			"user = '".$_SESSION['authUser']."', " .
			"groupname = '".$_SESSION['authProvider']."'");
    }
		return new wmtFYI($data['id']);
	}
	
  /**
 * Updates the FYI information in the database.
 * 
 * @static
 * @param Errors $iderror_object
 * @return null
 */
	public function update() {
		$fyi=htmlspecialchars($this->fyi,ENT_QUOTES,'UTF-8',false);	
		$med_nt=htmlspecialchars($this->fyi_med_nt,ENT_QUOTES,'UTF-8',false);	
		$all_nt=htmlspecialchars($this->fyi_allergy_nt,ENT_QUOTES,'UTF-8',false);	
		$surg_nt=htmlspecialchars($this->fyi_surg_nt,ENT_QUOTES,'UTF-8',false);	
		$pmh_nt=htmlspecialchars($this->fyi_pmh_nt,ENT_QUOTES,'UTF-8',false);	
		$medhist_nt=htmlspecialchars($this->fyi_medhist_nt,ENT_QUOTES,'UTF-8',false);	
		
		$sql = "UPDATE form_fyi SET date = NOW(), user = '".
			$_SESSION['authUser']."', groupname = '".$_SESSION['authProvider'].
			"', activity = 1, fyi='$fyi', fyi_med_nt='$med_nt', ".
			"fyi_surg_nt='$surg_nt', fyi_pmh_nt='$pmh_nt', ".
			"fyi_medhist_nt='$medhist_nt', ".
			"fyi_allergy_nt='$all_nt' WHERE id=$this->id";
		sqlInsert($sql);
		return;
	}

	/**
	 * Inserts data from an FYI object into the database.
	 * 
	 * @static
	 * @param Errors $iderror_object
	 * @return null
	 */
	public static function insert(wmtFYI $object) {
		if($object->id) {
			throw new Exception("wmtFYI::insert - object already contains identifier");
		}

		$object->id = sqlInsert("INSERT INTO form_fyi SET " .
			"date = NOW(), " .
			"pid = '$object->pid', " .
			"user = '".$_SESSION['authUser']."', " .
			"groupname = '".$_SESSION['authProvider']."'");
		
		return $object->id;
	}

	/**
	 * Checks to see if we will update any FYI fields, if so we will 
	 * also set the form date.
	 *
	 * @static
	 * @param - an array of fields indexed by FYI field names
	 * @return - true if we need to update
	 */
	public static function change($values=array(),$object) {
		if(count($values) < 1) return false;
		$change = false;
		$flds = sqlListFields('form_fyi');
		$flds = array_slice($flds,7);
		foreach($values as $key => $val) {
			if(in_array($key, $flds)) {
				if($val && ($val != 'YYYY-MM-DD') && ($val != $object->$key)) {
					$change = true;
					$object->$key = $val;
				}
			}
		}	
	}
}
                                            
?>
