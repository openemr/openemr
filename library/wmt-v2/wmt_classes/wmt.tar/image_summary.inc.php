<?php
echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "		<tr>\n";
echo "			<td class='LabelCenterBorderB' style='width: 90px'>Date</td>\n";
echo "			<td class='LabelCenterBorderLB'>Type</td>\n";
echo "			<td class='LabelCenterBorderLB'>Notes</td>\n";
if(acl_check('admin','super') && $unlink_allow) {
	echo "			<td class='LabelBorderLB' style='width: 175px'>&nbsp;</td>\n";
} else if($unlink_allow) {
	echo "			<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else if(acl_check('admin','super')) {
	echo "			<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else {
	echo "			<td class='LabelBorderLB' style='width: 65px'>&nbsp;</td>\n";
}
echo "		</tr>\n";
$cnt=1;
if(isset($img) && (count($img) > 0)) {
	foreach($img as $prev) {
		echo "<tr>\n";
		echo "<td class='BodyBorderB'><input name='img_id_$cnt' id='img_id_$cnt' type='hidden' readonly='readonly' value='".$prev['id']."' /><input name='img_num_links_$cnt' id='img_num_links_$cnt' type='hidden' tabindex = '-1' value='".$prev['img_num_links']."' /><input name='img_dt_$cnt' id='img_dt_$cnt' class='FullInput' type='text' value='".$prev['img_dt']."' title='YYYY-MM-DD' /></td>\n";
		echo "<td class='BodyBorderLB'><select name='img_type_$cnt' id='img_type_$cnt' class='FullInput' tabindex='-1'>\n";
		echo ListSelAlpha($prev['img_type'],'Image_Types');
		echo "</select></td>\n";
		echo "<td class='BodyBorderLB'><input name='img_nt_$cnt' id='img_nt_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['img_nt']."' /></td>\n";
		echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='top.restoreSession(); return UpdateImageHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a>";
		if($unlink_allow) {
			echo "<a class='css_button_small' tabindex='-1' onClick='top.restoreSession(); return UnlinkImageHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Un-Link</span></a>\n";
		}
		if(acl_check('admin','super')) {
			echo "<a class='css_button_small' tabindex='-1' onClick='top.restoreSession(); return DeleteImageHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\",\"{$prev['img_num_links']}\");' href='javascript:;'><span>Delete</span></a>\n";
		}
		echo "</td>\n";
		echo "</tr>\n";
		$cnt++;
	}
}
$cnt--;
echo "		<tr>\n";
echo "			<td class='BodyBorderB'><input name='img_dt' id='img_dt' class='FullInput' type='text' value='",$dt['img_dt'],"' /></td>\n";
echo "			<td class='BodyBorderLB'><select name='img_type' id='img_type' class='FullInput'>\n";
ListSelAlpha($dt['img_type'],'Image_Types');
echo "			</select></td>\n";
echo "			<td class='BodyBorderLB'><input name='img_nt' id='img_nt' class='FullInput' type='text' value='",$dt['img_nt'],"' /></td>\n";
echo "			<td class='BodyBorderLB'>&nbsp;</td>\n";
echo "		</tr>\n";
echo "		</tr>\n";
echo "			<td class='CollapseBar'><a class='css_button' onClick='top.restoreSession(); return SubmitImageHistory(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a></td>\n";
echo "			<td class='CollapseBar' colspan='3'><a class='css_button' onClick='return add_item(\"img_type\",\"Image_Types\");' href='javascript:;'><span>Add A Type</span></a><input name='tmp_img_cnt' id='tmp_img_cnt' type='hidden' tabindex='-1' value='".$cnt."' </td>\n";
echo "		</tr>\n";
echo "		</table>\n";
?>
