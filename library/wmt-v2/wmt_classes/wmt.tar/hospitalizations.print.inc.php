<?php
if(isset($hosp) && (count($hosp) > 0)) {
	echo "<div class='wmtPrnMainContainer'>\n";
	echo "	<div class='wmtPrnCollapseBar'>\n";
	echo "		<span class='wmtPrnChapter'>Admissions</span>\n";
	echo "	</div>\n";
	echo "	<div class='wmtPrnCollapseBox'>\n";
	echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
	echo "		<tr>\n";
	echo "			<td class='wmtPrnLabelCenterBorderB' style='width: 95px'>Date</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB'>Facility Type</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB'>Reason</td>\n";
	echo "			<td class='wmtPrnLabelCenterBorderLB'>Comments</td>\n";
	echo "		</tr>\n";
	foreach($hosp as $prev) {
		echo "<tr>\n";
		echo "<td class='wmtPrnBodyBorderB'>",$prev['begdate'],"&nbsp;</td>\n";
		echo "<td class='wmtPrnBodyBorderLB'>",$prev['extrainfo'],"&nbsp;</td>\n";
		echo "<td class='wmtPrnBodyBorderLB'>",$prev['title'],"&nbsp;</td>\n";
		echo "<td class='wmtPrnBodyBorderLB'>",$prev['comments'],"&nbsp;</td>\n";
		echo "</tr>\n";
	}
	echo "	</table>\n";
	echo "	</div>\n";
	echo "</div>\n";
}
?>

