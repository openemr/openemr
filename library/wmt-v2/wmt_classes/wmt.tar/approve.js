
function ApprovalTimeStamp(thisDate)
{
  var currentTime=new Date();
  var myStamp= currentTime.getFullYear();
  var myMonth= "00" + (currentTime.getMonth()+1);
  myMonth= myMonth.slice(-2);
  var myDays= "00" + currentTime.getDate();
  myDays= myDays.slice(-2);
  var myHours= "00" + currentTime.getHours();
  myHours= myHours.slice(-2);
  var myMinutes= "00" + currentTime.getMinutes();
  myMinutes= myMinutes.slice(-2);
  var mySeconds= "00" + currentTime.getSeconds();
  mySeconds= mySeconds.slice(-2);
  myStamp= myStamp + "-" + myMonth + "-" + myDays + " " + myHours + ":" +
           myMinutes + ":" + mySeconds;

  document.getElementById(thisDate).value = myStamp;
}

function ValidateApprovalPIN(source, check, disp, approve)
{
  var pin= document.getElementById(source).value;
  if(pin == '') {
    alert("No PIN Entered");
    return false;
  }
  var pin_check= document.getElementById(check).value;
  if(pin == pin_check) {
    alert("Form Approved");
    document.getElementById(disp).value = 'Approved - Now Click [Save Data] to Commit';
    document.getElementById(approve).value = 'A';
    return true;
  } else {
    alert("Incorrect PIN");
    document.getElementById(source).value = '';
    return false;
  }
}

function VerifyApprovalPIN(source, check, approve)
{
  var pin= document.getElementById(source).value;
  if(pin == '') {
    top.restoreSession();
    document.approval_form.submit();
    return true;
  }
  var pin_check= document.getElementById(check).value;
  if(pin == pin_check) {
    document.getElementById(approve).value = 'A';
    top.restoreSession();
    document.approval_form.submit();
    return true;
  } else {
    alert("Incorrect PIN");
    document.getElementById(source).value = '';
    document.getElementById(approve).value = '';
    return false;
  }
}

function ExitForm()
{
  top.restoreSession();
}
