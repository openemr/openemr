function setWeeksFrom(oldDate, newDate, targetColumn)
{
	var date1 = document.getElementById(oldDate).value;
	if(date1 == 0 || date1 == '') return false;	
	date1 = new Date(date1);
	if(date1 == 'Invalid Date') {
		alert("Surgery Date is NOT a Valid Date, Use 'YYYY-MM-DD' for Auto Calculating");
		return false;
	}
	var date2 = document.getElementById(newDate).value;
	if(date2 == 0 || date2 == '') return false;	
	date2 = new Date(date2);
	if(date2 == 'Invalid Date') {
		alert("Follow Up Date is NOT a Valid Date, Use 'YYYY-MM-DD' for Auto Calculating");
		return false;
	}
	var one_week = 1000 * 60 * 60 * 24 * 7;
	var seconds1 = date1.getTime();
	var seconds2 = date2.getTime();
  var mySeconds= Math.abs(seconds2 - seconds1);
	var myWeeks = Math.round(mySeconds / one_week);
	document.getElementById('kf_vis_num_'+targetColumn).value= myWeeks;
	return true;
}

function setKneeVisitNum(thisField,thisColumn)
{
	var my_val = document.getElementById(thisField).value;
	document.getElementById('tmp_label_lax_'+thisColumn).value = my_val;
	document.getElementById('tmp_label_align_'+thisColumn).value = my_val;
	document.getElementById('tmp_label_comp_'+thisColumn).value = my_val;
	document.getElementById('tmp_label_pat_'+thisColumn).value = my_val;
	document.getElementById('tmp_label_xray_'+thisColumn).value = my_val;
	document.getElementById('tmp_label_screw_'+thisColumn).value = my_val;
}
