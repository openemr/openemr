<?php
echo "		<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "			<tr>\n";
echo "        <td style='width: 8%' class='Label3C'>Date</td>\n";
echo "        <td class='Label3CBordL' style='width: 5%'>GA</td>\n";
echo "        <td class='Label3CBordLB' style='width: 6%' rowspan='2'>Length of Labor</td>\n";
echo "        <td class='Label3CBordL' colspan='2'>Birth Weight</td>\n";
echo "        <td class='Label3CBordL' style='width: 6%'>Sex</td>\n";
echo "        <td class='Label3CBordLB' style='width: 7%' rowspan='2'>Type Delivery</td>\n";
echo "        <td class='Label3CBordLB' style='width: 8%' rowspan='2'>Anesthesia</td>\n";
echo "        <td class='Label3CBordLB' style='width: 15%' rowspan='2'>Place of Delivery</td>\n";
echo "        <td class='Label3CBordL' style='width: 6%'>Preterm</td>\n";
echo "        <td class='Label3CBordLB' rowspan='2'>Comments/Complications</td>\n";
if($unlink_allow || $delete_allow) {
	echo "<td class='Label3CBordLB' rowspan='2' style='width: 65px'>&nbsp;</td>\n";
}
echo "      </tr>\n";
echo "      <tr>\n";
echo "        <td class='Label3CBordB'>YYYY-MM</td>\n";
echo "        <td class='Label3CBordLB'>Weeks</td>\n";
echo "        <td class='Label3CBordLB' style='width: 3%'>lb.</td>\n";
echo "        <td class='Label3CBordB' style='width: 3%'>oz.</td>\n";
echo "        <td class='Label3CBordLB'>M/F</td>\n";
echo "        <td class='Label3CBordLB'>Labor</td>\n";
echo "			</tr>\n";
$cnt=1;
if(isset($obhist) && (count($obhist) > 0)) {
	foreach($obhist as $preg) {
 		echo "			<tr>\n";
 		echo "  			<td class='Body2BordB'><input name='pp_date_of_pregnancy_$cnt' id='pp_date_of_pregnancy_$cnt' class='FullInput2' type='text' value='",$preg['pp_date_of_pregnancy'],"' /></td>\n";
 		echo "  			<td class='Body2BordLB'><input name='pp_ga_weeks_$cnt' id='pp_ga_weeks_$cnt' class='FullInput2' type='text' value='",$preg['pp_ga_weeks'],"' /></td>\n";
 		echo "  			<td class='Body2BordLB'><input name='pp_labor_length_$cnt' id='pp_labor_length_$cnt' class='FullInput2' type='text' value='",$preg['pp_labor_length'],"' /></td>\n"; 
 		echo "  			<td class='Body2BordLB'><input name='pp_weight_lb_$cnt' id='pp_weight_lb_$cnt' class='FullInput2' type='text' value='",$preg['pp_weight_lb'],"' /></td>\n"; 
 		echo "	 			<td class='Body2BordLB'><input name='pp_weight_oz_$cnt' id='pp_weight_oz_$cnt' class='FullInput2' type='text' value='",$preg['pp_weight_oz'],"' /></td>\n";
 		echo "				 <td class='Body2BordLB'><select name='pp_sex_$cnt' id='pp_sex_$cnt' class='FullInput2'>";
 		ListSel($preg['pp_sex'],'WHC_Sex');
 		echo "			</select></td>\n";
 		echo "  			<td class='Body2BordLB'><select name='pp_delivery_$cnt' id='pp_delivery_$cnt' class='FullInput2'>";
 		ListSel($preg['pp_delivery'],'WHC_Delivery');
 		echo "				</select></td>\n";
 		echo "  			<td class='Body2BordLB'><select name='pp_anes_$cnt' id='pp_anes_$cnt' class='FullInput2'>";
 		ListSel($preg['pp_anes'],'WHC_Anesthesia');
 		echo "				</select></td>\n";
 		echo " 			 <td class='Body2BordLB'><input name='pp_place_$cnt' id='pp_place_$cnt' class='FullInput2' type='text' value='",$preg['pp_place'],"' /></td>\n";
 		echo "			 <td class='Body2BordLB'><select name='pp_preterm_$cnt' id='pp_preterm_$cnt' class='FullInput2'>";
 		ListSel($preg['pp_preterm'],'WHC_Preterm');
 		echo "				</select></td>\n";
 		echo "  			<td class='Body2BordLB'><input name='pp_comment_$cnt' id='pp_comment_$cnt' class='FullInput2' type='text' value='",$preg['pp_comment'],"' /><input name='pp_id_$cnt' id='pp_id_$cnt' type='hidden' value='",$preg['id'],"' /></td>\n";
		if($unlink_allow) {
			echo "<td class='Body2BordLB'><a class='css_button_small' tabindex='-1' onClick='return UnlinkPastPregnancy(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;' title='Unlink this history from this visit'><span>Un-Link</span></a></td>";
		} else if($delete_allow) {
			echo "<td class='Body2BordLB'><a class='css_button_small' tabindex='-1' onClick='return DeletePastPregnancy(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;' title='Delete this entry'><span>Delete</span></a></td>";
		}
 		echo "			</tr>\n";
		$cnt++;
	}
}
echo "			<tr>\n";
echo "  			<td class='Body2BordB'><input name='pp_date_of_pregnancy' id='pp_date_of_pregnancy' class='FullInput2' type='text' value='",$dt['pp_date_of_pregnancy'],"' /></td>\n";
echo "  			<td class='Body2BordLB'><input name='pp_ga_weeks' id='pp_ga_weeks' class='FullInput2' type='text' value='",$dt['pp_ga_weeks'],"' /></td>\n";
echo "  			<td class='Body2BordLB'><input name='pp_labor_length' id='pp_labor_length' class='FullInput2' type='text' value='",$dt['pp_labor_length'],"' /></td>\n"; 
echo "  			<td class='Body2BordLB'><input name='pp_weight_lb' id='pp_weight_lb' class='FullInput2' type='text' value='",$dt['pp_weight_lb'],"' /></td>\n"; 
echo "	 			<td class='Body2BordLB'><input name='pp_weight_oz' id='pp_weight_oz' class='FullInput2' type='text' value='",$dt['pp_weight_oz'],"' /></td>\n";
echo "				 <td class='Body2BordLB'><select name='pp_sex' id='pp_sex' class='FullInput2'>";
ListSel($dt['pp_sex'],'WHC_Sex');
echo "			</select></td>\n";
echo "  			<td class='Body2BordLB'><select name='pp_delivery' id='pp_delivery' class='FullInput2'>";
ListSel($dt['pp_delivery'],'WHC_Delivery');
echo "				</select></td>\n";
echo "  			<td class='Body2BordLB'><select name='pp_anes' id='pp_anes' class='FullInput2'>";
ListSel($dt['pp_anes'],'WHC_Anesthesia');
echo "				</select></td>\n";
echo " 			 <td class='Body2BordLB'><input name='pp_place' id='pp_place' class='FullInput2' type='text' value='",$dt['pp_place'],"' /></td>\n";
echo "			 <td class='Body2BordLB'><select name='pp_preterm' id='pp_preterm' class='FullInput2'>";
ListSel($dt['pp_preterm'],'WHC_Preterm');
echo "				</select></td>\n";
echo "  			<td class='Body2BordLB'><input name='pp_comment' id='pp_comment' class='FullInput2' type='text' value='",$dt['pp_comment'],"' /></td>\n";
if($unlink_allow || $delete_allow) {
	echo "<td class='Body2BordLB'>&nbsp;</td>\n";
}
echo "			</tr>\n";
echo "			<tr>\n";
echo "				<td class='CollapseBar' colspan='5'><a class='css_button' onClick='return SubmitPastPregnancy(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a></td>\n";
echo "				<td class='CollapseBar' colspan='6'><input name='tmp_pp_cnt' id='tmp_pp_cnt' type='hidden' value='".($cnt-1)."' />&nbsp;</td>\n";
if($unlink_allow || $delete_allow) {
	echo "				<td class='CollapseBar'>&nbsp;</td>\n";
}
echo "			</tr>\n";
if(!isset($show_ob_totals)) { $show_ob_totals= false; }
if($show_ob_totals) {
	echo "			<tr>\n";
	echo "				<td class='wmtLabel' colspan='5' style='border-top: solid 1px black'>Total # of Pregnancies:</td>\n";
	echo "				<td colspan='2' style='border-top: solid 1px black'><input name='db_pregnancies' id='db_pregnancies' type='text' class='wmtInput' style='width: 60px;' value='".$dt{'db_pregnancies'}."' /></td>\n";
	echo "				<td style='border-top: solid 1px black'>&nbsp;</td>\n";
	echo "				<td class='wmtLabel' colspan='2' style='border-top: solid 1px black'>Total # of Deliveries:</td>\n";
	echo "				<td style='border-top: solid 1px black'><input name='db_deliveries' id='db_deliveries' type='text' class='wmtInput' style='width: 60px;' value='".$dt{'db_deliveries'}."' /></td>\n";
	if($unlink_allow || $delete_allow) {
		echo "				<td style='border-top: solid 1px black'>&nbsp;</td>\n";
	}
	echo "			</tr>\n";
}
echo "			</table>\n";
?>
