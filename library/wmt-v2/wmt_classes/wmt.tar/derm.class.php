<?php
/** **************************************************************************
 *	DERM.CLASS.PHP
 *	This file contains the standard classes for the dermatology implementation
 *	of OpenEMR. The file must be included in each dermatology form file or the
 *	implementation will not function correctly.
 *
 *  NOTES:
 *  1) __CONSTRUCT - always uses the record ID to retrieve data from the database
 *  2) GET - uses alternate selectors to find and return associated object
 *  3) FIND - returns only the object ID without data using alternate selectors
 *  4) LIST - returns an array of IDs meeting specific selector criteria
 *  5) FETCH - returns an array of data meeting specific criteria
 *   
 * 
 *  @package dermatology
 *  @version 1.0
 *  @copyright Williams Medical Technologies, Inc.
 *  @author Ron Criswell <info@keyfocusmedia.com>
 * 
 *************************************************************************** */

/** 
 * Provides a partial representation of the patient data record. This object
 * does NOT include all of the fields associated with the core patient data
 * record and should NOT be used for database updates.  It is intended only
 * for retrieval of partial patient information primarily for display 
 * purposes (reports for example).
 *
 * @package WMT
 * @subpackage Standard
 * @category Patient
 * 
 */
class wmtPatient {
	public $id;
	public $pid;
	public $title;
	public $language;
	public $financial;
	public $fname;
	public $mname;
	public $lname;
	public $DOB;
	public $sex;
	public $street;
	public $postal_code;
	public $city;
	public $state;
	public $country_code;
	public $ss;
	public $occupation;
	public $phone_home;
	public $phone_biz;
	public $phone_contact;
	public $contact_name;
	public $phone_cell;
	public $email;
	public $pharmacy_id;
	public $status;
	public $ethnoracial;
	public $race;
	public $ehinicity;
	
	// generated values
	public $format_name;
	
	/**
	 * Constructor for the 'patient' class which retrieves the requested 
	 * patient information from the database or creates an empty object.
	 * 
	 * @param int $id patient record identifier
	 * @return object instance of patient class
	 */
	public function __construct($id = false) {
		if(!$id) return false;

		$query = "SELECT * FROM patient_data ";
		$query .= "WHERE id = $id ";
		$results = sqlStatement($query);
	
		if ($data = sqlFetchArray($results)) {
			$this->id = $data['id'];
			$this->pid = $data['pid'];
			$this->title = $data['title'];
			$this->language = $data['language'];
			$this->financial = $data['financial'];
			$this->fname = $data['fname'];
			$this->mname = $data['mname'];
			$this->lname = $data['lname'];
			$this->DOB = $data['DOB'];
			$this->sex = $data['sex'];
			$this->street = $data['street'];
			$this->postal_code = $data['postal_code'];
			$this->city = $data['city'];
			$this->state = $data['state'];
			$this->countery_code = $data['counter_code'];
			$this->ss = $data['ss'];
			$this->occupation = $data['occupation'];
			$this->phone_home = $data['phone_home'];
			$this->phone_biz = $data['phone_biz'];
			$this->phone_contact = $data['phone_contact'];
			$this->contact_name = $data['contact_relationship'];
			$this->phone_cell = $data['phone_cell'];
			$this->email = $data['email'];
			$this->pharmacy_id = $data['pharmacy_id'];
			$this->status = $data['status'];
			$this->ethnoracial = $data['ethnoracial'];
			$this->race = $data['race'];
			$this->ehinicity = $data['ehinicity'];
		}
		else {
			throw new Exception('wmtPatient::_construct - no patient record with id ('.$this->id.').');
		}
		
		// preformat commonly used data elements
		$this->format_name = ($this->title)? "$this->title " : "";
		$this->format_name .= ($this->fname)? "$this->fname " : "";
		$this->format_name .= ($this->mname)? substr($this->mname,0,1).". " : "";
		$this->format_name .= ($this->lname)? "$this->lname " : "";

		if ($this->DOB) {
			$now = new DateTime();
			$then = new DateTime($this->DOB);
			$this->age = $then->diff($now)->y;
		}
		
	}	

	/**
	 * Retrieve a patient object by PID value. Uses the base constructor for the 'patient' class 
	 * to create and return the object. 
	 * 
	 * @static
	 * @param int $id patient record identifier
	 * @return object instance of patient class
	 */
	public static function getPidPatient($pid) {
		if(!pid) {
			throw new Exception('wmtPatient::getPidPatient - no patient identifier provided.');
		}
		
		$results = sqlStatement("SELECT id FROM patient_data WHERE pid = '$pid'");
		$data = sqlFetchArray($results);

		return new wmtPatient($data['id']);
	}
}

/** 
 * Provides a partial representation of the insurance data record. This object
 * does NOT include all of the fields associated with the core insurance data
 * record and should NOT be used for database updates.  It is intended only
 * for retrieval of partial insurance information primarily for display 
 * purposes (reports for example).
 *
 * @package WMT
 * @subpackage Standard
 * @category Insurance
 * 
 */
class wmtInsurance {
	public $id;
	public $pid;
	public $type;
	public $provider;
	public $plan_name;
	public $policy_number;
	
	// generated values
	public $format_name;
	
	/**
	 * Constructor for the 'patient' class which retrieves the requested 
	 * patient information from the database or creates an empty object.
	 * 
	 * @param int $id patient record identifier
	 * @return object instance of patient class
	 */
	public function __construct($id = false) {
		if(!$id) return false;

		$query = "SELECT * FROM insurance_data ";
		$query .= "WHERE id = $id ";
		$results = sqlStatement($query);
	
		if ($data = sqlFetchArray($results)) {
			$this->id = $data['id'];
			$this->pid = $data['pid'];
			$this->type = $data['type'];
			$this->provider = $data['provider'];
			$this->plan_name = $data['plan_name'];
			$this->policy_number = $data['policy_number'];
		}
		else {
			throw new Exception('wmtInsurance::_construct - no insurance record with id ('.$this->id.').');
		}
		
	}	

	/**
	 * Retrieve a insurance object by PID value. Uses the base constructor for the 'insurance' class 
	 * to create and return the object. 
	 * 
	 * @static
	 * @param int $id patient record identifier
	 * @return object instance of patient class
	 */
	public static function getPidInsurance($pid, $primary=TRUE) {
		if(!pid) {
			throw new Exception('wmtPatient::getPidInsurance - no patient identifier provided.');
		}
		
		$query = "SELECT id FROM insurance_data WHERE pid = '$pid' ";
		if ($primary) $query .= "AND type='primary' ";
		$results = sqlStatement($query);
		if ($results)
			$data = sqlFetchArray($results);

		return new wmtInsurance($data['id']);
	}
}

/** 
 * Provides standardized error reporting helper functions for the 'errors'
 * database table.
 *
 * @package Dermatology
 * @subpackage Lists
 */
class wmtIssue {
	public $id;
	public $date;
	public $type;
	public $title;
	public $begdate;
	public $enddate;
	public $returndate;
	public $occurrence;
	public $classification;
	public $referredby;
	public $extrainfo;
	public $diagnosis;
	public $activity;
	public $comments;
	public $pid;
	public $user;
	public $groupname;
	public $outcome;
	
	/**
	 * Constructor for the 'error' class which retrieves the requested 
	 * error record from the database of creates an empty object.
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public function __construct($id = FALSE) {
		if(!$id) return false;

		$query = "SELECT * FROM lists WHERE id = $id";

		$results = sqlStatement($query);
	
		if ($data = sqlFetchArray($results)) {
			$this->id = $data['id'];
			$this->date = $data['date'];
			$this->type = $data['type'];
			$this->title = $data['title'];
			$this->begdate = ($data['begdate'])? date('Y-m-d', strtotime($data['begdate'])) : '';
			$this->enddate = ($data['enddate'])? date('Y-m-d', strtotime($data['enddate'])) : '';
			$this->returndate = ($data['returndate'])? date('Y-m-d', strtotime($data['enddate'])) : '';
			$this->occurrence = $data['occurrence'];
			$this->classification = $data['classification'];
			$this->referredby = $data['refferredby'];
			$this->extrainfo = $data['extrainfo'];
			$this->diagnosis = $data['diagnosis'];
			$this->activity = $data['activity'];
			$this->comments = $data['comments'];
			$this->pid = $data['pid'];
			$this->user = $data['user'];
			$this->groupname = $data['groupname'];
			$this->outcome = $data['outcome'];
		}
		else {
			throw new Exception('wmtIssue::_construct - no issue record with id ('.$id.').');
		}
	}	

	/**
	 * Inserts data from an error object into the database.
	 * 
	 * @static
	 * @param Errors $iderror_object
	 * @return null
	 */
	public static function insert(wmtIssue $object) {
		if($object->id) {
			throw new Exception("wmtIssue::insert - object already contains identifier");
		}

		// add generic diagnosis record
		$begdate = ($object->begdate) ? "'$object->begdate'" : "NULL";
		$enddate = ($object->enddate) ? "'$object->enddate'" : "NULL";
		$returndate = ($object->returndate) ? "'$object->returndate'" : "NULL";
		
		$title = ($object->title)? $object->title : 'ICD9:'.$object->diagnosis;
		
		$object->id = sqlInsert("INSERT INTO lists SET " .
			"date = NOW(), " .
			"type = 'medical_problem', " .
			"title = '$title', " .
			"begdate = $begdate, " .
			"enddate = $enddate, " .
			"returndate = $returndate, " .
			"occurrence = '$object->occurrence', " .
			"classification = '$object->classification', " .
			"referredby = '$object->referredby', " .
			"extrainfo = '$object->extrainfo', " .
			"diagnosis = '$object->diagnosis', " .
			"activity = '$object->activity', " . 
			"comments = '$object->comments', " .
			"pid = '$object->pid', " .
			"user = '".$_SESSION['authUser']."', " .
			"groupname = '".$_SESSION['authProvider']."', " .
			"outcome = '$object->outcome'");
		
		return $object->id;
	}

	/**
	 * Inserts data from an error object into the database.
	 * 
	 * @static
	 * @param Errors $iderror_object
	 * @return null
	 */
	public function update() {
		// update generic diagnosis record
		$begdate = ($this->begdate) ? "'$this->begdate'" : "NULL";
		$enddate = ($this->enddate) ? "'$this->enddate'" : "NULL";
		$returndate = ($this->returndate) ? "'$this->returndate'" : "NULL";
		
		$title = ($this->title)? $this->title : 'ICD9:'.$this->diagnosis;
		
		sqlInsert("UPDATE lists SET " .
			"title = '$title', " .
			"begdate = $begdate, " .
			"enddate = $enddate, " .
			"returndate = $returndate, " .
			"occurrence = '$this->occurrence', " .
			"classification = '$this->classification', " .
			"referredby = '$this->referredby', " .
			"extrainfo = '$this->extrainfo', " .
			"diagnosis = '$this->diagnosis', " .
			"activity = '$this->activity', " . 
			"comments = '$this->comments', " .
			"pid = '$this->pid', " .
			"user = '".$_SESSION['authUser']."', " .
			"groupname = '".$_SESSION['authProvider']."', " .
			"outcome = '$this->outcome' " .
			"WHERE id = $this->id ");
		
		return;
	}

	/**
	 * Returns a list of issues identifiers associated with the
	 * given PID and optionally a given TYPE. If no TYPE is given
	 * then all issues for the PID are returned.
	 * 
	 * @static
	 * @param int $pid patient identifier
	 * @param string $type type of issue to select
	 * @return array $issList list of selected issue identifiers
	 */
	public static function listPidIssues($pid, $type=FALSE) {
		if (!$pid) return FALSE;

		$query = "SELECT * FROM lists ";
		$query .= "WHERE pid = $pid AND enddate IS NULL AND returndate IS NULL ";
		if ($type) $query = "AND type = '$type' ";
		$query .= "ORDER BY type, date, id";

		$results = sqlStatement($query);
	
		$isuList = array();
		while ($data = sqlFetchArray($results)) {
			$isuList[] = $data['id'];
		}
		
		return $isuList;
	}

	/**
	 * Returns an array issue objects associated with the
	 * given PID and optionally a given TYPE. If no TYPE is given
	 * then all issues for the PID are returned.
	 * 
	 * @static
	 * @param int $pid patient identifier
	 * @param string $type type of issue to select
	 * @return array $issList list of selected issue identifiers
	 */
	public static function fetchPidIssues($pid, $type=FALSE) {
		if (!$pid) return FALSE;

		$query = "SELECT * FROM lists ";
		$query .= "WHERE pid = $pid AND enddate IS NULL AND returndate IS NULL ";
		if ($type) $query = "AND type = '$type' ";
		$query .= "ORDER BY type, date, id";

		$results = sqlStatement($query);
	
		$isuList = array();
		while ($data = sqlFetchArray($results)) {
			$isuList[] = new wmtDiagnosis($data['id']);
		}
		
		return $isuList;
	}
}
	
/** 
 * Provides standardized error reporting helper functions for the 'errors'
 * database table.
 *
 * @package Dermatology
 * @subpackage Diagnosis
 */
class wmtDiagnosis extends wmtIssue {
	public $dx_id;
	public $dx_date;
	public $dx_pid;
	public $dx_list_id;
	public $dx_form_name;
	public $dx_form_id;
	public $dx_form_title;
	
	/**
	 * Constructor for the 'error' class which retrieves the requested 
	 * error record from the database of creates an empty object.
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public function __construct($id = false) {
		if(!$id) return false;

		// get standard part of the issue
		try {
			parent::__construct($id);
		}
		catch (Exception $e) {
			// should log this as an error
			$this->id = NULL;
		}
				
		// try and retrieve extended issue (with diagnosis)
		$query = "SELECT * FROM form_derm_dx_issue WHERE list_id = $id";
		$results = sqlStatement($query);

		// check for child data
		if ($data = sqlFetchArray($results)) {
			if (!$this->id) {
				// found child with no parent, get rid of child
				sqlStatement("DELETE FROM form_derm_dx_issue WHERE id = ".$data['id']);
			}
			else {
				// add child data to object
				$this->dx_id = $data['id'];
				$this->dx_date = $data['date'];
				$this->dx_pid = $data['pid'];
				$this->dx_list_id = $data['list_id'];
				$this->dx_form_name = $data['form_name'];
				$this->dx_form_id = $data['form_id'];
				$this->dx_form_title = $data['form_title'];
			}
		}
	}
		
	/**
	 * Inserts data from an error object into the database.
	 * 
	 * @static
	 * @param Errors $iderror_object
	 * @return null
	 */
	public static function insert(wmtDiagnosis $object) {
		if($object->id) {
			throw new Exception("wmtDiagnosis::insert - object already contains identifier");
		}

		// insert parent record first
		$parent_id = parent::insert($object);
		
		// add generic diagnosis record
		$enc_date = ($object->date) ? "'$object->date'" : "NULL";

		$object->id = sqlInsert("INSERT INTO form_derm_dx_issue SET " .
			"date = '$enc_date', " .
			"pid = '$object->pid', " .
			"list_id = '$parent_id', " .
			"form_name = '$object->dx_form_name', " .
			"form_title = '$object->dx_form_title'");
		
		return $parent_id;
	}

	/**
	 * Delete diagnosis record from the database and unlink.
	 * 
	 * @static
	 * @param Errors $iderror_object
	 * @return null
	 */
	public static function delete($id) {
		if(!$id) {
			throw new Exception("wmtDiagnosis::delete - no identifier provided");
		}

		// insert parent record first
		$parent_id = parent::insert($object);
		
		// add generic diagnosis record
		$enc_date = ($object->date) ? "'$object->date'" : "NULL";

		$object->id = sqlInsert("INSERT INTO form_derm_dx_issue SET " .
			"date = '$enc_date', " .
			"pid = '$object->pid', " .
			"list_id = '$parent_id', " .
			"form_name = '$object->dx_form_name', " .
			"form_title = '$object->dx_form_title'");
		
		return $parent_id;
	}

	/**
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public static function linkSingle($pid, $encounter, $issue) {
		if (!$pid || !$encounter || !issue) {
			throw new Exception('wmtDiagnosis::linkSingle - missing required data elements');
		}

		// remove old links
		sqlStatement("DELETE FROM issue_encounter WHERE " .
  			"pid = '$pid' AND encounter = '$encounter' AND list_id = '$issue' ");
		
		// add new link
		$query = "INSERT INTO issue_encounter SET ";
		$query .= "pid = '$pid', list_id = '$issue', encounter = '$encounter' ";
	    sqlStatement ($query);
		
		return;
	}

	/**
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public static function linkDiagnosis($pid, $encounter, $issues) {
		if (!$pid || !$encounter || !is_array($issues)) {
			throw new Exception('wmtDiagnosis::linkDiagnosiss - missing required data elements');
		}

		// remove old links
		sqlStatement("DELETE FROM issue_encounter WHERE " .
  			"pid = '$pid' AND encounter = '$encounter'");
		
		// add new links
		foreach ($issues as $issue) {
			$query = "INSERT INTO issue_encounter SET ";
			$query .= "pid = '$pid', list_id = '$issue', encounter = '$encounter' ";
		    sqlStatement ($query);
		}
		
		return;
	}

	/**
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public static function getDiagnosis($pid) {
		if (!$pid) return FALSE;

		$query = "SELECT l.id, ie.encounter FROM issue_encounter ie ";
		$query .= "LEFT JOIN lists l ON ie.list_id = l.id ";
		$query .= "WHERE ie.pid = $pid AND l.enddate IS NULL AND l.returndate IS NULL ";
		$query .= "ORDER BY l.date, l.id";

		$results = sqlStatement($query);
	
		$txList = array();
		while ($data = sqlFetchArray($results)) {
			$txList[] = array('id' => $data['id'], 'encounter' => $data['encounter']);
		}
		
		return $txList;
	}
	
	/**
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public function getTxEncounter($encounter) {
		if (!$encounter) {
			throw new Exception('wmtDiagnosis::getTxEncounter - no encounter identifier provided');
		}

		$query = "SELECT l.id FROM issue_encounter ie ";
		$query .= "LEFT JOIN lists l ON ie.list_id = l.id ";
		$query .= "WHERE ie.pid = $pid AND l.enddate IS NULL AND l.returndate IS NULL ";
		$query .= "AND ie.encounter = '$this->encounter' ";
		$query .= "ORDER BY l.date, l.id";

		$results = sqlStatement($query);
	
		$txList = array();
		while ($data = sqlFetchArray($results)) {
			$txList[] = new wmtDiagnosis($data['id']);
		}
		
		return $txList;
	}

	/**
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public function getTxForm($form_id) {
		if (!$form_id) {
			throw new Exception('wmtDiagnosis::getTxForm - no form identifier provided');
		}

		$query = "SELECT dx.list_id FROM form_derm_dx_issue dx ";
		$query .= "LEFT JOIN lists l ON dx.list_id = l.id ";
		$query .= "WHERE dx.form_id = $form_id AND l.enddate IS NULL AND l.returndate IS NULL ";
		$query .= "ORDER BY l.date, l.id";

		$results = sqlStatement($query);
	
		$txList = array();
		while ($data = sqlFetchArray($results)) {
			$txList[] = $data['id'];
		}
		
		return $txList;
	}
}
		

/**
 * Provides standardized base class for an encounter which
 * is typically extended for specific types of encounters.
 *
 * @package WMT
 * @subpackage Encounter
 */
class wmtEncounter {
	public $id;
	public $date;
	public $reason;
	public $facility;
	public $facility_id;
	public $pid;
	public $encounter;
	public $onset_date;
	public $sensitivity;
	public $billing_note;
	public $pc_catname;
	public $pc_catid;
	public $provider_id;
	public $supervisor_id;
	public $referral_source;
	public $billing_facility;

	/**
	 * Constructor for the 'encounter' class which retrieves the requested
	 * record from the database or creates an empty object.
	 *
	 * @param int $id record identifier
	 * @return object instance of class
	 */
	public function __construct($id = false) {
		if(!$id) return false;

		$query = "SELECT fe.*, pc.pc_catname FROM form_encounter fe ";
		$query .= "LEFT JOIN openemr_postcalendar_categories pc ON fe.pc_catid = pc.pc_catid ";
		$query .= "WHERE fe.id = $id ";
		$query .= "ORDER BY fe.date, fe.id";
		$results = sqlStatement($query);

		if ($data = sqlFetchArray($results)) {
			// load everything returned into object
			foreach ($data as $key => $value) {
				if ($key == 'date' || $key == 'onset_date') {
					$value = ($value)? date('Y-m-d', strtotime($value)) : '';
				}
				$this->$key = $value;
			}
		}
		else {
			throw new Exception('wmtEncounter::_construct - no encounter record with id ('.$id.').');
		}
	}

	/**
	 * Inserts data from an error object into the database.
	 *
	 * @static
	 * @param Errors $iderror_object
	 * @return null
	 */
	public static function insert(wmtEncounter $object) {
		if($object->id) {
			throw new Exception ("wmtEncounter::insert - object already contains identifier");
		}

		// get facility name from id
		$fres = sqlQuery("SELECT name FROM facility WHERE id = $object->facility_id");
		$facility = $fres['name'];

		// create basic encounter
		$object->encounter = generate_id(); // in sql.inc

		// add base record
		$enc_date = ($object->date) ? "$object->date" : "date('Y-m-d)";
		$onset_date = ($object->onset_date) ? "'$object->onset_date'" : "null";

		$object->id = sqlInsert("INSERT INTO form_encounter SET " .
				"date = '$enc_date', " .
				"onset_date = $onset_date, " .
				"reason = '$object->reason', " .
				"facility = '$facility', " .
				"pc_catid = '$object->pc_catid', " .
				"facility_id = '$object->facility_id', " .
				"billing_facility = '$object->billing_facility', " .
				"sensitivity = '$object->sensitivity', " .
				"referral_source = '$object->referral_source', " .
				"pid = '$object->pid', " .
				"encounter = '$object->encounter', " .
				"provider_id = '$object->provider_id'");

		return $object->id;
	}

	/**
	 * Updates data from an object into the database.
	 *
	 * @static
	 * @param wmtEncounter $object
	 * @return null
	 */
	public function update() {
		if(!$this->id) {
			throw new Exception ("wmtEncounter::update - object contains no identifier");
		}

		// get facility name from id
		$fres = sqlQuery("SELECT name FROM facility WHERE id = $this->facility_id");
		$facility = $fres['name'];

		// update basic encounter
		$enc_date = ($this->date) ? "$this->date" : "date('Y-m-d')";
		$onset_date = ($this->onset_date) ? "$this->onset_date" : "$enc_date";

		sqlInsert("UPDATE form_encounter SET " .
				"date = '$enc_date', " .
				"onset_date = '$onset_date', " .
				"reason = '$this->reason', " .
				"facility = '$facility', " .
				"pc_catid = '$this->pc_catid', " .
				"facility_id = '$this->facility_id', " .
				"billing_facility = '$this->billing_facility', " .
				"sensitivity = '$this->sensitivity', " .
				"referral_source = '$this->referral_source', " .
				"pid = '$this->pid', " .
				"encounter = '$this->encounter', " .
				"provider_id = '$this->provider_id' " .
				"WHERE id = '$this->id'");

		return;
	}

	/**
	 *
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public static function listPidEncounters($pid) {
		if (!$pid) return FALSE;

		$query = "SELECT fe.encounter, fe.id FROM form_encounter fe ";
		$query .= "LEFT JOIN issue_encounter ie ON fe.id = ie.list_id ";
		$query .= "LEFT JOIN lists l ON ie.list_id = l.id ";
		$query .= "WHERE fe.pid = $pid AND l.enddate IS NULL ";
		$query .= "ORDER BY fe.date, fe.encounter";

		$results = sqlStatement($query);

		$txList = array();
		while ($data = sqlFetchArray($results)) {
			$txList[] = array('id' => $data['id'], 'encounter' => $data['encounter']);
		}

		return $txList;
	}

	/**
	 *
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public static function getEncounter($encounter) {
		if (!$encounter) return FALSE;

		$query = "SELECT id FROM form_encounter WHERE encounter = '$encounter' ";
		$results = sqlStatement($query);
		$data = sqlFetchArray($results);

		return new wmtEncounter($data['id']);
	}

	/**
	 *
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public static function dupCheck($pid) {
		if (!$pid) return FALSE;

		$query = "SELECT count(*) AS count FROM form_encounter fe, forms f ";
		$query .= "WHERE fe.pid = '$pid' AND fe.date = '" . date('Y-m-d 00:00:00') . "' ";
		$query .= "AND f.formdir = 'newpatient' AND f.form_id = fe.id AND f.deleted = 0";
		$data = sqlQuery($query);

		return ($data['count'] > 0)? true : false;
	}
}


/** 
 * Provides standardized error reporting helper functions for the 'errors'
 * database table.
 *
 * @package Dermatology
 * @subpackage Encounter
 */
class XXwmtAssessment {
	public $id;
	public $date;
	public $reason;
	public $facility;
	public $facility_id;
	public $pid;
	public $encounter;
	public $onset_date;
	public $sensitivity;
	public $billing_note;
	public $catid;
	public $catname;
	public $provider_id;
	public $supervisor_id;
	public $referral_source;
	public $billing_facility;
	public $problem_history;
	public $followup;
	public $nurse_notes;
	public $doctor_notes;
	public $doctor_approved;
	public $vitals_id;
	
	private $derm_id;
	private $derm_encounter;
	
	
	
	/**
	 * Constructor for the 'error' class which retrieves the requested 
	 * error record from the database of creates an empty object.
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public function __construct($id = false) {
		if(!$id) {
			// create basic encounter
			$this->encounter = generate_id(); // in sql.inc
			return;
		}		
		
		$query = "SELECT fe.*, de.id as dx_id, de.problem_history, de.nurse_notes, de.doctor_notes, de.doctor_approved, de.followup, de.vitals_id, pc.pc_catname FROM form_encounter fe ";
		$query .= "LEFT JOIN form_derm_encounter de ON fe.encounter = de.encounter ";
		$query .= "LEFT JOIN openemr_postcalendar_categories pc ON fe.pc_catid = pc.pc_catid ";
		$query .= "WHERE fe.id = $id ";
		$query .= "ORDER BY fe.date, fe.id";
		$results = sqlStatement($query);
	
		if ($data = sqlFetchArray($results)) {
			$this->id = $data['id'];
			$this->date = ($data['date'])? date('Y-m-d',strtotime($data['date'])) : '';
			$this->reason = $data['reason'];
			$this->facility = $data['facility'];
			$this->facility_id = $data['facility_id'];
			$this->referral_source = $data['referral_source'];
			$this->pid = $data['pid'];
			$this->encounter = $data['encounter'];
			$this->onset_date = ($data['onset_date'])? date('Y-m-d',strtotime($data['onset_date'])) : '';
			$this->sensitivity = $data['sensitivity'];
			$this->billing_note = $data['billing_note'];
			$this->catid = $data['pc_catid'];
			$this->catname = $data['pc_catname'];
			$this->provider_id = $data['provider_id'];
			$this->supervisor_id = $data['supervisor_id'];
			$this->billing_facility = $data['billing_facility'];
			$this->derm_id = $data['dx_id'];
			$this->followup = $data['followup'];
			$this->problem_history = $data['problem_history'];
			$this->nurse_notes = $data['nurse_notes'];
			$this->doctor_notes = $data['doctor_notes'];
			$this->doctor_approved = $data['doctor_approved'];
			$this->vitals_id = $data['vitals_id'];
		}
		else {
			throw new Exception('wmtEncounter::_construct - no encounter record with id ('.$id.').');
		}
	}	
		
	/**
	 * Inserts data from an error object into the database.
	 * 
	 * @static
	 * @param Errors $iderror_object
	 * @return null
	 */
	public static function insert(wmtEncounter $object) {
		if($object->id) {
			throw new Exception ("wmtEncounter::insert - object already contains identifier");
		}

		// get facility name from id
//		$fres = sqlQuery("SELECT name FROM facility WHERE id = $object->facility_id");
//		$facility = $fres['name'];

		// set appropriate default values
		$object->pid = ($object->pid)? $object->pid : $_SESSION['pid'];
		$object->groupname = ($object->groupname)? $object->groupname : $_SESSION['authProvider'];
		$object->user = ($object->user)? $object->user : $_SESSION['authUser'];
		$object->authorized = ($object->authorized)? $object->authorized : $_SESSION['userauthorized'];
		$object->activity = 1;
		
		// add base record
		$enc_date = ($object->date) ? "'$object->date'" : date('Y-m-d');
		$onset_date = ($object->onset_date) ? "'$object->onset_date'" : "NULL";

		$object->id = sqlInsert("INSERT INTO form_encounter SET " .
			"date = $enc_date, " .
			"onset_date = $onset_date, " .
			"reason = '$object->reason', " .
			"facility = '$object->facility', " .
			"pc_catid = '$object->catid', " .
			"facility_id = '$object->facility_id', " .
			"billing_facility = '$object->billing_facility', " .
			"sensitivity = '$object->sensitivity', " .
			"referral_source = '$object->referral_source', " .
			"pid = '$object->pid', " .
			"encounter = '$object->encounter', " .
			"provider_id = '$object->provider_id'");

		// add derm specific data
		$dxId = sqlInsert("INSERT INTO form_derm_encounter SET " .
			"date = '$object->date', " .
			"pid = '$object->pid', " .
			"encounter = '$object->encounter', " .
			"followup = '$object->followup', " .
			"problem_history = '$object->problem_history', " .
			"nurse_notes = '$object->nurse_notes', " .
			"doctor_notes = '$object->doctor_notes', " .
			"vitals_id = '$object->vitals_id', " .
			"doctor_approved = '$object->doctor_approved'");
		
		return $object->id;
	}

	/**
	 * Inserts data from an error object into the database.
	 * 
	 * @static
	 * @param Errors $iderror_object
	 * @return null
	 */
	public function update() {
		if(!$this->id) {
			throw new Exception ("wmtEncounter::update - object contains no identifier");
		}
		
		// get facility name from id
		$fres = sqlQuery("SELECT name FROM facility WHERE id = $this->facility_id");
		$facility = $fres['name'];

		// update basic encounter
		$enc_date = ($this->date) ? "'$this->date'" : "NULL";
		$onset_date = ($this->onset_date) ? "'$this->onset_date'" : "NULL";

		sqlInsert("UPDATE form_encounter SET " .
			"date = $enc_date, " .
			"onset_date = $onset_date, " .
			"reason = '$this->reason', " .
			"facility = '$facility', " .
			"pc_catid = '$this->catid', " .
			"facility_id = '$this->facility_id', " .
			"billing_facility = '$this->billing_facility', " .
			"sensitivity = '$this->sensitivity', " .
			"referral_source = '$this->referral_source', " .
			"pid = '$this->pid', " .
			"encounter = '$this->encounter', " .
			"provider_id = '$this->provider_id' " .
			"WHERE id = '$this->id'");

		// update derm specific data
		sqlInsert("UPDATE form_derm_encounter SET " .
			"date = '$this->date', " .
			"pid = '$this->pid', " .
			"encounter = '$this->encounter', " .
			"followup = '$this->followup', " .
			"problem_history = '$this->problem_history', " .
			"nurse_notes = '$this->nurse_notes', " .
			"doctor_notes = '$this->doctor_notes', " .
			"vitals_id = '$this->vitals_id', " .
			"doctor_approved = '$this->doctor_approved' " .
			"WHERE id = '$this->derm_id'");
				
		return;
	}

	/**
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public static function listPidEncounters($pid) {
		if (!$pid) return FALSE;

		$query = "SELECT fe.encounter, fe.id FROM form_encounter fe ";
		$query .= "LEFT JOIN issue_encounter ie ON fe.id = ie.list_id ";
		$query .= "LEFT JOIN lists l ON ie.list_id = l.id ";
		$query .= "WHERE fe.pid = $pid AND l.enddate IS NULL ";
		$query .= "ORDER BY fe.date, fe.encounter";

		$results = sqlStatement($query);
	
		$txList = array();
		while ($data = sqlFetchArray($results)) {
			$txList[] = array('id' => $data['id'], 'encounter' => $data['encounter']);
		}
		
		return $txList;
	}

	/**
	 * 
	 * @param int $id lists record identifier
	 * @return object instance of lists class
	 */
	public static function getEncounter($encounter) {
		if (!$encounter) return FALSE;

		$query = "SELECT id FROM form_encounter WHERE encounter = '$encounter' ";
		$results = sqlStatement($query);
		$data = sqlFetchArray($results);
		
		return new wmtEncounter($data['id']);
	}
}


/** 
 * Provides standardized error reporting helper functions for the 'errors'
 * database table.
 *
 * @package Dermatology
 * @subpackage Treatment
 */
class wmtTreatment {
	public $id;
	public $date;
	public $pid;
	public $user;
	public $groupname;
	public $authorized;
	public $activity;
	public $status;
	public $priority;

	public static function findPrevious($form_name, $pid) {
		if (!$form_name) {
			throw new Exception("wmtTreatment::findPrevious - no form name provided");
		}
		if (!$pid) {
			throw new Exception("wmtTreatment::findPrevious - no patient identifier provided");
		}

		$id = '';
		try {
			$query = "SELECT id FROM form_".$form_name." WHERE pid = '".$pid."' ORDER BY date DESC LIMIT 1";
			$results = sqlStatement($query);
			if ($data = sqlFetchArray($results)) {
				$id = $data['id'];
			}
		}
		catch(Exception $e) {
			$id = '';
		}
		
		return $id;
	}
}
	
/** 
 * Provides standardized error reporting helper functions for the 'errors'
 * database table.
 *
 * @package Dermatology
 * @subpackage Diagnosiss
 */
class wmtCategory {
	public $id;
	public $name;
	public $color;
	public $description;
	
	
	/**
	 * Constructor for the 'category' class which retrieves the requested 
	 * category record from the database or creates an empty object.
	 * 
	 * @param int $id category record identifier
	 * @return object instance of category class
	 */
	public function __construct($id = false) {
		if(!$id) return false;

		$query = "SELECT * FROM openemr_postcalendar_categories ";
		$query .= "WHERE pc_catid = $id ";
		$results = sqlStatement($query);
	
		if ($data = sqlFetchArray($results)) {
			$this->id = $data['pc_catid'];
			$this->name = $data['pc_catname'];
			$this->color = $data['pc_catcolor'];
			$this->description = $data['pc_catdesc'];
		}
		else {
			throw new Exception('wmtCategory::_construct - no category record with id ('.$this->id.').');
		}
	}	
		
	/**
	 * Returns an array of category IDs which may optionally be limited to
	 * only those records which are displayable.
	 * 
	 * @static
	 * @param boolean $display include only displayable categories
	 * @return object instance of lists class
	 */
	public static function listCategories($display = TRUE) {
		$query = "SELECT pc_catid FROM openemr_postcalendar_categories ";
		if ($display) $query .= "WHERE pc_catid = 5 OR pc_catid > 8 ";
		$query .= "ORDER BY pc_catname";

		$results = sqlStatement($query);
	
		$catList = array();
		while ($data = sqlFetchArray($results)) {
			$catList[] = $data['pc_catid'];
		}
		
		return $catList;
	}

	/**
	 * Returns an array of category data which may optionally be limited to
	 * only those records which are displayable.
	 * 
	 * @static
	 * @param boolean $display include only displayable categories
	 * @return object instance of lists class
	 */
	public static function fetchCategories($display = TRUE) {
		$query = "SELECT * FROM openemr_postcalendar_categories ";
		if ($display) $query .= "WHERE pc_catid = 5 OR pc_catid > 8 ";
		$query .= "ORDER BY pc_catname";

		$results = sqlStatement($query);
	
		$catData = array();
		while ($data = sqlFetchArray($results)) {
			$catList[] = new wmtCategory($data['pc_catid']);
		}
		
		return $catList;
	}
}
	
/** 
 * Provides standardized processing for most forms.
 *
 * @package WMT
 * @subpackage Forms
 */
class wmtForm {
	public $id;
	public $date;
	public $pid;
	public $user;
	public $groupname;
	public $authorized;
	public $activity;
	public $status;
	public $priority;
	
	// control elements
	protected $form_name;
	protected $form_table;
	protected $form_title;
	
	/**
	 * Constructor for the 'form' class which retrieves the requested 
	 * information from the database or creates an empty object.
	 * 
	 * @param string $form_table database table
	 * @param int $id record identifier
	 * @return object instance of form class
	 */
	public function __construct($form_name, $id = false) {
		if (!$form_name)
			throw new Exception('wmtForm::_construct - no form name provided.');

		// store table name in object
		$this->form_name = $form_name;
		$this->form_table = 'form_'.$form_name;
		
		// create empy record or retrieve
		if(!$id) return false;
		
		// retrieve data
		$query = "SELECT * FROM $this->form_table ";
		$query .= "WHERE id = $id AND activity = 1";
		$results = sqlStatement($query);
	
		if ($data = sqlFetchArray($results)) {
			// load everything returned into object
			foreach ($data as $key => $value) {
				$this->$key = $value;
			}
		}
		else {
			throw new Exception('wmtForm::_construct - no record with id ('.$id.').');
		}
		
		// preformat commonly used data elements
		$this->date = ($this->date)? date('Y-m-d',strtotime($this->date)) : date('Y-m-d');
		
		return;		
	}	

	/**
	 * Inserts data from a form object into the database.
	 * 
	 * @static
	 * @param wmtForm $object
	 * @return int $id identifier for new object
	 */
	public static function insert(wmtForm $object) {
		if(!$object->form_name || !$object->form_table)
			throw new Exception ("wmtForm::insert - object missing form information");

		if($object->id)
			throw new Exception ("wmtForm::insert - object already contains identifier");

		// set appropriate default values
		$object->date = ($object->date)? $object->date : date('Y-m-d');
		$object->pid = ($object->pid)? $object->pid : $_SESSION['pid'];
		$object->groupname = ($object->groupname)? $object->groupname : $_SESSION['authProvider'];
		$object->user = ($object->user)? $object->user : $_SESSION['authUser'];
		$object->authorized = ($object->authorized)? $object->authorized : $_SESSION['userauthorized'];
		$object->activity = 1;
		
		// build sql insert from object
		$query = '';
		$fields = wmtForm::listFields($object->form_name);
		foreach ($object as $key => $value) {
			if (!in_array($key, $fields) || $key == 'id') continue;
			$query .= ($query)? ", $key = " : "$key = ";
			$query .= ($value == 'NULL')? NULL : "'$value'";
		}
		
		// run the insert		
		$object->id = sqlInsert("INSERT INTO $object->form_table SET $query");
		
		return $object->id;
	}

	/**
	 * Updates database with information from the given object.
	 * 
	 * @return null
	 */
	public function update() {
		// set appropriate default values
		$object->date = ($object->date) ? "$this->date" : "NULL";
		$object->activity = 1;
				
		// build sql update from object
		$query = '';
		$fields = wmtForm::listFields($this->form_name);
		foreach ($this as $key => $value) {
			if (!in_array($key, $fields) || $key == 'id') continue;
			$query .= ($query)? ", $key = " : "$key = ";
			$query .= ($value == 'NULL')? NULL : "'$value'";
		}
		
		// run the update		
		sqlInsert("UPDATE $this->form_table SET $query WHERE id = $this->id");
		
		return;
	}
	
	/**
	 * Returns an array of valid database fields for the object.
	 * 
	 * @static
	 * @return array list of database field names
	 */
	public static function listFields($form_name) {
		if (!$form_name)
			throw new Exception('wmtForm::listFields - no form name provided.');
		
		$form_table = 'form_'.$form_name;
		$fields = sqlListFields($form_table);
		
		return $fields;
	}
	
}
	
/** 
 * Provides standardized helper functions for the 'derm_rto'
 * database table.
 *
 * @package Dermatology
 * @subpackage RTO
 */
class wmtRTO extends wmtForm {
	public $rto_num;
	public $rto_frame;
	public $rto_prn;
	public $rto_notes;
	
	/**
	 * Constructs a new object instance.
	 * 
	 * @param int $id record identifier
	 * @return object instance of class
	 */
	public function __construct($id = false) {
		parent::__construct('derm_rto', $id);
		return;
	}	
		
	/**
	 * Inserts data from a form object into the database.
	 * 
	 * @static
	 * @param wmtForm $object
	 * @return int $id identifier for new object
	 */
	public static function insert(wmtRTO $object) {
		if (!$object->rto_num && !$object->rto_frame && !$object->rto_prn && !$object->rto_notes) return false; // nothing to create
		
		$object->pid = $_SESSION['pid'];
		$object->date = date('Y-m-d');
		
		return parent::insert($object);
	}

	/**
	 * Retrieves information for the given encounter.
	 * 
	 * @static
	 * @param int encounter number
	 * @return $object
	 */
	public static function fetchEncounter($encounter = false) {
		$form_id = '';
		
		if ($encounter) { 
			// retrieve the id
			$query = "SELECT form_id FROM forms WHERE encounter = $encounter ";
			$query .= "AND formdir = 'derm_rto' AND deleted = 0 LIMIT 1";
			$data = sqlQuery($query);
			if ($data['form_id']) $form_id = $data['form_id'];
		}
		
		$object = new wmtRTO($form_id); // retrieve/create record
		return $object;
	}
	
}
	
/** 
 * Provides standardized helper functions for the 'derm_assessment'
 * database table.
 *
 * @package Dermatology
 * @subpackage Assessment
 */
class wmtAssessment extends wmtForm {
	public $complaint;
	public $history;
	public $nurse_notes;
	public $doctor_notes;
	public $doctor_approved;
	
	/**
	 * Constructs a new object instance.
	 * 
	 * @param int $id record identifier
	 * @return object instance of class
	 */
	public function __construct($id = false) {
		parent::__construct('derm_assessment', $id);
		return;
	}	
		
	/**
	 * Inserts data from a form object into the database.
	 * 
	 * @static
	 * @param wmtForm $object
	 * @return int $id identifier for new object
	 */
	public static function insert(wmtAssessment $object) {
		$object->pid = $_SESSION['pid'];
		$object->date = date('Y-m-d');
		
		return parent::insert($object);
	}

	/**
	 * Retrieves information for the given encounter.
	 * 
	 * @static
	 * @param int encounter number
	 * @return $object
	 */
	public static function fetchEncounter($encounter = false) {
		$form_id = '';
		
		if ($encounter) { 
			// retrieve the id
			$query = "SELECT form_id FROM forms WHERE encounter = $encounter ";
			$query .= "AND formdir = 'derm_assessment' AND deleted = 0 LIMIT 1";
			$data = sqlQuery($query);
			if ($data['form_id']) $form_id = $data['form_id'];
		}
		
		$object = new wmtAssessment($form_id); // retrieve/create record
		return $object;
	}
	
}
?>