<?php 
echo "<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "	<tr>\n";
echo "		<td class='LabelCenterBorderB' style='width: 95px'>Date</td>\n";
echo "		<td class='LabelCenterBorderLB'>Type of Surgery</td>\n";
echo "		<td class='LabelCenterBorderLB'>Notes</td>\n";
echo "		<td class='LabelCenterBorderLB'>Performed By</td>\n";
if(acl_check('admin','super') && $unlink_allow) {
	echo "		<td class='LabelBorderLB' style='width: 175px'>&nbsp;</td>\n";
} else if($unlink_allow) {
	echo "		<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else if(acl_check('admin','super')) {
	echo "		<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else {
	echo "		<td class='LabelBorderLB' style='width: 65px'>&nbsp;</td>\n";
}
echo "	</tr>\n";
$cnt=1;
if(isset($surg)) {
	foreach($surg as $prev) {
		echo "<tr>\n";
		echo "<td class='BodyBorderB'><input name='ps_id_$cnt' id='ps_id_$cnt' type='hidden' readonly='readonly' value='".$prev['id']."' /><input name='ps_num_links_$cnt' id='ps_num_links_$cnt' type='hidden' tabindex='-1' value='".$prev['num_links']."' /><input name='ps_begdate_".$cnt."' id='ps_begdate_".$cnt."' class='FullInput' type='text' tabindex='-1' value='".$prev['begdate']."' /></td>\n";
		echo "<td class='BodyBorderLB'><input name='ps_title_$cnt' id='ps_title_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['title']."' /></td>\n";
		echo "<td class='BodyBorderLB'><input name='ps_comments_$cnt' id='ps_comments_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['comments']."' /></td>\n";
		echo "<td class='BodyBorderLB'><input name='ps_referredby_$cnt' id='ps_referredby_$cnt' class='FullInput' type='text' tabindex='-1' value='".$prev['referredby']."' /></td>\n";
		echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdateSurgery(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a>";
		if($unlink_allow) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return UnlinkSurgery(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Un-Link</span></a>\n";
		}
		if(acl_check('admin','super')) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return DeleteSurgery(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\",\"{$prev['num_links']}\");' href='javascript:;'><span>Delete</span></a>\n";
		}
		echo "</td>\n";
		echo "</tr>\n";
		$cnt++;
	}
}
echo "	<tr>\n";
echo "		<td class='BodyBorderB'><input name='ps_begdate' id='ps_begdate' class='FullInput' type='text' title='YYYY-MM-DD' value='".$dt{'ps_begdate'}."' /></td>\n";
echo "		<td class='BodyBorderLB'><input name='ps_title' id='ps_title' class='FullInput' type='text' value='".$dt{'ps_title'}."' /></td>\n";
echo "		<td class='BodyBorderLB'><input name='ps_comments' id='ps_comments' class='FullInput' type='text' value='".$dt{'ps_comments'}."' /></td>\n";
echo "		<td class='BodyBorderLB'><input name='ps_referredby' id='ps_referredby' class='FullInput' type='text' value='".$dt{'ps_referredby'}."' /></td>\n";
echo "		<td class='BodyBorderLB'>&nbsp;</td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td class='CollapseBar' colspan='6'><a class='css_button' onClick='return SubmitSurgery(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a></td>\n";
echo "	</tr>\n";
echo "</table>\n";
?>
