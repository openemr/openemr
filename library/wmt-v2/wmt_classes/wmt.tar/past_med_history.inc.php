<?php
echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo "		<tr>\n";
echo "			<td class='LabelCenterBorderB'>Issue</td>\n";
echo "			<td class='LabelCenterBorderLB'>Notes</td>\n";
if(acl_check('admin','super') && $unlink_allow) {
	echo "			<td class='LabelBorderLB' style='width: 175px'>&nbsp;</td>\n";
} else if($unlink_allow) {
	echo "			<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else if(acl_check('admin','super')) {
	echo "			<td class='LabelBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else {
	echo "			<td class='LabelBorderLB' style='width: 65px'>&nbsp;</td>\n";
}
echo "		</tr>\n";
$cnt=1;
if(isset($pmh) && (count($pmh) > 0)) {
	foreach($pmh as $prev) {
		echo "<tr>\n";
		echo "<td class='BodyBorderB'><input name='pmh_id_$cnt' id='pmh_id_$cnt' type='hidden' readonly='readonly' value='".$prev['id']."' /><input name='pmh_num_links_$cnt' id='pmh_num_lniks_$cnt' type='hidden' tabstop='-1' value='".$prev['pmh_num_links']."' /><select name='pmh_type_$cnt' id='pmh_type_$cnt' class='FullInput' tabindex='-1'>\n";
		echo ListSelAlpha($prev['pmh_type'],'Medical_History_Problems');
		echo "</select></td>\n";
		echo "<td class='BodyBorderLB'><input name='pmh_nt_".$cnt."' id='pmh_nt_".$cnt."' class='FullInput' type='text' tabindex='-1' value='".$prev['pmh_nt']."' /></td>\n";
		echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdateMedicalHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a>";
		if($unlink_allow) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return UnlinkMedicalHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Un-Link</span></a>\n";
		}
		if(acl_check('admin','super')) {
			echo "<a class='css_button_small' tabindex='-1' onClick='return DeleteMedicalHistory(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\",\"{$prev['pmh_num_links']}\");' href='javascript:;'><span>Delete</span></a>\n";
		}
		echo "</td>\n";
		echo "</tr>\n";
		$cnt++;
	}
}
echo "		<tr>\n";
echo "			<td class='BodyBorderB'><select name='pmh_type' id='pmh_type' class='FullInput'>\n";
ListSelAlpha($dt{'pmh_type'},'Medical_History_Problems');
echo "			</select></td>\n";
echo "			<td class='BodyBorderLB'><input name='pmh_nt' id='pmh_nt' class='FullInput' type='text' value='",$dt{'pmh_nt'},"' /></td>\n";
echo "			<td class='BodyBorderLB'>&nbsp;</td>\n";
echo "		</tr>\n";
echo "		</tr>\n";
echo "			<td class='CollapseBar' colspan='3'><a class='css_button' onClick='return SubmitMedicalHistory(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a>&nbsp;&nbsp;<a class='css_button' onClick='return add_item(\"pmh_type\",\"Medical_History_Problems\");' href='javascript:;'><span>Add A Problem Type</span></a></td>\n";
echo "		</tr>\n";
echo "		</table>\n";
?>
