<?php
echo "<table width='100%'	border='0' cellspacing='0' cellpadding='0'>\n";
echo "	<tr>\n";
echo "		<td class='LabelCenterBorderB DateCell'>Date</td>\n";
echo "		<td class='LabelCenterBorderLB' colspan='2'>Lab/Test/Result</td>\n";
echo "		<td class='LabelCenterBorderLB'>Comments</td>\n";
echo "		<td class='LabelCenterBorderLB' style='width: 65px'>&nbsp;</td>\n";
echo "	</tr>\n";
$cnt=1;
$tab_base=100;
foreach($pap_data as $pap) {
	echo "	<tr>\n";
	echo "		<td class='DateCell'>\n";
	$tmp=($tab_base * $cnt);
	echo "		<input name='pt_date_$cnt' id='pt_date_$cnt' class='DateInput' type='text' value='".$pap['pt_date']."' title='YYYY-MM-DD' tabindex='$tmp'/></td>\n";
	$tmp=($tab_base * $cnt)+10;
	echo "		<td class='BodyBorderL'><select name='pt_lab_$cnt' id='pt_lab_$cnt' class='Input' tabindex='$tmp'>\n";
	echo ListSel($pap['pt_lab'], 'PT_Labs');
	echo "		</select>\n";
	echo "		<input name='pt_id_$cnt' id='pt_id_$cnt' type='hidden' value='".$pap['id']."' /></td>\n";
	$tmp=($tab_base * $cnt)+20;
	echo "		<td class='Body'><select name='pt_test_$cnt' id='pt_test_$cnt' class='Input' tabindex='$tmp'>\n";
	echo ListSel($pap['pt_test'], 'PT_Tests');
	echo "		</select></td>\n";
	echo "		<td class='BodyBorderLB' rowspan='2'>\n";
	$tmp=($tab_base * $cnt)+40;
	echo "		<textarea name='pt_result_nt_$cnt' id='pt_result_nt_$cnt' class='FullInput' rows='2' tabindex='$tmp'>".$pap['pt_result_nt']."</textarea>\n";
	echo "		<td class='BodyBorderL'><a class='css_button_small' tabindex='-1' onClick='return UpdatePap(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;'><span>Update</span></a></td>\n";
	echo "		</td>\n";
	echo "	</tr>\n";
	echo "	<tr>\n";
	echo "		<td class='BodyBorderB'>&nbsp;<input name='pt_num_links_$cnt' id='pt_num_links_$cnt' type='hidden' tabindex='-1' value='".$pap['pt_num_links']."' />\n";
	if(acl_check('admin','super')) {
		echo "<a class='css_button_small' tabindex='-1' onClick='return DeletePap(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\",\"{$pap['pt_num_links']}\");' href='javascript:;'><span>Delete</span></a>\n";
	}
	echo "</td>\n";
	$tmp=($tab_base * $cnt)+30;
	echo "		<td class='BodyBorderLB' colspan='2'><select name='pt_result_$cnt' id='pt_result_$cnt' class='Input' tabindex='$tmp'>\n";
	echo ListSel($pap['pt_result'],'PT_Results');
	echo "		</select>&nbsp;&nbsp;\n";
	$tmp=($tab_base * $cnt)+35;
	echo "		<select name='pt_hpv_result_$cnt' id='pt_hpv_result_$cnt' class='Input' tabindex='$tmp'>\n";
	echo ListSel($pap['pt_hpv_result'],'PT_HPV_Results');
	echo "		</select></td>\n";
	if($unlink_allow) {
		echo "		<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UnlinkPap(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;' title='Un-link this pap tracking entry from this visit'><span>Un-Link</span></a></td>\n";
	} else {
		echo "		<td class='BodyBorderLB'>&nbsp;</td>\n";
	}
	echo "</tr>\n";
	$cnt++;
}
echo "	<tr>\n";
echo "		<td class='DateCell'>\n";
$tmp=$tab_base*$cnt;
echo "		<input name='pt_date' id='pt_date' class='DateInput' type='text' value='".$dt['pt_date']."' title='YYYY-MM-DD'  tabindex='$tmp' /></td>\n";
$tmp=($tab_base*$cnt)+10;
echo "		<td class='BodyBorderL'><select name='pt_lab' id='pt_lab' class='Input' tabindex='$tmp'>\n";
echo ListSel($dt['pt_lab'], 'PT_Labs');
echo "		</select>\n";
echo "		<input name='tmp_pap_cnt' id='tmp_pap_cnt' type='hidden' tabindex='-1' value='".($cnt - 1)."' /></td>\n";
$tmp=($tab_base*$cnt)+20;
echo "		<td class='Body'><select name='pt_test' id='pt_test' class='Input' tabindex='$tmp'>\n";
echo ListSel($dt['pt_test'], 'PT_Tests');
echo "		</select></td>\n";
echo "		<td class='BodyBorderLB' rowspan='2'>\n";
$tmp=($tab_base*$cnt)+40;
echo "		<textarea name='pt_result_nt' id='pt_result_nt' class='FullInput' rows='2' tabindex='$tmp'>".$dt['pt_result_nt']."</textarea>\n";
echo "		</td>\n";
echo "		<td class='BodyBorderLB' rowspan='2'>&nbsp;</td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td class='BodyBorderB'>&nbsp;</td>\n";
$tmp=($tab_base*$cnt)+30;
echo "		<td class='BodyBorderLB' colspan='2'><select name='pt_result' id='pt_result' class='Input' tabindex='$tmp'>\n";
echo ListSel($dt['pt_result'],'PT_Results');
echo "		</select>&nbsp;&nbsp;\n";
$tmp=($tab_base*$cnt)+35;
echo "		<select name='pt_hpv_result' id='pt_hpv_result' class='Input' tabindex='$tmp'>\n";
echo ListSel($dt['pt_hpv_result'],'PT_HPV_Results');
echo "		</select></td>\n";
echo "	</tr>\n";
echo "	<tr>\n";
echo "		<td class='CollapseBar' colspan='3'><a class='css_button' onClick='return SubmitPap(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a></td>\n";
echo "		<td class='CollapseBar' colspan='2'><a class='css_button' style='float: right; padding-right: 15px;' href='javascript:PopRTO();'><span>Orders/RTO</span></a></td>\n";
echo "	</tr>\n";
echo "</table>\n";
?>
