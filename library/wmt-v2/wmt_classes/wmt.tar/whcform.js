function toggleHistoryToNo()
{
  var i;
  var l = document.acog_a.elements.length;
  for (i=0; i<l; i++) {
    var tmp = document.acog_a.elements[i].name;
    if(document.acog_a.elements[i].name.indexOf("aa_mh_") != -1) {
      if(document.acog_a.elements[i].id.indexOf("_no") != -1) {
        document.acog_a.elements[i].checked = true;
        document.acog_a.elements[i].value = '1';
      }
      if(document.acog_a.elements[i].id.indexOf("_yes") != -1) {
        document.acog_a.elements[i].checked = false;
      }
    }
  }
}

function toggleHistoryToNull()
{
  var i;
  var l = document.acog_a.elements.length;
  for (i=0; i<l; i++) {
    if(document.acog_a.elements[i].name.indexOf("aa_mh_") != -1) {
      document.acog_a.elements[i].checked = false;
      document.acog_a.elements[i].value = '';
    }
  }
}

function toggleBreast(which, tag)
{
  var i=510;
  if(tag == "r") i=710;
  if(document.getElementById(which).checked == true) {
    document.getElementById('w6_'+tag+'size_note').tabIndex=i; 
    document.getElementById('w6_'+tag+'location').tabIndex=i+10; 
    document.getElementById('w6_'+tag+'duration').tabIndex=i+20; 
    document.getElementById('w6_'+tag+'consist_soft').tabIndex=i+30; 
    document.getElementById('w6_'+tag+'consist_soft_note').tabIndex=i+40; 
    document.getElementById('w6_'+tag+'consist_firm').tabIndex=i+50; 
    document.getElementById('w6_'+tag+'consist_firm_note').tabIndex=i+60; 
    document.getElementById('w6_'+tag+'consist_mobile').tabIndex=i+70; 
    document.getElementById('w6_'+tag+'consist_mobile_note').tabIndex=i+80; 
    document.getElementById('w6_'+tag+'pre_meno').tabIndex=i+90; 
    document.getElementById('w6_'+tag+'post_meno').tabIndex=i+100; 
  } else {
    document.getElementById('w6_'+tag+'size_note').tabIndex=-1; 
    document.getElementById('w6_'+tag+'location').tabIndex=-1; 
    document.getElementById('w6_'+tag+'duration').tabIndex=-1; 
    document.getElementById('w6_'+tag+'consist_soft').tabIndex=-1; 
    document.getElementById('w6_'+tag+'consist_soft_note').tabIndex=-1; 
    document.getElementById('w6_'+tag+'consist_firm').tabIndex=-1; 
    document.getElementById('w6_'+tag+'consist_firm_note').tabIndex=-1; 
    document.getElementById('w6_'+tag+'consist_mobile').tabIndex=-1; 
    document.getElementById('w6_'+tag+'consist_mobile_note').tabIndex=-1; 
    document.getElementById('w6_'+tag+'pre_meno').tabIndex=-1; 
    document.getElementById('w6_'+tag+'post_meno').tabIndex=-1; 
  }
}

function toggleROStoNo()
{
  var i;
  var l = document.forms[0].elements.length;
  for (i=0; i<l; i++) {
    if(document.forms[0].elements[i].type.indexOf("select") != -1) {
      if(document.forms[0].elements[i].name.indexOf("_ros_") != -1) {
        document.forms[0].elements[i].selectedIndex = "2";
      }
    }
  }
}

function toggleFamilyExtraNo()
{
  document.forms[0].elements['wc_fh_any_breast'].selectedIndex = "2";
  document.forms[0].elements['wc_fh_any_uterine'].selectedIndex = "2";
  document.forms[0].elements['wc_fh_any_cervix'].selectedIndex = "2";
  document.forms[0].elements['wc_fh_any_ovarian'].selectedIndex = "2";
  document.forms[0].elements['wc_fh_any_colon'].selectedIndex = "2";
}

function toggleROStoNull()
{
  var i;
  var l = document.forms[0].elements.length;
  for (i=0; i<l; i++) {
    if(document.forms[0].elements[i].type.indexOf("select") != -1) {
      if(document.forms[0].elements[i].name.indexOf("_ros_") != -1) {
        document.forms[0].elements[i].selectedIndex = "-1";
      }
    }
  }
}

function toggleROSTexttoNull()
{
  var i;
  var l = document.forms[0].elements.length;
  for (i=0; i<l; i++) {
    if(document.forms[0].elements[i].type.indexOf("text") != -1) {
      if(document.forms[0].elements[i].name.indexOf("_ros_") != -1) {
        document.forms[0].elements[i].value = "";
      }
    }
  }
}

function ClearWcGenExam()
{
  var i;
  var l = document.forms[0].elements.length;
  for (i=0; i<l; i++) {
    if(document.forms[0].elements[i].name.indexOf('wc_ge_') != -1) {
    	if(document.forms[0].elements[i].type.indexOf('select') != -1) {
        document.forms[0].elements[i].selectedIndex = '0';
      }
    	if(document.forms[0].elements[i].type.indexOf('check') != -1) {
        document.forms[0].elements[i].checked=false;
      }
    	if(document.forms[0].elements[i].type.indexOf('text') != -1) {
        document.forms[0].elements[i].value='';
      }
    }
  }
}

function SetWcGenExamNormal()
{
	var client_id = "";
	var numargs = arguments.length;
	if(numargs) {
		client_id = arguments[0];
	}
	// There is really no way to loop this any more
  document.forms[0].elements['wc_ge_gen_norm'].checked=true;
  document.forms[0].elements['wc_ge_gen_dev'].checked=true;
  document.forms[0].elements['wc_ge_gen_groom'].checked=true;
  document.forms[0].elements['wc_ge_gen_dis'].checked=true;
  document.forms[0].elements['wc_ge_gen_jaun'].selectedIndex='2';
  document.forms[0].elements['wc_ge_gen_waste'].selectedIndex='2';
  document.forms[0].elements['wc_ge_gen_sleep'].selectedIndex='1';
	if(client_id == 'wcs') {
  	document.forms[0].elements['wc_ge_gen_sleep'].selectedIndex='0';
	}
  document.forms[0].elements['wc_ge_hd_atra'].checked=true;
  document.forms[0].elements['wc_ge_hd_norm'].checked=true;
	if(client_id == 'wcs') {
  	document.forms[0].elements['wc_ge_hd_atra'].checked=false;
  	document.forms[0].elements['wc_ge_hd_norm'].checked=false;
	}
  document.forms[0].elements['wc_ge_eyer_norm'].selectedIndex='1';
  document.forms[0].elements['wc_ge_eyel_norm'].selectedIndex='1';
  document.forms[0].elements['wc_ge_mouth_moist'].checked=true;
  document.forms[0].elements['wc_ge_thrt_ery'].checked=true;
  document.forms[0].elements['wc_ge_thrt_exu'].checked=true;
	if(client_id == 'wcs') {
  	document.forms[0].elements['wc_ge_mouth_moist'].checked=false;
  	document.forms[0].elements['wc_ge_thrt_ery'].checked=false;
  	document.forms[0].elements['wc_ge_thrt_exu'].checked=false;
	}
  document.forms[0].elements['wc_ge_nk_sup'].checked=true;
  document.forms[0].elements['wc_ge_nk_trach'].checked=true;
  document.forms[0].elements['wc_ge_thy_norm'].checked=true;
  document.forms[0].elements['wc_ge_thy_nod'].selectedIndex='2';
  document.forms[0].elements['wc_ge_thy_brit'].selectedIndex='2';
  document.forms[0].elements['wc_ge_thy_tnd'].selectedIndex='2';
  document.forms[0].elements['wc_ge_brr_axil'].selectedIndex='2';
  document.forms[0].elements['wc_ge_brr_mass'].selectedIndex='2';
  document.forms[0].elements['wc_ge_nipr_ev'].selectedIndex='1';
  document.forms[0].elements['wc_ge_nipr_in'].selectedIndex='2';
  document.forms[0].elements['wc_ge_nipr_mass'].selectedIndex='2';
  document.forms[0].elements['wc_ge_nipr_dis'].selectedIndex='2';
  document.forms[0].elements['wc_ge_nipr_ret'].selectedIndex='2';
  document.forms[0].elements['wc_ge_brl_axil'].selectedIndex='2';
  document.forms[0].elements['wc_ge_brl_mass'].selectedIndex='2';
  document.forms[0].elements['wc_ge_nipl_ev'].selectedIndex='1';
  document.forms[0].elements['wc_ge_nipl_in'].selectedIndex='2';
  document.forms[0].elements['wc_ge_nipl_mass'].selectedIndex='2';
  document.forms[0].elements['wc_ge_nipl_dis'].selectedIndex='2';
  document.forms[0].elements['wc_ge_nipl_ret'].selectedIndex='2';
  document.forms[0].elements['wc_ge_cr_norm'].selectedIndex='1';
  document.forms[0].elements['wc_ge_cr_mur'].selectedIndex='2';
  document.forms[0].elements['wc_ge_cr_gall'].selectedIndex='2';
  document.forms[0].elements['wc_ge_cr_click'].selectedIndex='2';
  document.forms[0].elements['wc_ge_cr_rubs'].selectedIndex='2';
  document.forms[0].elements['wc_ge_cr_extra'].selectedIndex='2';
  document.forms[0].elements['wc_ge_pul_clear'].selectedIndex='1';
  document.forms[0].elements['wc_ge_pul_rales'].selectedIndex='2';
  document.forms[0].elements['wc_ge_pul_whz'].selectedIndex='2';
  document.forms[0].elements['wc_ge_pul_ron'].selectedIndex='2';
  document.forms[0].elements['wc_ge_pul_dec'].selectedIndex='2';
  document.forms[0].elements['wc_ge_gi_soft'].selectedIndex='1';
  document.forms[0].elements['wc_ge_gi_tend'].selectedIndex='2';
  document.forms[0].elements['wc_ge_gi_dis'].selectedIndex='2';
  document.forms[0].elements['wc_ge_gi_scar'].selectedIndex='2';
  document.forms[0].elements['wc_ge_gi_hern'].selectedIndex='2';
  document.forms[0].elements['wc_ge_gi_bowel'].selectedIndex='1';
  document.forms[0].elements['wc_ge_gi_hepa'].selectedIndex='2';
  document.forms[0].elements['wc_ge_gi_spleno'].selectedIndex='2';
  document.forms[0].elements['wc_ge_neu_ao'].selectedIndex='3';
}
