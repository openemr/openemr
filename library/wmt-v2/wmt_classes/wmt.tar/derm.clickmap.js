var clickmap = function( args ) {

	var f = true;
	var counter = 0;

	var fn_buildMarker = function( x, y, pos, annotation, selectedOption, selectedDiagnosis, selectedTreatment, notes) {
	       var fn_edit = function() {
	            f = false;
	            var dialog = $( ".dialog-form" ).clone();
	            dialog.find(".label").val( marker.attr("data-pos") );

	            var hasOptions = typeof(options) != "undefined";
                if ( hasOptions ) {
                        dialog.find("label[for='options']").text( optionsLabel );
                        var select = dialog.find("select[name='options']");
                        for ( var attr in options ) {
                                if ( options.hasOwnProperty(attr) ) {
                                	if ( attr == marker.attr("data-option") ) {
                                        select.append("<option selected value='" + attr + "'>" + options[attr] + "</option>");
                                	}
                                	else {
                                        select.append("<option value='" + attr + "'>" + options[attr] + "</option>");
                                	}
                                }
                        }
                } else {
                        dialog.find("label[for='options']").remove();
                        dialog.find("select[name='options']").remove();
                }

                var hasDiagnosis = typeof(diagnosis) != "undefined";
                if ( hasDiagnosis ) {
                        dialog.find("label[for='diagnosis']").text( diagnosisLabel );
                        var select = dialog.find("select[name='diagnosis']");
                        for ( var attr in diagnosis ) {
                                if ( diagnosis.hasOwnProperty(attr) ) {
                                	if ( attr == marker.attr("data-diagnosis") ) {
                                        select.append("<option selected value='" + attr + "'>" + diagnosis[attr] + "</option>");
                                	}
                                	else {
                                        select.append("<option value='" + attr + "'>" + diagnosis[attr] + "</option>");
                                	}
                                }
                        }
                } else {
                        dialog.find("label[for='diagnosis']").remove();
                        dialog.find("select[name='diagnosis']").remove();
                }


                var hasTreatment = typeof(treatment) != "undefined";
                if ( hasTreatment ) {
                        dialog.find("label[for='treatment']").text( treatmentLabel );
                        var select = dialog.find("select[name='treatment']");
                        for ( var attr in treatment ) {
                                if ( treatment.hasOwnProperty(attr) ) {
                                	if ( attr == marker.attr("data-treatment") ) {
                                        select.append("<option selected value='" + attr + "'>" + treatment[attr] + "</option>");
                                	}
                                	else {
                                        select.append("<option value='" + attr + "'>" + treatment[attr] + "</option>");
                                	}
                                }
                        }
                } else {
                        dialog.find("label[for='treatment']").remove();
                        dialog.find("select[name='treatment']").remove();
                }

	            dialog.find(".detail").val( decodeURIComponent(marker.attr("data-notes")) );
                
	            var do_edit = function() {
	                    if ( dialog.saved ) {
	                            var newcounter = dialog.find(".label").val();
	                            var notes = encodeURIComponent(dialog.find(".detail").val());
	                            var selectedOption = encodeURIComponent(dialog.find("select[name='options']").val());
	                               var combinedNotes = "";
                                   if ( selectedOption) {
                                           combinedNotes = options[selectedOption];
                                   }
                                   var selectedDiagnosis = encodeURIComponent(dialog.find("select[name='diagnosis']").val());
                                   if (selectedDiagnosis) {
                                       combinedNotes += "%20%28" + diagnosis[selectedDiagnosis] + "%29%20";
                                   }
                                   var selectedTreatment = encodeURIComponent(dialog.find("select[name='treatment']").val());
                                   if (selectedTreatment) {
                                       combinedNotes += "%20%28" + treatment[selectedTreatment] + "%29%20";
                                   }
                                   if ( (selectedOption && notes) || (selectedDiagnosis && notes) || (selectedTreatment && notes) ) {
                                       combinedNotes += "%3A%20";
                                   }
                                   if ( notes ) {
                                           combinedNotes += notes;
                                   }

	                		    marker.attr("data-pos", pos).attr("data-option", selectedOption).attr("data-diagnosis", selectedDiagnosis).attr("data-treatment", selectedTreatment).attr("data-notes", notes)
	                		    .attr("title", decodeURIComponent(combinedNotes) )
	                		    .show()

	                		    legendText = $("<li class='legend-item' id='legend-" + marker.attr("id") + "'><b>" + marker.attr("data-pos") + " - </b> " + decodeURIComponent(combinedNotes) + "</li>");
	                    		legendItem.html( legendText );
	                    }
	                    dialog.remove();
	            };

	            dialog.dialog({
	                    title: "Update Graphic",
	                    autoOpen: false, height: hasOptions? 345 : 300, width: 350, modal:true,
	                    open: function() { dialog.find(".detail").focus(); },
	                    buttons: {
	                            "Save": function() { dialog.saved = true; $(this).dialog("close"); },
	                            "Delete": function() { marker.remove(); legendItem.remove(); f = false; $(this).dialog("close"); },
	                            "Cancel": function() { $(this).dialog("close"); }
	                    },
	                    close: do_edit
	            });
	            dialog.dialog("open");
	       }
	    
	    	var marker = $(".marker-template").clone();
		    if (annotation != 'marker') { // only labels get legend
		    	marker.attr("data-x", x).attr("data-y", y).attr("data-pos", pos).attr("id", new Date().getTime() );
		    	marker.attr("class", "marker").attr("data-option", selectedOption).attr("data-diagnosis", selectedDiagnosis).attr("data-treatment", selectedTreatment);
		    	marker.attr("data-notes", notes).attr("style", "left:" + x + "px; top:" + y + "px;" ).find("span.count").text( pos );
		    	marker.mouseenter( function() { f = true; } )
		    	.mouseleave( function() { f = false; } )
		    	.attr("title", annotation ? decodeURIComponent(annotation) : "" )
			  .show()
//		   	  .click( function() { $(this).remove(); legendItem.remove(); f = false; } );
		   	  .click( fn_edit );
		    	var legendItem = $("<li class='legend-item' id='legend-" + marker.attr("id") + "'><b>" + pos + " - </b> " + decodeURIComponent(annotation) + "</li>");
		    	$(".legend .body ul").append( legendItem );
		    }
		    else {
		    	marker = $(".marker-template").clone();
		    	marker.attr("data-x", x).attr("data-y", y).attr("data-pos", pos).attr("id", new Date().getTime() );
		    	marker.attr("class", "marker").attr("data-option", selectedOption).attr("data-diagnosis", selectedDiagnosis).attr("data-treatment", selectedTreatment);
		    	marker.attr("data-notes", notes).attr("style", "left:" + x + "px; top:" + y + "px;" ).find("span.count").text( pos );
		    	marker.mouseenter( function() { f = true; } )
		    	.mouseleave( function() { f = false; } )
		    	.attr("title", annotation ? decodeURIComponent(annotation) : "" )
			  .show()
		   	  .click( function() { $(this).remove(); f = false; } );
//		   	  .click( fn_edit );
		    }

		return marker;
	};

	var fn_isnumber = function(num) { return !isNaN( parseInt( num ) ); }
	
	var fn_clear = function() { 
		$(".marker").remove();
		$(".legend-item").remove();
		counter = 0; 
	};

	var fn_load = function( container, val ) {
		fn_clear();
        if ( !val ) return;
		var coordinates = val.split("}");
		for ( var i = 0; i < coordinates.length; i++ ) {
			var coordinate = coordinates[i];
			if ( coordinate ) {
				var info = coordinate.split("^");
				var x = info[0]; var y = info[1]; var label = info[2]; var detail = info[3]; var selectedOption = info[4]; var selectedDiagnosis = info[5]; var notes = decodeURIComponent(info[6]); var selectedTreatment = info[7]; 
				if (selectedOption == null) selectedOption = 0;
				if (selectedDiagnosis == null) selectedDiagnosis = 0;
				if (selectedTreatment == null) selectedTreatment = 0;
				if (notes == null || notes == 0) notes = '';
				var marker = fn_buildMarker( x, y, label, detail, selectedOption, selectedDiagnosis, selectedTreatment, notes);
				if (hideNav == true) marker.unbind('click');
				container.append(marker);
				if ( fn_isnumber(label) ) {
					counter = parseInt(label);
				}
			}
		}
	};

	var fn_save = function() {
		var val = "";
		$(".marker").each( function() {
			var marker = $(this);
			val += marker.attr("data-x") + "^" + marker.attr("data-y") + "^" + marker.attr("data-pos") + "^" + marker.attr("data-option") + "^" + marker.attr("data-diagnosis") + "^" + encodeURIComponent(marker.attr("notes")) + "^" + encodeURIComponent(marker.attr("data-treatment")) + "}";
		});
		$("#data").attr("value", val);
                $("#submitForm").submit();
	};
	

	//// main
	var dropdownOptions = args.dropdownOptions;
	var options = dropdownOptions.options;
	var optionsLabel = dropdownOptions.optionsLabel;
	var diagnosis = dropdownOptions.diagnosis;
	var diagnosisLabel = dropdownOptions.diagnosisLabel;
	var treatment = dropdownOptions.treatment;
	var treatmentLabel = dropdownOptions.treatmentLabel;
	var container = args.container;
	var data = args.data;
	var hideNav = args.hideNav;

	container.mousemove( function() { f = true; });

        if ( !hideNav ) {
            container.click ( function(e) {
                    if ( !f || marker_type == '') return;
                    var x = e.pageX - this.offsetLeft - 5;
                    var y = e.pageY - this.offsetTop - 5;
                    if (marker_type != 'LABEL') {
                    	var marker = fn_buildMarker( x, y, marker_type, 'marker', 0, 0, 0, '' );
                        container.append(marker);
                    }
                    else {

                    var dialog = $( ".dialog-form" ).clone();
                    dialog.find(".label").val( counter + 1 );

                    var hasOptions = typeof(options) != "undefined";
                    if ( hasOptions ) {
                            dialog.find("label[for='options']").text( optionsLabel );
                            var select = dialog.find("select[name='options']");
                            for ( var attr in options ) {
                                    if ( options.hasOwnProperty(attr) ) {
                                            select.append("<option value='" + attr + "'>" + options[attr] + "</option>");
                                    }
                            }
                    } else {
                            dialog.find("label[for='options']").remove();
                            dialog.find("select[name='options']").remove();
                    }

                    var hasDiagnosis = typeof(diagnosis) != "undefined";
                    if ( hasDiagnosis ) {
                            dialog.find("label[for='diagnosis']").text( diagnosisLabel );
                            var select = dialog.find("select[name='diagnosis']");
                            for ( var attr in diagnosis ) {
                                    if ( diagnosis.hasOwnProperty(attr) ) {
                                            select.append("<option value='" + attr + "'>" + diagnosis[attr] + "</option>");
                                    }
                            }
                    } else {
                            dialog.find("label[for='diagnosis']").remove();
                            dialog.find("select[name='diagnosis']").remove();
                    }

                    var hasTreatment = typeof(treatment) != "undefined";
                    if ( hasTreatment ) {
                            dialog.find("label[for='treatment']").text( treatmentLabel );
                            var select = dialog.find("select[name='treatment']");
                            for ( var attr in treatment ) {
                                    if ( treatment.hasOwnProperty(attr) ) {
                                            select.append("<option value='" + attr + "'>" + treatment[attr] + "</option>");
                                    }
                            }
                    } else {
                            dialog.find("label[for='treatment']").remove();
                            dialog.find("select[name='treatment']").remove();
                    }

                    var do_marker = function() {
                            if ( dialog.saved ) {
                                    var newcounter = dialog.find(".label").val();
                                    var notes = encodeURIComponent(dialog.find(".detail").val());
                                    var selectedOption = encodeURIComponent(dialog.find("select[name='options']").val());
                                    var combinedNotes = "";
                                    if ( selectedOption) {
                                            combinedNotes = options[selectedOption];
                                    }
                                    var selectedDiagnosis = encodeURIComponent(dialog.find("select[name='diagnosis']").val());
                                    if (selectedDiagnosis) {
                                        combinedNotes += "%20%28" + diagnosis[selectedDiagnosis] + "%29%20";
                                    }
                                    var selectedTreatment = encodeURIComponent(dialog.find("select[name='treatment']").val());
                                    if (selectedTreatment) {
                                        combinedNotes += "%20%28" + treatment[selectedTreatment] + "%29%20";
                                    }
                                    if ( (selectedOption && notes) || (selectedDiagnosis && notes) || (selectedTreatment && notes) ) {
                                        combinedNotes += "%3A%20";
                                    }
                                    if ( notes ) {
                                            combinedNotes += notes;
                                    }

                                    var marker = fn_buildMarker( x, y, newcounter, combinedNotes, selectedOption, selectedDiagnosis, selectedTreatment, notes );
                                    container.append(marker);
                                    if ( fn_isnumber(newcounter) ) { counter++; }
                            }
                            dialog.remove();
                    };

                    dialog.dialog({
                            title: "Information",
                            autoOpen: false, height: hasOptions? 345 : 300, width: 350, modal:true,
                            open: function() { dialog.find(".detail").focus(); },
                            buttons: {
                                    "Save": function() { dialog.saved = true; $(this).dialog("close"); },
                                    "Cancel": function() { $(this).dialog("close"); }
                            },
                            close: do_marker
                    });
                    dialog.dialog("open");
                    
                    } // end type if
            });

       }

        
    var btn_clear = $("#btn_clear");
	btn_clear.click( fn_clear );

	var btn_save = $("#btn_save");
	btn_save.click( fn_save );

	fn_load( container, data );

        if ( hideNav ) {
            $(".nav").hide();
        };
};


