<?php
if(isset($imm) && (count($imm) > 0)) {
	echo "<div class='wmtPrnMainContainer'>\n";
	echo "  <div class='wmtPrnCollapseBar'>\n";
	echo "    <span class='wmtPrnChapter'>Immunizations</span>\n";
	echo "  </div>\n";
	echo "  <div class='wmtPrnCollapseBox'>\n";
	echo "	<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
	echo " 	<tr>\n";
	echo " 		<td class='wmtPrnLabelCenterBorderB' style='width: 95px'>Date</td>\n";
	echo " 		<td class='wmtPrnLabelCenterBorderLB'>Immunization</td>\n";
	echo " 		<td class='wmtPrnLabelCenterBorderLB'>Notes</td>\n";
	echo " 	</tr>\n";
	foreach($imm as $prev) {
		echo "	<tr>\n";
		echo "		<td class='wmtPrnBodyBorderB'>",$prev['administered_date'],"&nbsp;</td>\n";
		echo "		<td class='wmtPrnBodyBorderLB'>",ImmLook($prev['cvx_code'],'immunizations'),"&nbsp;</td>\n";
		echo "		<td class='wmtPrnBodyBorderLB'>",$prev['note'],"&nbsp;</td>\n";
		echo "	</tr>\n";
	}
	echo "	</table>\n";
	echo "	</div>\n";
	echo "</div>\n";
}
?>
