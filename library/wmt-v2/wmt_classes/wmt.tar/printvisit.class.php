<?php
/** **************************************************************************
 *	PRINTVISIT.CLASS.PHP
 *	This file contains a print class for use with any print form
 *
 *  NOTES:
 *  1) __CONSTRUCT - uses the encounter id to retrieve data 
 *  2) GET - uses alternate selectors to find and return associated object
 * 
 *  @version 1.0
 *  @copyright Williams Medical Technologies, Inc.
 *  @author Rich Genandt <rgenandt@gmail.com>
 * 
 *************************************************************************** */

/** 
 * Provides a partial representation of the patient encouner record This object
 * does NOT include all of the fields associated with the core encounter data
 * record and should NOT be used for database updates.  It is intended only
 * for retrieval of partial patient information primarily for display 
 * purposes (reports for example).
 *
 */

class wmtPrintVisit{
	public $encounter_id;
	public $facility_id;
	public $provider_id;
	public $supervisor_id;
	public $signed_by;
	public $approved_by;
	
	// generated values - none in use currently
	
	/**
	 * Constructor for the 'encounter' print class which retrieves the requested 
	 * encounter information from the database.
	 * 
	 * @param int $id encounter id number 
	 * @return object instance of encounter print class
	 */
	public function __construct($id = false, $approval_user = '') {
		if(!$id) return false;

		$query = "SELECT * FROM form_encounter WHERE id =?";
		$results = sqlStatement($query, array($id));
	
		if ($data = sqlFetchArray($results)) {
			$this->encounter_id = $data['encounter'];
			$this->facility_id = $data['facility_id'];
			$this->provider_id = $data['provider_id'];
			$this->supervisor_id = $data['supervisor_id'];
		}
		else {
			throw new Exception('wmtPrintVisit::_construct - no encounter record with id ('.$this->id.').');
		}
		// Default facility to 3 if not set
		if(!$this->facility_id) { $this->facility_id= 3; }
		
		// preformat commonly used data elements	
		$signing_user = '';
		$this->signed_by = 'No Signature on File';
		if($this->provider_id) {
  		$rlist= sqlStatement("SELECT id, lname, fname, mname, username ".
					"FROM users WHERE id=?", array($this->provider_id));
  		$rrow= sqlFetchArray($rlist);
  		if($rrow{'id'}) {
				$signing_user = $rrow{'username'};
				$_mi = ' ';
				if(!empty($rrow{'mname'})) { $_mi = ' '.$rrow{'mname'}.' '; }
    		$this->signed_by= 'Digitally Signed By: '.$rrow{'fname'}.$_mi.
						$rrow{'lname'};
  		}
		}
		$this->approved_by = '';
		if($approval_user && ($approval_user != $signing_user)) {
  		$sql= "SELECT id, lname, fname, mname FROM users WHERE username=?";
  		$rlist= sqlStatement($sql, array($approval_user));
  		if($rlist) {
    		$rrow= sqlFetchArray($rlist);
				if($rrow{'id'}) {
    			$_mi=' ';
    			if($rrow['mname']) $_mi=' '.$rrow['mname'].' ';
    			$this->approved_by = 'Approved By: '.$rrow['fname'].
																											$_mi.$rrow['lname'];
				}
  		}
		}
		
	}	

	/**
	 * Retrieve an encounter object by encounter value. Uses the base constructor 
   * for the 'visit' print class to create and return the object.
	 * 
	 * @static
	 * @param int $enc encounter record encounter
	 * @return object instance of visit pring class
	 */
	public static function getEncounter($enc) {
		if(!$enc) {
			throw new Exception('wmtPrintVisit::getEncounter - no encounter identifier provided.');
		}
		
		$results = sqlStatement("SELECT id FROM form_encounter WHERE encounter=?",
			 array($enc));
		$data = sqlFetchArray($results);
		return new wmtPrintVisit($data['id']);
	}
	
	/**
	 * Retrieve an encounter object by encounter value. Uses the base constructor 
   * for the 'visit' print class to create and return the object.
	 * 
	 * @static
	 * @param int $enc encounter record encounter
	 * @return object instance of visit pring class
	 */
	public static function getEncounterByForm($form_id, $formdir) {
		if(!$form_id) {
			throw new Exception('wmtPrintVisit::getEncounterByForm - no form identifier provided.');
		}
		if(!$formdir) {
			throw new Exception('wmtPrintVisit::getEncounterByForm - no form directory provided.');
		}
		/**
		*  Load the approving physician so we can see if it's different than
		*  the provider
		**/		
		$approval_user = '';
		$results = sqlStatement("SELECT user, form_complete, approved_by ".
			"FROM form_$formdir WHERE id=?", array($form_id));
		$data= sqlFetchArray($results);
		if(strtolower($data{'form_complete'}) == 'a') {
			$approval_user = $data{'approved_by'};
			if($data{'approved_by'} == '') {
				$approval_user = $data{'user'};
			}
		}	

		$results = sqlStatement("SELECT encounter FROM forms WHERE form_id=?".
			" AND formdir=?", array($form_id, $formdir));
		$data = sqlFetchArray($results);
		$results = sqlStatement("SELECT id FROM form_encounter WHERE encounter=?",
			 array($data['encounter']));
		$data = sqlFetchArray($results);
		return new wmtPrintVisit($data['id'], $approval_user);
	}

}
                                            
?>
