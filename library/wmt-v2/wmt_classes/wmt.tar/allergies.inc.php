<?php
echo"<table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";
echo"	<tr>\n";
echo"		<td class='LabelCenterBorderB' style='width: 95px'>Start Date</td>\n";
echo"		<td class='LabelCenterBorderLB'>Title</td>\n";
echo"		<td class='LabelCenterBorderLB'>Reaction</td>\n";
echo"		<td class='LabelCenterBorderLB'>Comments</td>\n";
if($unlink_allow) {
	echo"		<td class='LabelCenterBorderLB' style='width: 115px'>&nbsp;</td>\n";
} else {
	echo"		<td class='LabelCenterBorderLB' style='width: 65px'>&nbsp;</td>\n";
}
echo"	</tr>\n";
$cnt=1;
if(isset($allergies) && (count($allergies) > 0)) {
	foreach($allergies as $prev) {
		echo "<tr>\n";
		echo "<td class='BodyBorderB'><input name='all_id_".$cnt."' id='all_id_".$cnt."' type='hidden' tabindex='-1' readonly='readonly' value='".$prev['id']."' />".$prev['begdate']."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'>".$prev['title']."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'>".ListLook($prev['outcome'],'outcome')."&nbsp;</td>\n";
		echo "<td class='BodyBorderLB'><input name='all_comments_".$cnt."' id='all_coments_".$cnt."' class='FullInput' type='text' tabindex='-1' value='".$prev['comments']."' /></td>\n";
		echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdateAllergy(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;' title='Update the comment associated with this allergy'><span>Update</span></a>";
		if($unlink_allow) { 
			echo "<a class='css_button_small' tabindex='-1' onClick='return UnlinkAllergy(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;' title='Unlink this allergy from this visit'><span>Un-Link</span></a>";
		}
		echo "</td>\n";
		// echo "<td class='BodyBorderLB'><a class='css_button_small' tabindex='-1' onClick='return UpdateAllergy(\"$base_action\",\"$wrap_mode\",\"$cnt\",\"$id\");' href='javascript:;' title='Update the comment associated with this allergy'><span>Update</span></a></td>\n";
		echo "</tr>\n";
		$cnt++;
	}
} else if(!$allergy_add_allowed) {
	echo "<tr>\n";
	echo "<td class='LabelBorderB'>&nbsp;</td>\n";
	echo "<td class='LabelBorderLB'>None on File</td>\n";
	echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
	echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
	echo "<td class='LabelBorderLB'>&nbsp;</td>\n";
	echo "</tr>\n";
}
if($allergy_add_allowed) {
	echo "<tr>\n";
	echo "	<td class='BodyBorderB'><input name='all_begdate' id='all_begdate' class='FullInput' type='text' title='YYYY-MM-DD' value='",$dt{'all_begdate'},"' /></td>\n";
	echo "	<td class='BodyBorderLB'><input name='all_title' id='all_title' class='FullInput' type='text' value='",$dt{'all_title'},"' /></td>\n";
	echo "	<td class='BodyBorderLB'><input name='all_react' id='all_react' class='FullInput' type='text' value='",$dt{'all_react'},"' /></td>\n";
	echo "	<td class='BodyBorderLB'><input name='all_comm' id='all_comm' class='FullInput' type='text' value='",$dt{'all_comm'},"' /></td>\n";
	echo "  <td class='BodyBorderLB'>&nbsp;</td>\n";
	echo "</tr>\n";
	echo "	<tr>\n";
	echo "		<td class='CollapseBar' style='border-bottom: solid 1px black;' colspan='5'><a class='css_button' onClick='return SubmitAllergy(\"$base_action\",\"$wrap_mode\",\"$id\");' href='javascript:;'><span>Add Another</span></a></td>\n";
	echo "	</tr>\n";
}
echo "<tr>\n";
echo "	<td class='Label' colspan='2'>Other Notes:</td>\n";
echo "</tr>\n";
echo "<tr>\n";
echo "	<td class='Body' colspan='5'><textarea name='fyi_allergy_nt' id='fyi_allergy_nt' rows='4' class='FullInput'>".$dt['fyi_allergy_nt']."</textarea></td>\n";
echo "</tr>\n";
echo "</table>\n";
?>
