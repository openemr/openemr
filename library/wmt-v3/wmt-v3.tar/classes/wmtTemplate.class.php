<?php
/** **************************************************************************
 *	TEMPLATE.CLASS.PHP
 *
 *	Copyright (c)2016 - Medical Technology Services <MDTechSvcs.com>
 *
 *	This program is free software: you can redistribute it and/or modify it under the 
 *  terms of the GNU General Public License as published by the Free Software Foundation, 
 *  either version 3 of the License, or (at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful, but WITHOUT ANY
 *	WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
 *  PARTICULAR PURPOSE. DISTRIBUTOR IS NOT LIABLE TO USER FOR ANY DAMAGES, INCLUDING 
 *  COMPENSATORY, SPECIAL, INCIDENTAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES, 
 *  CONNECTED WITH OR RESULTING FROM THIS AGREEMENT OR USE OF THIS SOFTWARE.
 *
 *	See the GNU General Public License <http://www.gnu.org/licenses/> for more details.
 *
 *  @package wmt
 *  @subpackage template
 *  @version 1.0.0
 *  @category Email Base Class
 *  @copyright Medical Technology Services
 *  @author Ron Criswell <ron.criswell@MDTechSvcs.com>
 *
 ******************************************************************************************** */

/**
 * All new classes are defined in the WMT namespace
 */
namespace wmt;

/**
 * Provides standardized processing for document templates.
 *
 * @package wmt
 * @subpackage template
 */
class Template {
	public $html_body;
	public $html_tags;
	public $html_merged;
	public $text_body;
	public $text_tags;
	public $text_merged;
	
	/**
	 * Constructor for the 'template' class which generates all types 
	 * of documents used for email, PDF, and simple text.
	 *
	 * @return object instance of form class
	 * 
	 */
	public function __construct($id = false) {
		if ($id === false) return;
		
		// get table fields (verify table exists)
		$fields = sqlListFields("templates");
		if (is_array($fields) === false) 
			throw new \Exception("wmtTemplate::__construct - missing templates database table");

		// retrieve record
		$data = sqlQueryNoLog("SELECT * FROM `templates` WHERE `id` = ?", array($id));
		if ($data === false) $data = array();
		
		// store content
		foreach ($fields AS $key) {
			$this->$key = (array_key_exists($key, $data)) ? $data[$key] : '';
		}
		
		// find tags within content
		$count = preg_match_all("/\[([^\]]*)\]/", $this->html_body, $html_tags);
		$this->html_tags = ($count) ? $html_tags[1] : array(); // array[1] contains match content
		
		$count = preg_match_all("/\[([^\]]*)\]/", $this->text_body, $text_tags);
		$this->text_tags = ($count) ? $text_tags[1] : array();
		
		return;
	}

	/**
	 * Determine the current version for a template name and return
	 * an object for that template.
	 * 
	 * @param string $name unique name for the template
	 * @return object wmtTemplate
	 * 
	 */
	public static function Lookup($name) {
		if (!$name)
			throw new \Exception('wmtTemplate::Lookup - no name provided for template lookup');

		$name = strtolower(preg_replace('/^[^\w]+$/', '', $name)); // only a-z,0-9,_
		$result = sqlQueryNoLog("SELECT `id` FROM `templates` WHERE `name` = ?", array($name));
		
		if (!$result || !$result['id'])
			throw new \Exception('wmtTemplate::Lookup - no matching record in template table');
				
		return new self($result['id']);
	}
		
	/**
	 * Generate a merge template document based on a stored template
	 * using the data provided.
	 * 
	 * @param array $elements data elements to be inserted
	 * @param int $id record identifier for the template
	 * @return string merged template content
	 */
	public function Merge($elements) {
		if (is_array($elements) === false)
			throw new \Exception('wmtTemplate::Merge - no element data provided for merge');

		if (!$this->id)
			throw new \Exception('wmtTemplate::Merge - no template available for merge');

		// get html content
		$content = $this->html_body;

		// do html substitutions
		if (is_array($this->html_tags)) {
			foreach ($this->html_tags AS $tag) {
				$value = (array_key_exists($tag, $elements)) ? $elements[$tag] : '';
				$content = str_ireplace('['.$tag.']', $value, $content);
			}
		}
		
		// store merged html document
		$this->html_merged = $content;
		
		// get text content
		$content = $this->text_body;

		// do html substitutions
		if (is_array($this->text_tags)) {
			foreach ($this->text_tags AS $tag) {
				$value = (array_key_exists($tag, $elements)) ? $elements[$tag] : '';
				$content = str_ireplace('['.$tag.']', $value, $content);
			}
		}
		
		// store merged html document
		$this->text_merged = $content;

	}
	
}
