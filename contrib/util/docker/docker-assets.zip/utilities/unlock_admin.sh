#!/bin/sh

cd /root
php ./unlock_admin.php $1
