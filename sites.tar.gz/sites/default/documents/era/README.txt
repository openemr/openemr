This directory saves output from automated remittance (X12 835) processing.
This includes archived remittance files, and copies of the generated HTML
reports.

