This holds pieces needed for different versions of encryption.
