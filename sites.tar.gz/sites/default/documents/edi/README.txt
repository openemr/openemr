This directory is for saving transmitted electronic batches for various kinds
of problem solving, and should be writable by the web server.

