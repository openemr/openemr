<?php $_config_vars = array (
  'TableBorderColor' => '<?php $GLOBALS[\'style\'][\'BGCOLOR1\'] ?>',
  'TableBackgroundColor' => '<?php $GLOBALS[\'style\'][\'BGCOLOR2\'] ?>',
  'DayNameColor' => 'var(--white)',
  'MonthDateTextColor' => '#990000',
  'NonMonthDateTextColor' => '#cc6666',
  'CurrentDateTextColor' => '#990000',
  'CurrentDayHighlightColor' => '#cc6666',
  'CurrentWeekHighlight' => '<?php $GLOBALS[\'style\'][\'BGCOLOR1\'] ?>',
  'MonthCellColor' => '#eeeeee',
  'NonMonthCellColor' => '#999999',
  'CellHighlight' => 'var(--white)',
  'HeaderTextColor' => 'var(--white)',
); ?>